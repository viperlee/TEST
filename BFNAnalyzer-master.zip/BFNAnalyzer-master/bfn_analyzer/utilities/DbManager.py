# -*- coding: utf-8 -*-

import psycopg2
import base64
from psycopg2._psycopg import connection
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from qgis.core import QgsDataSourceUri
from qgis.core import Qgis
import uuid

from .patterns import Singleton
from .log import *
from .enumeration import *


ExecuteType = enum('EXECUTE', 'SELECT', 'USING_CURSOR')

class DbOptions:
    def __init__(self):
        self.auto_commit = True
        self.result_type = 0  # 0:execute, 1:select
        self.cursor_iter_size = 10000
        self.server_side_cursor = False


class DbManager(Singleton):
    def __init__(self):
        self.current_db_uri = None
        self.common_db_uri = None
        self.connections = dict()
        self.set_common_db_info()
        self.set_current_db_info()
        self.current_db_name = None

    def __del__(self):
        if self.connections:
            for conn in self.connections.values():
                if conn:
                    conn.close()
                conn = None

    @staticmethod
    def make_db_connect_string(connection_info):
        conn_str = None
        if type(connection_info) == dict:
            conn_str = "dbname='{0}' host='{1}' port='{2}' user='{3}' password='{4}'".format(
                connection_info['dbname'],
                connection_info['host'],
                connection_info['port'],
                connection_info['user'],
                connection_info['password']
            )
        elif type(connection_info) == QgsDataSourceUri:
            conn_str = "dbname='{0}' host='{1}' port='{2}' user='{3}' password='{4}'".format(
                connection_info.database(),
                connection_info.host(),
                int(connection_info.port()),
                connection_info.username(),
                connection_info.password()
            )
        else:
            return None
        return conn_str

    @staticmethod
    def make_dblink_connection_string(connection_info):
        conn_str = None
        if type(connection_info) == dict:
            conn_str = "host={0} port={1} dbname={2} user={3} password={4}".format(
                connection_info['host'],
                connection_info['port'],
                connection_info['dbname'],
                connection_info['user'],
                connection_info['password']
            )
        elif type(connection_info) == QgsDataSourceUri:
            conn_str = "host={0} port={1} dbname={2} user={3} password={4}".format(
                connection_info.host(),
                int(connection_info.port()),
                connection_info.database(),
                connection_info.username(),
                connection_info.password()
            )
        else:
            pass
        return conn_str

    def connect_db(self, connection_info,  managed):
        conn_str = self.make_db_connect_string(connection_info)
        if not conn_str:
            return None

        if not managed:
            try:
                db_conn = psycopg2.connect(conn_str)
                cur = db_conn.cursor()
                cur.close()
                return db_conn
            except Exception as e:
                log(self, 'db connection failed.\n{0}\n{1}'.format(conn_str, e))
                return None
        else:
            try:
                cur = self.connections[conn_str].cursor()
                cur.execute(bytes("select 1;"))
                cur.close()
                return self.connections[conn_str]
            except:
                try:
                    db_conn = psycopg2.connect(conn_str)
                    self.connections[conn_str] = db_conn
                    return self.connections[conn_str]
                except Exception as e:
                    log(self, 'db connection failed.\n{0}\n{1}'.format(conn_str, e))
                    return None

    @staticmethod
    def get_create_server_side_cursor_sql(sql):
        cursor_func_name = 'ref_{0}'.format(str(uuid.uuid4().fields[0]))
        # print 'serverside_cursor_name = {0}'.format(cursor_func_name)
        cursor_sql = "CREATE OR REPLACE FUNCTION {0}(refcursor) RETURNS refcursor AS $$ " \
                  "BEGIN " \
                  "OPEN $1 FOR {1}; " \
                  "RETURN $1; " \
                  "END; " \
                  "$$ LANGUAGE plpgsql;".format(cursor_func_name, sql)
        return cursor_func_name, cursor_sql

    @staticmethod
    def get_drop_server_side_cursor_sql(cursor_func_name):
        sql = "drop function {0}(refcursor)".format(cursor_func_name)
        return sql

    def execute_sql(self, conn, sql, options=None):
        if type(conn) is QgsDataSourceUri:
            conn = self.connect_db(conn, True)

        if not conn:
            log(self, 'connection error')
            return False, None

        auto_commit = True
        result_type = 0
        cursor_iter_size = 10000
        using_server_side_cursor = False
        conn.set_client_encoding('UTF8')
        # conn.set_client_encoding('UNICODE')

        if options:
            if isinstance(options, DbOptions):
                # auto_commit = options.auto_commit
                result_type = options.result_type
                cursor_iter_size = options.cursor_iter_size
                using_server_side_cursor = options.server_side_cursor
            else:
                if options ==  ExecuteType.SELECT:
                    result_type = 1
                elif options ==  ExecuteType.USING_CURSOR:
                    result_type = 1
                    using_server_side_cursor = True

        utf_8_str = sql
        if isinstance(utf_8_str, unicode):
            utf_8_str = utf_8_str.encode('utf-8', 'surrogateescape').decode('utf-8', 'replace')
        if auto_commit:
            conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        else:
            conn.set_isolation_level(None)
        results = list()
        cur = conn.cursor()
        if result_type == 0:
            try:
                cur.execute(utf_8_str)
                cur.close()
                return True, results
            except Exception as e:
                if e.args[0] == "can't execute an empty query":
                    cur.close()
                    return True, results
                log(self, 'execute_sql error.\n{0}'.format(e.args), Qgis.Warning)
                cur.close()
                return False, results
        elif result_type == 1:
            if using_server_side_cursor:
                cursor_func_name, cursor_sql = self.get_create_server_side_cursor_sql(utf_8_str)
                cursor_name = 'cursor_{0}'.format(str(uuid.uuid4().fields[0]))

                cur.execute(bytes(cursor_sql))
                cur.callproc(cursor_func_name, [cursor_name])
                ss_cursor = conn.cursor(cursor_name)

                try:
                    while True:
                        rows = ss_cursor.fetchmany(cursor_iter_size)
                        results.extend(rows)
                        get_row_count = len(rows)
                        if get_row_count < cursor_iter_size:
                            break

                except Exception as e:
                    log(self, 'cursor fetch failed.\n{0}\n{1}'.format(e.args, sql), Qgis.Warning)

                ss_cursor.close()
                if cursor_func_name:
                    sql = self.get_drop_server_side_cursor_sql(cursor_func_name)
                    cur.execute(bytes(sql))
            else:
                cur.execute(utf_8_str)
                results = cur.fetchall()
                # cur.execute(bytes("commit;".encode('utf-8')))

        conn.commit()
        cur.close()

        return True, results

    def cancel_sql(self, conn):
        pid = conn.get_backend_pid()
        query = 'select pg_cancel_backend({0})'.format(pid)
        self.execute_sql(conn, query)
        log(self, 'execute canceled.')

    def get_external_connection_info(self):
        qry = u"SELECT db_name, conn_host, conn_port, conn_dbname, conn_user, conn_password from external_db_connection_info"

        options = DbOptions()
        options.result_type = 1  # select
        ret, results = self.execute_sql(self.common_db_uri, qry, options)
        connection_infos = dict()

        for row in results:
            db_name = row[0]
            conn_host = row[1]
            conn_port = row[2]
            conn_dbname = row[3]
            conn_user = row[4]
            conn_password = row[5]
            if conn_user and len(conn_user) > 0:
                connection_infos[db_name] = {"host": conn_host,
                                             "port": conn_port,
                                             "dbname": conn_dbname,
                                             "user": conn_user,
                                             "password": conn_password
                                             }
            else:
                connection_infos[db_name] = {"host": conn_host,
                                             "port": conn_port,
                                             "dbname": conn_dbname,
                                             "user": self.current_db_uri.username(),
                                             "password": self.current_db_uri.password(),
                                             }
        return connection_infos

    def set_common_db_info(self, db_info=None):
        self.common_db_uri = QgsDataSourceUri()
        if not db_info:
            return

        host, port, db, id, pw = db_info
        self.common_db_uri.setConnection(host, port, db, id, pw)

    def set_current_db_info(self, db_info=None):
        self.current_db_uri = QgsDataSourceUri()
        if not db_info:
            return

        host, port, db, id, pw = db_info
        self.current_db_name = db
        self.current_db_uri.setConnection(host, port, db, id, pw)

    def get_current_db_info(self):
        return QgsDataSourceUri(self.current_db_uri)

    def get_common_db_info(self):
        return QgsDataSourceUri(self.common_db_uri)

    def get_db_list(self, prefix, db_uri=None):
        if not db_uri:
            return []

        qry = "SELECT datname FROM pg_database AS a " \
              "WHERE datistemplate = false AND datname LIKE '{0}_%' ORDER BY datname DESC;".format(prefix)

        options = DbOptions()
        options.result_type = 1
        ret, results = self.execute_sql(db_uri, qry, options)

        if not ret:
            return []

        return [result[0] for result in results]

    def create_new_database(self, db_name, template_db_name=None):
        new_db_uri = self.get_common_db_info()
        new_db_uri.setDatabase(db_name)

        conn_str = self.make_db_connect_string(new_db_uri)
        if template_db_name:
            create_db_sql = "create database {0} template {1} owner bfna_user;".format(db_name, template_db_name)
        else:
            create_db_sql = "create database {0} owner bfna_user;".format(db_name)
        grant_sql = "grant connect, temporary on database {0} to public;" \
                    "grant all on database {0} to bfna_user;" \
                    "".format(db_name)
        try:
            db_conn = psycopg2.connect(conn_str)
            if not db_conn:
                create_db_conn = psycopg2.connect(self.make_db_connect_string(self.common_db_uri))
                self.execute_sql(create_db_conn, create_db_sql)
                self.execute_sql(create_db_conn, grant_sql)
                # create_db_cur = create_db_conn.cursor()
                # create_db_cur.execute(create_db_sql)
                # create_db_cur.execute(grant_sql)
                # create_db_cur.close()
                db_conn = psycopg2.connect(conn_str)
                if not db_conn:
                    return False

        except Exception as e:
            if not template_db_name:
                return False

            disconnect_sql = "SELECT pg_terminate_backend(pg_stat_activity.pid) " \
                             "FROM pg_stat_activity " \
                             "WHERE pg_stat_activity.datname = '{0}' AND pid != pg_backend_pid();".format(template_db_name)
            create_db_conn = psycopg2.connect(self.make_db_connect_string(self.common_db_uri))
            create_db_conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
            self.execute_sql(create_db_conn, disconnect_sql)
            self.execute_sql(create_db_conn, create_db_sql)
            self.execute_sql(create_db_conn, grant_sql)
            # create_db_cur = create_db_conn.cursor()
            # create_db_cur.execute(disconnect_sql)
            # create_db_cur.execute(create_db_sql)
            # create_db_cur.execute(grant_sql)
            # create_db_cur.close()

            db_conn = psycopg2.connect(conn_str)
            if not db_conn:
                log(self, 'DB를 생성하지 못했습니다.', Qgis.Warning)
                return False

        return True

    def drop_database(self, db_name):
        if db_name in ('common','postgres','template_db'):
            return

        disconnect_sql = "SELECT pg_terminate_backend(pg_stat_activity.pid) " \
                         "FROM pg_stat_activity " \
                         "WHERE pg_stat_activity.datname = '{0}' AND pid != pg_backend_pid();".format(db_name)
        drop_db_sql = "drop database {0};".format(db_name)
        conn = psycopg2.connect(self.make_db_connect_string(self.common_db_uri))
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        self.execute_sql(conn, disconnect_sql)
        self.execute_sql(conn, drop_db_sql)
        # cursor = conn.cursor()
        # cursor.execute(disconnect_sql)
        # cursor.execute(drop_db_sql)
        # cursor.close()

