# -*- coding: utf-8 -*-
import os
import sys
import time
import codecs
import inspect
import datetime
import subprocess

from qgis.core import QgsMessageLog
from qgis.core import Qgis

from ..Const import Const
from qgis.PyQt.QtCore import QMutex

log_mutex = QMutex()

def log(instance, message, level=Qgis.Info):
    """
    QGis 로그 메시지 패널에 입력 메시지 표출
    :param instance: 해당 메시지를 호출한 instance
    :type instance: instance

    :param message: 로그 메시지
    :type message: str

    :param level: 메시지 레벨
    :type level: QgsMessageLog.(INFO|WARNING|CRITICAL)

    """
    caller_frame_record = inspect.stack()[1]    # 0 represents this line
                                              # 1 represents line at caller
    frame = caller_frame_record[0]
    info = inspect.getframeinfo(frame)
    '''
    QgsMessageLog.instance().logMessage(u'{0}-{1}@{2}:{3}'.format(type(instance).__name__,
                                                                  info.filename,
                                                                  info.lineno,
                                                                  message),
                                        const.PLUGIN_NAME,
                                        level)
    '''
    QgsMessageLog.logMessage(message = u'{0}:{1} - {2}'.format(type(instance).__name__, info.lineno, message),
                             tag = Const.get_instance().PLUGIN_NAME,
                             level = level)
    log_level = 'Info'

    if level == Qgis.Critical:
        log_level = 'Critical'
    elif level == Qgis.Warning:
        log_level = 'Warning'

    log_mutex.lock()
    print("[{0}] {1}".format(log_level, message))
    log_mutex.unlock()
