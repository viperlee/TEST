# -*- coding: utf-8 -*-
#
# class Singleton(object):
#     _instances = {}
#
#     def __new__(cls, *args, **kwargs):
#         if cls not in cls._instances:
#             cls._instances[cls] = super(Singleton, cls).__new__(cls, *args, **kwargs)
#         return cls._instances[cls]
#


class Singleton:
    __instance = None

    @classmethod
    def __getInstance(cls):
        return cls.__instance

    @classmethod
    def get_instance(cls, *args, **kwargs):
        cls.__instance = cls(*args, **kwargs)
        cls.get_instance = cls.__getInstance
        return cls.__instance

    @classmethod
    def drop_instance(cls):
        if cls.__instance is not None:
            del cls.__instance
            cls.__instance = None
