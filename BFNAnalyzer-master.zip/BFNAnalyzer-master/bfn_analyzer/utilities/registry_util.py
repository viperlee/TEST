# -*- coding: utf-8 -*-
import winreg as _winreg
from .patterns import *
from ..Const import *


class ResgistryUtil(Singleton):
    def __init__(self):
        self.const = Const.get_instance()
        self.reg_key = _winreg.CreateKey(_winreg.HKEY_CURRENT_USER, self.const.REGISTRY_KEY)

    def set_value(self, sub_key, value, group=None, value_type=None):
        if group:
            reg_key = _winreg.CreateKey(_winreg.HKEY_CURRENT_USER, self.const.REGISTRY_KEY + '\\' + group)
        else:
            reg_key = self.reg_key

        if value_type is int:
            _winreg.SetValueEx(reg_key, sub_key, 0, _winreg.REG_DWORD, value)
        else:
            _winreg.SetValueEx(reg_key, sub_key, 0, _winreg.REG_SZ,  u"{0}".format(value))

        if group:
            reg_key.Close()

    def get_value(self, sub_key, group=None, value_type=None):
        value = ""
        if group:
            reg_key = _winreg.CreateKey(_winreg.HKEY_CURRENT_USER, self.const.REGISTRY_KEY + '\\' + group)
        else:
            reg_key = self.reg_key

        try:
            value, reg_type = _winreg.QueryValueEx(reg_key, sub_key)
        except:
            if value_type is int:
                value = 0
            self.set_value(sub_key, value, group, value_type)

        if group:
            reg_key.Close()

        return value

    def get_all_values(self, group=None):
        sub_keys = list()
        if group:
            reg_key = _winreg.CreateKey(_winreg.HKEY_CURRENT_USER, self.const.REGISTRY_KEY + '\\' + group)
        else:
            reg_key = self.reg_key

        try:
            i = 0
            while 1:
                sub_key, value, reg_type = _winreg.EnumValue(reg_key, i)
                sub_keys.append([sub_key, value])
                i += 1
        except:
            pass

        if group:
            reg_key.Close()

        return sub_keys

    def __del__(self):
        self.reg_key.Close()

