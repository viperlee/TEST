# -*- coding: utf-8 -*-
import time
import math
import tempfile

from PyQt5.QtCore import QObject, pyqtSignal, QThread, QDate, QDateTime
try:
    from PyQt5.QtCore import QPyNullVariant
except:
    pass

try:
    from qgis.core import NULL
except:
    pass
from bfn_analyzer.Const import *


class EventSenderReceiver(QObject):
    """
    event를 주고 받고 위한 class
    """
    _instances = {}
    selection_type_changed = pyqtSignal(int)

    def __new__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(EventSenderReceiver, cls).__new__(cls, *args, **kwargs)
        return cls._instances[cls]

    def __init__(self, plugin_dir=None):
        try:
            if self.bInitialized:
                pass
        except:
            QObject.__init__(self)
            self.bInitialized = True

    def set_selection_type(self, selection_type):
        self.selection_type_changed.emit(selection_type)

    def connect_selection_type(self, selection_type_function):
        self.selection_type_changed.connect(selection_type_function)


class SleepAsync(QThread):

    def __init__(self, sleep_time, callback_function):
        QThread.__init__(self, None)
        self.sleep_time = sleep_time
        self.connect(self, SIGNAL("finished()"), callback_function)
        self.connect(self, SIGNAL("terminated()"), callback_function)
        self.start()

    def run(self):
        time.sleep(self.sleep_time)


def get_point_with_angle(geo_point_of_circle, radius, angle, is_reverse=False):
    """
    중심점, 길이, 각도로 포인트의 회전된 좌표를 구한다

    북쪽이 0도 인 각도, 시계 방향으로 내려오면서 각이 올라간다.
    예시)
     radius가 100일 경우
     (0, 0) 에서 0도일 때, (0, 100)
     (0, 0) 에서 90도일 때, (100, 0)

    reverse_angle은 동쪽이 0도 이다.:
     (0, 0) 에서 0도일 때, (100, 0)
     (0, 0) 에서 90도일 때, (0, 100)

    :param geo_point_of_circle: 중심점
    :type  geo_point_of_circle: x(), y() 함수를 가지는 Point Class
    :param radius: 반지름
    :type  radius: double
    :param angle: 각도(degree)
    :type  angle: double
    :param is_reverse: 정방향 역방향 구분
    :type  is_reverse: bool
    :return: 회전된 좌표의 위치
    :rtype: geo_point_of_circle 와 동일한 타입
    """
    point_type = type(geo_point_of_circle)
    radian = angle * 3.1415926535 / 180
    if is_reverse:
        reverse_angle = angle
        if angle < 0:
            angle += 360
        if angle > 360:
            angle -= 360
        reverse_angle = 90 - reverse_angle
        radian = reverse_angle * math.pi / 180
    x2 = geo_point_of_circle.x() + radius * math.sin(radian)
    y2 = geo_point_of_circle.y() + radius * math.cos(radian)
    return point_type(x2, y2)


def is_right_side(start_angle, end_angle, input_angle):
    """
    두개의 직선 각도가 있을때, 입력각도가 우측에 있는지 좌측에 있는지 확인

    :param start_angle: 시작각도
    :param end_angle: 끝각도
    :param input_angle: 입력각도
    :type start_angle: double
    :type end_angle: double
    :type input_angle: double
    :return: True:우측, False:좌측
    :rtype: bool
    """

    start_angle = correction_angle(start_angle)
    end_angle = correction_angle(end_angle)
    input_angle = correction_angle(input_angle)

    diff_angle = 360 - start_angle
    start_angle += diff_angle
    end_angle += diff_angle
    input_angle += diff_angle

    start_angle = correction_angle(start_angle)
    end_angle = correction_angle(end_angle)
    input_angle = correction_angle(input_angle)

    if input_angle > 180:
        return True

    return False


def correction_angle(angle):
    """
    angle의 범위를 0~360 범위로 변경한다

    :param angle: 입력각도
    :type angle: double
    :return: 보정된 각도
    :rtype: double
    """

    if angle < 0:
        angle = correction_angle(angle + 360)
    if angle >= 360:
        angle = correction_angle(angle - 360)
    return angle


def find_angle(center_point, target_point, add_angle=0, is_reverse=False):
    """
    Cetner Point르 기준으로 Target Point의 각도를 구한다.
    Center Point(0, 0), Target Point(0, 100)일 경우, 결과는 90 Degree
    Center Point(0, 0), Target Point(100, 0)일 경우, 결과는 0 Degree
    일반적인 2차원 좌표계에서의 좌표이다. (시계 반대방향으로 각도가 더해진다.)

    is_reverse 인경우, 북쪽이 0도이고 시계방향으로 각도가 더해진다.

     add_angle은 계산값에서 결과값의 값을 추가하고싶을때 사용.

    :param center_point:
    :type center_point: QgsPoint
    :param target_point:
    :type target_point: QgsPoint
    :param add_angle:
    :type add_angle: float
    :param is_reverse:
    :type is_reverse: bool
    :return:
    :rtype: float
    """

    xdf = target_point.x() - center_point.x()
    ydf = target_point.y() - center_point.y()
    angle = find_zero_point_angle(ydf, xdf)
    if is_reverse:
        reverse_angle = angle
        if reverse_angle < 0:
            reverse_angle += 360
        if reverse_angle > 360:
            reverse_angle -= 360
        angle = 90 - reverse_angle

    angle += add_angle
    if angle < 0:
        angle += 360
    if angle > 360:
        angle -= 360
    return angle


def find_zero_point_angle(x, y):
    return math.atan2(y, x) * 180 / 3.1415926535


def is_null(value):
    if value is None:
        return True
    try:
        if isinstance(value, QPyNullVariant):
            return True
        if value is QPyNullVariant:
            return True
        if type(value) is QPyNullVariant:
            return True
    except:
        pass
    try:
        if value == NULL:
            return True
    except:
        pass
    return False


def null_to_empty_str(value, empty_str=''):
    return empty_str if is_null(value) else value


def null_to_zero(value):
    return 0 if is_null(value) else value


def to_string(value):
    if isinstance(value, QDate) or isinstance(value, QDateTime):
        return value.toString('yyyy-MM-dd')
    if is_null(value):
        return u''
    return unicode(value)


def get_inside_angle(prev, center, after):
    azimuth_prev = center.azimuth(prev)
    azimuth_after = center.azimuth(after)

    if azimuth_prev > azimuth_after:
        azimuth_diff = azimuth_prev - azimuth_after
    else:
        azimuth_diff = azimuth_after - azimuth_prev
    if azimuth_diff > 180:
        azimuth_diff = abs(azimuth_diff - 360)
    return azimuth_diff


def diff_angle(a1, a2):
    a1 = correction_angle(a1)
    a2 = correction_angle(a2)
    return 180 - abs(abs(a1 - a2) - 180)


def check_sharpness(geom, angle_tolerance=50):
    sharp_vertex_index_list = list()
    for v_idx in range(1, len(geom.asPolyline())-1):
        if get_inside_angle(geom.asPolyline()[v_idx-1], geom.asPolyline()[v_idx], geom.asPolyline()[v_idx+1]) < angle_tolerance:
            sharp_vertex_index_list.append(v_idx)
    return sharp_vertex_index_list


def to_geom_str(g):
    type_string = u''
    geom_item = None
    if g.type() == 0:
        if g.isMultipart():
            type_string += u'MultiPoint'
            geom_item = g.asMultiPoint()
        else:
            type_string += u'Point'
            geom_item = g.asPoint()
    elif g.type() == 1:
        if g.isMultipart():
            type_string += u'MultiLine'
            geom_item = g.asMultiPolyline()
        else:
            type_string += u'Line'
            geom_item = g.asPolyline()
    elif g.type() == 2:
        if g.isMultipart():
            type_string += u'MultiPolygne'
            geom_item = g.asMultiPolygon()
        else:
            type_string += u'Polygon'
            geom_item = g.asPolygon()
    elif g.type() == 3:
        type_string += u'UnkownGeometry'
    else:
        type_string += u'NoGeometry'

    geom_str = u''
    if geom_item is not None:
        geom_str = to_str(geom_item)

    return type_string, geom_str


def to_str(item):
    pstr = u''
    if type(item) is list or type(item) is tuple:
        pstr += u'['
        idx = 0
        item_size = len(item)
        for child_item in item:
            pstr += to_str(child_item)
            idx += 1
            if idx < item_size:
                pstr += u', '
        pstr += u']'
    else:
        pstr += u'({0}, {1})'.format(item.x(), item.y())

    return pstr


def slen(text_string):
    """
    한글2바이트(euc_kr, cp949) 기준으로 문자열 길이 반환
    납품 데이터 전용
    """
    str_len = 0
    for s in text_string:
        str_len += 1 if ord(s) < 256 else 2
    return str_len


def scut(text_string, cut_size):
    """
    한글2바이트(euc_kr, cp949) 기준으로 문자열 길이 만큼 text 자름
    납품 데이터 전용
    :return:
    """
    new_str = u''
    str_len = 0
    for s in text_string:
        str_len += 1 if ord(s) < 256 else 2
        if str_len <= cut_size:
            new_str += s
        else:
            break
    return new_str


def clear_layout(layout, remove_idx=None):
    """
    Qt layout의 하위 widget을 삭제 한다.
    :param layout:
    :param remove_idx: 삭제할 위젯의 index, None일 경우 전체 삭제, int일 경우는 해당 index, list일 경우 list index
    """
    cnt = layout.count()
    range_info = range(cnt - 1, -1, -1)
    if remove_idx is not None:
        if type(remove_idx) is list or type(remove_idx) is tuple:
            range_info = remove_idx
        elif type(remove_idx) is int or type(remove_idx) is long:
            range_info = [remove_idx]

    for idx in range_info:
        if layout is None:
            break
        item = layout.takeAt(idx)
        if item is None:
            continue
        widget = item.widget()
        if widget is not None:
            layout = widget.layout()
            if layout is not None:
                clear_layout(layout)
            widget.deleteLater()
        else:
            child_layout = item.layout()
            if child_layout is not None:
                clear_layout(child_layout)
        del item


def connect_event(event_list):
    for evt, func in event_list:
        try:
            evt.connect(func)
        except:
            pass


def disconnect_event(event_list):
    for evt, func in event_list:
        try:
            evt.disconnect(func)
        except:
            pass

def get_temporary_file_name(type_str, ext_name):
    const = Const.get_instance()
    return u'{0}\\{1}_{2}.{3}'.format(tempfile.gettempdir(), const.PLUGIN_SIMPLE_NAME, type_str, ext_name)

def write_file(file_path, file_data):
    """
    디스크에 파일을 쓴다.

    :param file_path:
    :param file_data:
    :return:
    """
    file = open(file_path, 'w')
    for bin_data in file_data:
        file.write(bin_data)
    file.close()


class MddIndex:
    def __init__(self):
        self.__start_idx = -1
        self.__end_idx = -1
        self.__curr_idx = -1

    def set_range(self, start_idx, end_idx):
        self.__start_idx = start_idx
        self.__end_idx = end_idx
        self.__curr_index = start_idx

    def set_current(self, idx):
        self.__curr_index = idx

    def current(self):
        return self.__curr_index

    def next(self):
        cur_idx = self.__curr_index
        self.__curr_index += 1
        return cur_idx

