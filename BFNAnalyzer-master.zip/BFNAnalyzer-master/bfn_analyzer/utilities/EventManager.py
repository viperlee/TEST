# -*- coding: utf-8 -*-
from .patterns import Singleton
from .log import *
from .enumeration import *


class EventManager(Singleton):
    def __init__(self):
        self.event_list = dict()
        pass

    def __del__(self):
        pass

    def connect_event(event_list):
        for evt, func in event_list:
            try:
                evt.connect(func)
            except:
                pass

    def disconnect_event(event_list):
        for evt, func in event_list:
            try:
                evt.disconnect(func)
            except:
                pass


