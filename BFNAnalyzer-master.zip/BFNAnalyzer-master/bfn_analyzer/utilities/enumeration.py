
"""
enumermation
Numbers = enum('ZERO', 'ONE', 'TWO')
Numbers.ONE  => 1
Numbers.reverse_mapping[1] => 'ONE'
"""
def enum(*sequential, **named):
    enums = dict(zip(sequential, range(len(sequential))), **named)
    reverse = dict((value, key) for key, value in enums.items())
    enums['reverse_mapping'] = reverse
    return type('Enum', (), enums)
