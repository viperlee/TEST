# -*- coding: utf-8 -*-
from ..FeatureAttributeController import *
from ..MdaFeature import *
from bfn_analyzer.Const import Const


class SwlPipeLmFeature(MdaFeature):
    """
    SwlPipeLmFeature
    """
    def __init__(self):
        MdaFeature.__init__(self)

    def auto_update(self):
        """
        속성값 자동으로 업데이트
        :return:
        """
        attr_idx = self.get_attribute_index_map()
        attr = self.attributes()

        self.set_attribute_values(attr)

    def copy_attributes(self, feature):
        attr_idx = self.get_attribute_index_map()
        cur_attributes = self.attributes()
        if isinstance(feature, self):
            new_attributes = feature.attributes()
        elif isinstance(feature, list):
            new_attributes = feature
        else:
            return

        for idx in [attr_idx.mid, attr_idx.mesh, attr_idx.feature_id]:
            new_attributes[idx] = cur_attributes[idx]

        self.set_attribute_values(new_attributes)

    def set_default_attributes(self):
        attr_idx = self.get_attribute_index_map()
        attr = self.attributes()
        self.set_attribute_values(attr)

    def get_id(self):
        attr_idx = self.get_attribute_index_map()
        return self.get_attribute_value(attr_idx.mid)

    def set_id(self, id):
        attr_idx = self.get_attribute_index_map()
        self.set_attribute_value(attr_idx.mid, id)

    def update_mid(self):
        return False

    def get_layer_name(self):
        const = Const.get_instance()
        return const.LAYER_NAME_PIPE_LINK

