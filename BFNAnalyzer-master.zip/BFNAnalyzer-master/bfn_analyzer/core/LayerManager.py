# -*- coding: utf-8 -*-
import inspect
from qgis.utils import iface
from qgis.core import *
from PyQt5.QtCore import QDateTime
from PyQt5.QtSql import QSqlError
from PyQt5.QtCore import pyqtSignal
from PyQt5.Qt import QObject
from PyQt5.QtCore import QMutex

from bfn_analyzer.utilities.DbManager import DbManager
from bfn_analyzer.utilities.patterns import Singleton
from bfn_analyzer.utilities.enumeration import *
from bfn_analyzer.utilities.log import log
from bfn_analyzer.utilities.util_etc import *
from bfn_analyzer.Const import Const

from .MdaVectorLayer import *
from .FeatureAttributeController import *


class LayerManager(Singleton, QObject):
    """
    레이어 관리자
    """
    def __init__(self):
        QObject.__init__(self)
        self.layers = {}
        self.layer_infos = list()

    def __del__(self):
        self.remove_layers()

    def get_load_layer_list_from_db(self):
        const = Const.get_instance()
        db_manager = DbManager.get_instance()
        if not db_manager.common_db_uri:
            return
        option = DbOptions()
        option.result_type = 1
        sql = "select group_name, table_name, geom_field from {0} where group_name > '' order by group_name, layer_order".format(const.TABLE_NAME_USER_STYLE)
        ret, results = db_manager.execute_sql(db_manager.common_db_uri, sql, option)
        if not ret:
            return

        return results

    def get_layer(self, layer_name):
        """
        Get Layers from layer's name
        :param layer_name:
        :return:
        """
        if isinstance(layer_name, str) or isinstance(layer_name, unicode):
            if layer_name in self.layers:
                return self.layers[layer_name]
        elif isinstance(layer_name, MdaFeature):
            layer_type = self.get_layer_type(layer_name)
            return self.get_layer(layer_type)
        elif isinstance(layer_name, type):
            for layer in self.layers.values():
                if layer_name is type(layer):
                    return layer
        return None

    def start_editing_all(self):
        """
        모든 Layer 편집 모드로 전환.
        """
        # 모든 Layer 편집 모드로 전환.
        for idx in range(0, self.layer_idx.END):
            layer = self.get_layer(self.layer_idx.reverse_mapping[idx])
            if not layer.name() in self.not_edit_layers:
                layer.startEditing()

    def remove_layers(self):
        # Layer Remove
        self.layers.clear()
        self.layer_infos.clear()

    def load_layers(self):
        """
        네트워크를 구성하는 layer를 각 class에 맞게 db에서 로딩
        :return:
        """

        self.remove_layers()
        iface.mapCanvas().setRenderFlag(False)
        db_manager = DbManager.get_instance()
        self.layer_infos = list()
        layer_styles = dict()
        for group_name, layer_name, geom_field in self.get_load_layer_list_from_db():
            style_file_name, order_idx, view_check = self.download_layer_style(layer_name)
            layer_styles[layer_name] = style_file_name
            self.layer_infos.append([group_name, layer_name, geom_field, order_idx, view_check])

        self.layer_infos.sort(key=lambda info:int(info[3]))
        db_uri = db_manager.get_current_db_info()
        for group_name, layer_name, geom_field, order_idx, view_check in self.layer_infos:
            db_uri.setDataSource("public", layer_name, geom_field)
            layer = self.make_layers(db_uri, layer_name)  # type: MdaVectorLayer
            if not layer:
                continue

            log(self, 'Layer load success: {0}'.format(layer_name))

            style_file_name = layer_styles[layer_name]
            if style_file_name is not None:
                layer.loadNamedStyle(style_file_name)

            self.layers[layer_name] = layer
        # self.start_editing_all()
        return True

    def make_layers(self, db_uri, layer_name):
        # layer = self.get_layer_type(layer_name)(db_uri.uri(), layer_name, "postgres")  # type: MdaVectorLayer
        layer = MdaVectorLayer(db_uri.uri(), layer_name, "postgres")  # type: MdaVectorLayer
        if not layer.isValid():
            log(self, 'Layer failed to load: {0}'.format(layer_name))
            return None
        attribute_idx_map = FeatureAttributeController.get_instance()
        attr_idx = attribute_idx_map.create_attribute_index(layer)
        attr_type = attribute_idx_map.create_attribute_type(layer)
        layer.attr_idx = attr_idx
        layer.attr_type = attr_type
        attribute_idx_map.add_attribute_index_map(layer, attr_idx)
        attribute_idx_map.add_attribute_index_map(self.get_feature_type(layer_name), attr_idx)
        attribute_idx_map.add_attribute_type_map(layer, attr_type)
        attribute_idx_map.add_attribute_type_map(self.get_feature_type(layer_name), attr_type)
        return layer

    def set_z_value(self, feature):
        """
        feature에 z value 추가 하는 함수
        :return:
        """
        if not isinstance(feature, QgsFeature):
            log(self, 'set_z_value() does not support feature: $s' % (type(feature)), QgsMessageLog.CRITICAL)
            return None
        geom = feature.geometry()

        # geometry가 없는 feature의 경우 처리
        if not geom:
            return

        geom_v2 = geom.geometry()
        geom_v2.addZValue(0)

        if isinstance(geom_v2, QgsPointV2):
            z_value = self.get_z_value(geom_v2.x(), geom_v2.y())
            geom_v2.setZ(z_value)
        elif isinstance(geom_v2, QgsLineStringV2):
            for idx_vertex in range(0, geom_v2.vertexCount()):
                point_v2 = geom_v2.pointN(idx_vertex)
                z_value = self.get_z_value(point_v2.x(), point_v2.y())
                geom_v2.setZAt(idx_vertex, z_value)
        else:
            log(self, 'set_z_value() does not support type(%s, %s)' % (type(geom), type(geom_v2)),
                QgsMessageLog.CRITICAL)
            return

        feature.setGeometry(geom)

    def get_z_value(self, x, y):
        """
        x, y 좌표에 대한 z값을 반환하는 함수
        :param x:
        :param y:
        :return:
        """
        return 0

    def get_selected_features(self, layer_names=None):
        if not layer_names:
            layer_names = [self.layer_idx.reverse_mapping[idx] for idx in range(0, self.layer_idx.END)]
        elif isinstance(layer_names, list):
            pass
        else:
            layer_names = [layer_names]

        layer_fts = dict()
        for layer_name in layer_names:
            layer = self.get_layer(layer_name)
            if not layer:
                continue

            fts = layer.get_selected_features()
            layer_fts[layer_name] = fts

        return layer_fts

    def get_feature_type(self, layer_name):
        if isinstance(layer_name, MdaVectorLayer):
            return self.get_feature_type(type(layer_name))
        elif isinstance(layer_name, str):
            for layer in self.layers.values():
                if layer.name() == layer_name:
                    return layer.get_feature_type()
        elif isinstance(layer_name, type):
            return layer_name().get_feature_type()

    def get_nearby_features(self, layer_name, center_point, dist):
        if isinstance(center_point, QgsGeometry):
            pass
        elif isinstance(center_point, QgsPoint):
            center_point = QgsGeometry.fromPoint(center_point)
        else:
            return None
        rect = center_point.buffer(dist, 2).boundingBox()
        return self.get_features_in_rect(rect, layer_name)

    def get_features_in_rect(self, rect, layer_names=None):
        if not layer_names:
            layer_names = [self.layer_idx.reverse_mapping[idx] for idx in range(0, self.layer_idx.END)]
        elif isinstance(layer_names, list):
            pass
        else:
            layer_names = [layer_names]

        layer_fts = dict()
        for layer_name in layer_names:
            layer = self.get_layer(layer_name)
            if not layer:
                layer_fts[layer_name] = None
                continue
            fts = layer.get_features_in_rect(rect)
            layer_fts[layer_name] = fts

        # print 'rect in m = ', rect.xMinimum(), rect.yMinimum(), rect.xMaximum(), rect.yMaximum()
        return layer_fts

    def check_feature_type(self, feature, layer_condition):
        """
        feature와 layer가 일치하는지 확인
        :param feature: MddFeature type
        :param layer_condition: Layer 명칭, Layer Class 등
        :return: True = 일치, False = 불일치
        """
        layer_type = self.get_feature_type(type(layer_condition))
        return isinstance(feature, layer_type)

    # style 처리
    def load_style(self, layer_name):
        layer = self.get_layer(layer_name)
        style_file_name, order_idx, view_check = self.download_layer_style(layer_name)
        if style_file_name is not None:
            layer.loadNamedStyle(style_file_name)
            # root = QgsProject.instance().layerTreeRoot()  # type: QgsLayerTreeGroup
            # layer_tree = root.findLayer(layer.id())  # type: QgsLayerTreeLayer
            # if layer_tree is not None:
            #     layer_tree.setVisible(2 if view_check == 1 else 0)

    def download_layer_style(self, layer_name):
        """
        Vector layer의 style을 db로 부터 다운받는다.

        :param layer_name: Layer 명칭
        :type layer_name: str
        :return: 임시폴더에 저장된 파일 명칭
        :rtype: str
        """
        my_data = None
        order_idx = 999
        view_check = 0
        db_manager = DbManager.get_instance()  # type: DbManager
        const = Const.get_instance()
        qry = u"SELECT style_data, layer_order, view_check FROM {0} WHERE table_name = '{1}'"
        qry = qry.format(const.TABLE_NAME_USER_STYLE, layer_name)
        ret, results = db_manager.execute_sql(db_manager.get_common_db_info(), qry, ExecuteType.SELECT)

        if not results:
            return None, order_idx, view_check

        for row in results:
            my_data = row[0]
            order_idx = row[1]
            view_check = row[2]

        if my_data is not None:
            file_path = get_temporary_file_name(layer_name, 'qml')
            write_file(file_path, my_data)
            return file_path, order_idx, view_check

        return None, order_idx, view_check

    def upload_layer_style(self, group_name, layer_name, view_check, order_idx):
        """
        layer style을 DB에 업로드 한다.

        :param tool_type_str:
        :param layer_name:
        :param old_style_name:
        :param style_name:
        :param view_check:
        :param order_idx:
        :param is_common_user:
        :return:
        """
        file_path = get_temporary_file_name(layer_name, 'qml')
        if not os.path.exists(file_path):
            return None

        const = Const.get_instance()
        db_manager = DbManager.get_instance()  # type: DbManager
        file = open(file_path, 'r')
        qry = u"INSERT INTO {0}(style_data, group_name, table_name, geom_field, layer_order, view_check) VALUES ('{1}', '{2}', '{3}', 'geom', {4}, {5})"

        style_file_string_data = file.read()
        # print (style_file_string_data)
        # style_file_data = psycopg2.Binary(style_file_string_data)
        qry = qry.format(const.TABLE_NAME_USER_STYLE, style_file_string_data.replace("'","''"), group_name, layer_name, order_idx, view_check)
        db_manager.execute_sql(db_manager.get_common_db_info(), qry, ExecuteType.EXECUTE)
