# -*- coding: utf-8 -*-
from PyQt5 import QtCore
from PyQt5.QtCore import QDateTime
from qgis.core import QgsPoint, QgsFeature, QgsGeometry

from bfn_analyzer.utilities.log import *
from bfn_analyzer.utilities.util_etc import is_null
from .FeatureAttributeController import *


class MdaFeature(QgsFeature):
    def __init__(self):
        QgsFeature.__init__(self)
        self.is_changed_attributes = False

    @staticmethod
    def convert(feature, class_type):
        """
        변환 함수
        :param feature:
        :param class_type:
        :type feature: MddFeature
        :type class_type: type(MddFeature)
        """
        feature.__class__ = class_type
        feature.is_changed_attributes = False

    @staticmethod
    def cast_value(value, value_type):
        if value_type is long:
            if is_null(value):
                value = 0
            elif type(value) is str or type(value) is unicode:
                if value.isdigit():
                    value = long(value)
                else:
                    value = 0
        elif value_type is str:
            if is_null(value):
                value = QtCore.QPyNullVariant(str)
            elif type(value) is str and value == '':
                value = QtCore.QPyNullVariant(str)
            elif type(value) is unicode and value == u'':
                value = QtCore.QPyNullVariant(str)
            elif type(value) is long or type(value) is int:
                value = str(value)

        return value

    def check_base_info(self):
        raise NotImplementedError

    def auto_update(self):
        """
        속성값 자동으로 업데이트
        :return:
        """
        pass

    def get_mesh_id(self):
        """
        도엽 id 반환
        :return:
        :type: str
        """
        attr_idx = self.get_attribute_index_map()
        try:
            return self.get_attribute_value(attr_idx.mesh)
        except:
            return 0

    def set_mesh_id(self, mesh_id):
        attr_idx = self.get_attribute_index_map()
        try:
            self.set_attribute_value(attr_idx.mesh, mesh_id)
        except:
            pass

    def get_mid(self):
        """

        :return:
        :type: integer
        """
        attr_idx = self.get_attribute_index_map()
        try:
            return self.get_attribute_value(attr_idx.mid)
        except:
            return None

    def set_mid(self, mid):
        attr_idx = self.get_attribute_index_map()
        try:
            self.set_attribute_value(attr_idx.mid, mid)
        except:
            pass

    def update_mid(self):
        raise NotImplementedError

    def get_id(self):
        raise NotImplementedError

    def set_id(self, id):
        raise NotImplementedError

    def get_editcode(self):
        attr_idx = self.get_attribute_index_map()
        try:
            editcode = self.get_attribute_value(attr_idx.editcode)
            if type(editcode) is str or type(editcode) is unicode:
                return editcode.upper()
            return ''
        except:
            return ''

    def is_deleted(self):
        attr_idx = self.get_attribute_index_map()
        try:
            editcode = self.get_attribute_value(attr_idx.editcode)
            if type(editcode) is str or type(editcode) is unicode:
                return editcode == 'D'
            return False
        except:
            return False

    def set_editcode(self, editcode):
        attr_idx = self.get_attribute_index_map()
        try:
            self.set_attribute_value(attr_idx.editcode, editcode.upper())
        except:
            pass

    def get_edit_info(self):
        attr_idx = self.get_attribute_index_map()
        try:
            return self.get_attribute_value([attr_idx.editcode, attr_idx.edituser, attr_idx.editdate])
        except:
            return None

    def set_edit_info(self, editcode, edituser, editdate=None):
        attr_idx = self.get_attribute_index_map()
        try:
            self.set_attribute_value(attr_idx.editcode, editcode)
            self.set_attribute_value(attr_idx.edituser, edituser)
            if not editdate:
                editdate = QDateTime.currentDateTime()
            self.set_attribute_value(attr_idx.editdate, editdate)
            if editcode == 'A':
                self.set_attribute_value(attr_idx.editdate_s, editdate)
        except:
            pass

    # def set_check_info(self, chkcode, chkuser, chkdate=None):
    #     attr_idx = self.get_attribute_index_map()
    #     self.set_attribute_value(attr_idx.chkcode, chkcode)
    #     # self.set_attribute_value(attr_idx.edituser, chkuser)
    #     if not chkdate:
    #         chkdate = str(datetime.datetime.now())
    #     self.set_attribute_value(attr_idx.chkdate, chkdate)

    def get_attribute_value(self, index):
        """
        속성 인덱스에 대한 속성 값을 반환
        :param index: feature's attribute index or name, list of feature's index or name
        :type: index: integer, str, list of integer, list of str

        :return: feature's attribute value
        :type: list or value
        """

        try:
            if type(index) is list:
                return [self.get_attribute_value(idx) for idx in index]
            elif type(index) is int or type(index) is long:
                value = self.attributes()[index]
                if is_null(value):
                    value = None
                attr_type = self.get_attribute_type_map()
                value = self.cast_value(value, attr_type[index])
                return value

            elif type(index) is str:
                idx = self.fieldNameIndex(index)
                return self.get_attribute_value(idx)
            elif index is None:
                # 의도적으로 None값을 넣고 결과도 None으로 반환한다.
                return None
        except IndexError:
            log(self, 'attribute index was invalid(%s:%s)' % (type(self), index), Qgis.critical)

    def set_attribute_value(self, index, value):
        attr_type = self.get_attribute_type_map()
        if type(index) is str:
            index = self.fieldNameIndex(index)

        if type(index) is int or type(index) is long:
            value = self.cast_value(value, attr_type[index])
        else:
            log(self, 'set attribute value failed, attribute index error')
            return
        self.setAttribute(index, value)

    def set_attribute_values(self, values):
        attr_type = self.get_attribute_type_map()
        for index in range(0, len(values)):
            values[index] = self.cast_value(values[index], attr_type[index])
            self.setAttribute(index, values[index])
        # self.setAttributes(values)

    def copy_attributes(self, feature):
        raise NotImplementedError

    def get_start_vertex(self):
        """
        feature의 시점 vertex를 구하는 함수
        :return:  시점 vertex
        :type: list of QgsPoint
        """
        return self.get_vertex(0)

    def get_end_vertex(self):
        """
        feature의 종점 vertex를 구하는 함수
        :return:  종점 vertex
        :type: list of QgsPoint
        """
        return self.get_vertex(-1)

    def get_vertex(self, start_idx, end_idx=None):
        """
        인덱스에 해당하는 feature의 vertex를 구하는 함수
        :return:  vertex about index
        :type: list of QgsPoint
        """
        point_list = list()
        if not end_idx:
            if not -1 <= start_idx < self.geometry().geometry().vertexCount():
                vertex_count = self.geometry().geometry().vertexCount()
                log(self, 'vertex index is invalid(%s/%s)' % (start_idx, vertex_count), Qgis.critical)
                return []
            elif start_idx == -1:
                point_2d = self.geometry().vertexAt(self.geometry().geometry().vertexCount() - 1)
            else:
                point_2d = self.geometry().vertexAt(start_idx)
            point_list.append(point_2d)
            return point_list
        else:
            if not (-1 <= start_idx < self.geometry().geometry().vertexCount()
                    and -1 <= end_idx < self.geometry().geometry().vertexCount()):
                vertex_count = self.geometry().geometry().vertexCount()
                log(self, 'vertex index is invalid(%s/%s)' % (start_idx, end_idx, vertex_count), Qgis.critical)
                return []
            if start_idx == -1:
                start_idx = self.geometry().geometry().vertexCount() - 1
            if end_idx == -1:
                end_idx = self.geometry().geometry().vertexCount() - 1

            if start_idx > end_idx:
                return []
            elif start_idx == end_idx:
                return self.get_vertex(start_idx)
            else:
                for idx in range(start_idx, end_idx + 1):
                    point_2d = self.geometry().vertexAt(idx)
                    point_list.append(point_2d)
                return point_list

    def get_attribute_index_map(self):
        attribute_idx_map = FeatureAttributeController.get_instance()
        return attribute_idx_map.get_attribute_index_map(type(self))

    def get_attribute_type_map(self):
        attribute_idx_map = FeatureAttributeController.get_instance()
        return attribute_idx_map.get_attribute_type_map(type(self))

    def check_close_vertex(self):
        """
        Geometry가 LineString 일 경우 근접 Vertex 여부를 확인한다.
        :return: True = 근접 Vertex 있음, False = 근접 Vertex 없음
        """
        geom = self.geometry()  # type: QgsGeometry
        if geom.type() != 1:  # Line String
            return

        geom_v2 = geom.geometry()  # type: QgsAbstractGeometryV2
        if geom_v2 is None:
            return False

        vertex_count = geom_v2.vertexCount()

        last_qpoint = None  # type: QgsPoint
        for vertex_idx in range(vertex_count):
            qpoint = geom.vertexAt(vertex_idx)  # type: QgsPoint
            if last_qpoint is None:
                last_qpoint = qpoint
                continue
            dist = last_qpoint.sqrDist(qpoint)
            if dist < 1:  # 아마 1미터
                return True
            last_qpoint = qpoint
        return False

    def get_layer_name(self):
        raise NotImplemented