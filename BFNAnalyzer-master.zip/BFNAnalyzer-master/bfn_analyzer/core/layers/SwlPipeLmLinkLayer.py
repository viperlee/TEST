# -*- coding: utf-8 -*-
from qgis.core import QgsVectorLayer

from ..MdaVectorLayer import MdaVectorLayer
from ..features.SwlPipeLmFeature import *


class SwlPipeLmLayer(MdaVectorLayer):
    """
    SwlPipeLmLayer
    """
    def __init__(self, QString_path=None, QString_baseName=None, QString_providerLib=None, options=QgsVectorLayer.LayerOptions()): # real signature unknown; restored from __doc__
        MdaVectorLayer.__init__(self, QString_path, QString_baseName, QString_providerLib, options)
        pass

    def convert_feature(self, feature):
        SwlPipeLmFeature.convert(feature, SwlPipeLmFeature)
        return feature

    def get_feature_type(self):
        return SwlPipeLmFeature

    def get_new_id(self, mesh=None):
        get_new_id_sql = "select nextval('user_memo_mid_seq'::regclass);"

        results = self.execute_sql(get_new_id_sql)
        if len(results) == 0:
            max_id = 1
        else:
            max_id = results[0][0]

        return long(max_id)
