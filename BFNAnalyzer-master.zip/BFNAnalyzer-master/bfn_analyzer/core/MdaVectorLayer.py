# -*- coding: utf-8 -*-

import inspect

from qgis.core import QgsVectorLayer, QgsFeatureRequest, QgsDataSourceUri, QgsSpatialIndex, QgsRectangle, QgsGeometry, QgsPoint
from qgis.gui import QgsRubberBand
from qgis.utils import iface
from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QColor
from PyQt5.QtCore import QDate

from bfn_analyzer.utilities.enumeration import enum
from bfn_analyzer.utilities.DbManager import *
from .MdaFeature import *


class MdaVectorLayer(QgsVectorLayer):
    def __init__(self, QString_path=None, QString_baseName=None, QString_providerLib=None, options=QgsVectorLayer.LayerOptions()): # real signature unknown; restored from __doc__
        QgsVectorLayer.__init__(self, QString_path, QString_baseName, QString_providerLib, options)
        self.attr_idx = None
        self.attr_type = None
        self.spatial_idx = None
        self.spatial_idx_rect = None
        self.selected_feature_list = list()
        self.deleted_features = dict()
        self.rbDict = {}
        self.cache_features = dict()

    def __del__(self):
        pass

    def get_empty_feature(self, geom=None, attributes=None):
        feature = self.convert_feature(QgsFeature(self.fields(), 0))

        if attributes:
            feature.copy_attributes(attributes)
        else:
            feature.set_default_attributes()

        if geom:
            feature.setGeometry(geom)

        return feature

    def convert_feature(self, feature):
        raise NotImplementedError

    def get_selected_features(self):
        """
        """
        ids = self.selectedFeaturesIds()
        if len(ids) == 0:
            return []
        req = QgsFeatureRequest()
        req.setFilterFids(ids)
        ft_iter = self.getFeatures(req)
        return [self.convert_feature(ft) for ft in ft_iter]

    def set_attribute_index(self):
        """
        레이어의 각 필드인덱스를 enum으로 정의해주는 함수
        레이어를 생성 후 한번 셋팅하면 됨.
        :return: None
        """
        attr_list = self.attributeList()
        seq = ()
        named = {self.attributeDisplayName(idx): idx for idx in attr_list}
        self.attr_idx = enum(*seq, **named)

    def get_features_all(self):
        ft_iter = self.getFeatures()
        return [self.convert_feature(ft) for ft in ft_iter]

    def get_features_from_mid(self, mids):
        """
        Feature를 mid값 기준으로 가져오는 함수
        :param mids: mid, 혹은 mid list
        :return:
        """
        if isinstance(mids, list):
            return [self.get_features_from_mid(mid) for mid in mids]
            # # 멀티 Feature 직접 구현
            # req = QgsFeatureRequest()
            # req.setFilterFids(mids)
            # feature_list = list()
            # feature_iter = self.getFeatures(req)
            # for tmp_feature in feature_iter:
            #     feature_list.append(self.convert_feature(tmp_feature))
            # return feature_list
        elif isinstance(mids, long) or isinstance(mids, int):
            if mids in self.cache_features:
                # print 'cache hit!!'
                return self.cache_features[mids]
            # print 'cache no hit!!{0}:{1}'.format(self.name(), mids)
            req = QgsFeatureRequest()
            req.setFilterFid(mids)
            feature = QgsFeature()
            if self.getFeatures(req).nextFeature(feature):
                feature = self.convert_feature(feature)
                self.cache_features[feature.get_mid()] = feature
                return feature
            edit_buffer = self.editBuffer()
            if edit_buffer:
                for ft in edit_buffer.addedFeatures().values():
                    # print "find id {0}, feature_id : {1}".format(mids, ft.id())
                    if (mids < 0 and ft.id() == mids) or ft.attributes()[self.attr_idx.mid] == mids:
                        feature = self.convert_feature(ft)
                        self.cache_features[feature.get_mid()] = feature
                        return feature

            return None

    def get_attribute_types(self):
        attr_list = self.attributeList()
        fields = self.pendingFields()
        typed = dict()
        for idx in attr_list:
            field_type_name = fields[idx].typeName()
            if u'int' in field_type_name:
                typed[idx] = long
            elif u'float8' in field_type_name:
                typed[idx] = float
            elif u'numeric' in field_type_name:
                typed[idx] = long
            elif u'char' in field_type_name:
                typed[idx] = str
            elif u'text' in field_type_name:
                typed[idx] = str
            elif u'date' in field_type_name:
                typed[idx] = QDate
            elif u'geometry' in field_type_name:
                typed[idx] = QgsGeometry
            elif u'timestamp' in field_type_name:
                typed[idx] = QDate
            elif u'bool' in field_type_name:
                typed[idx] = long
            else:
                log(self, "unknown field type {0}".format(field_type_name), Qgis.critical)
                raise NotImplementedError
        return typed

    def get_features_from_expr(self, where_expr):
        if not where_expr:
            return

        uri = self.get_uri()
        table_name = uri.table()
        if where_expr.find('where') != -1:
            sql = 'select {0} from {1} {2}'.format(uri.keyColumn(), table_name, where_expr)
        else:
            sql = 'select {0} from {1} where {2}'.format(uri.keyColumn(), table_name, where_expr)
        rows = self.execute_sql(sql)
        if not rows:
            return []
        else:
            fts = list()
            for row in rows:
                ft = self.get_features_from_mid(row[0])
                if ft:
                    fts.append(ft)
            return fts

    def get_features_from_attributes(self, attributes):
        if self.attr_idx is None:
            return None

        expr_list = list()
        attr_type = self.get_attribute_types()
        for attr_idx, attr_val in attributes:
            if attr_type[attr_idx] == str or attr_type[attr_idx] == QDate:
                if isinstance(attr_val, list):
                    expr_list.append("{0} in ('{1}')".format(self.attributeDisplayName(attr_idx), "','".join(attr_val)))
                else:
                    expr_list.append("{0} ='{1}'".format(self.attributeDisplayName(attr_idx), attr_val))
            elif attr_type[attr_idx] == QgsGeometry:
                continue
            else:
                if isinstance(attr_val, list):
                    expr_list.append("{0} in ({1})".format(self.attributeDisplayName(attr_idx), ",".join([str(value) for value in attr_val])))
                else:
                    expr_list.append("{0} = {1}".format(self.attributeDisplayName(attr_idx), attr_val))

        if not expr_list:
            find_features = self.get_features_from_expr("mid > 0")
        else:
            expr = " and ".join(expr_list)
            find_features = self.get_features_from_expr(expr)
        eb = self.editBuffer()
        if not eb:
            pass
        else:
            # feature 추가 건
            added_features = eb.addedFeatures()
            for ft in added_features.values():
                is_match = True
                feature_attributes = ft.attributes()
                for attr_idx, attr_val in attributes:
                    if isinstance(attr_val, list):
                        if feature_attributes[attr_idx] not in attr_val:
                            is_match = False
                            break
                    else:
                        if feature_attributes[attr_idx] != attr_val:
                            is_match = False
                            break
                if is_match:
                    ft = self.get_features_from_mid(ft.id())
                    if ft is None:
                        log(self, u'Feature를 찾을 수 없음 ({0})'.format(ft.id()), u'{0}'.format(type(self)), Qgis.warning)
                    else:
                        find_features.append(ft)
            # attributes 변경 건
            changed_attributes = eb.changedAttributeValues()
            for feature_id in changed_attributes.keys():
                ft = self.get_features_from_mid(feature_id)
                if ft is None:
                    log(self, u'Feature를 찾을 수 없음 ({0})'.format(feature_id), u'{0}'.format(type(self)), Qgis.warning)
                    continue
                is_match = True
                feature_attributes = ft.attributes()
                for attr_idx, attr_val in attributes:
                    if isinstance(attr_val, list):
                        if feature_attributes[attr_idx] not in attr_val:
                            is_match = False
                            break
                    else:
                        if feature_attributes[attr_idx] != attr_val:
                            is_match = False
                            break
                if is_match:
                    if ft.get_mid() not in [find_feature.get_mid() for find_feature in find_features]:
                        find_features.append(ft)
                else:
                    for find_feature in find_features:
                        if ft.get_mid() == find_feature.get_mid():
                            find_features.remove(find_feature)
            # feature 삭제 건
            deleted_feature_ids = eb.deletedFeatureIds()
            if find_features and deleted_feature_ids:
                for find_feature in find_features:
                    if find_feature.id() in deleted_feature_ids:
                        find_features.remove(find_feature)
        return find_features

    def get_new_id(self, mesh_id=None):
        raise NotImplementedError

    def get_uri(self):
        provider = self.dataProvider()
        uri = QgsDataSourceUri(provider.dataSourceUri())
        return uri

    def execute_sql(self, sql, uri=None):
        if uri is None:
            uri = self.get_uri()
        db_manager = DbManager.get_instance()
        return db_manager.execute_sql(uri, sql)

    def renew_spatial_index(self):
        if not self.spatial_idx_rect:
            return
        self.insert_feature_to_spatial_index(self.spatial_idx_rect, True)

    def insert_feature_to_spatial_index(self, features=None, clear_all=False):
        if clear_all or self.spatial_idx is None:
            self.spatial_idx = QgsSpatialIndex()

        if not features:
            features = self.getFeatures()
            map(self.spatial_idx.insertFeature, features)
        elif isinstance(features, list):
            for feature in features:
                self.spatial_idx.insertFeature(feature)
        elif isinstance(features, QgsRectangle):
            self.spatial_idx_rect = features
            features = self.getFeatures(QgsFeatureRequest(features))
            map(self.spatial_idx.insertFeature, features)
        elif isinstance(features, MdaFeature):
            self.spatial_idx.insertFeature(features)
        else:
            return

    def delete_feature_to_spatial_index(self, features):
        if not self.spatial_idx:
            return
        elif isinstance(features, long):
            self.spatial_idx.deleteFeature(features)
        elif isinstance(features, list):
            for feature in features:
                self.spatial_idx.deleteFeature(feature)
        elif isinstance(features, MdaFeature):
            self.spatial_idx.deleteFeature(features)
        else:
            return

    def search_intersects_spatial_index(self, search_geom, tolerance=0):
        if self.spatial_idx:
            return None

        if isinstance(search_geom, QgsRectangle):
            rect = search_geom
        elif isinstance(search_geom, QgsPoint) and tolerance > 0:
            rect = QgsRectangle(search_geom.x() - tolerance, search_geom.y() - tolerance, search_geom.x() + tolerance, search_geom.y() + tolerance)
        elif isinstance(search_geom, QgsGeometry):
            rect = search_geom.boundingBox()
        else:
            return None

        features = list()
        for feature_id in self.spatial_idx.intersects(rect):
            feature = self.get_features_from_mid(feature_id)
            if feature:
                features.append(features)
        return features

    def get_nearest_feature_in_spatial_index(self, search_point, tolerance):
        min_dist_feature = None
        fids = self.spatial_idx.nearestNeighbor(search_point, 1)
        for fid in fids:
            feature = self.get_features_from_mid(fid)
            if feature:
                search_geom = QgsGeometry(QgsGeometry.fromPoint(search_point))
                dist = search_geom.distance(feature.geometry())
                if dist > tolerance:
                    continue
                tolerance = dist
                min_dist_feature = feature
        return min_dist_feature

    def get_features_in_rect(self, rect):
        if isinstance(rect, QgsRectangle):
            req = QgsFeatureRequest(rect)
            ft_iter = self.getFeatures(req)
            fts = list()
            for ft in ft_iter:
                if ft.geometry().intersects(rect):
                    fts.append(self.convert_feature(ft))
            return fts

        elif isinstance(rect, MdaFeature):
            return self.get_features_in_rect(rect.geometry())

        elif isinstance(rect, QgsGeometry):
            return self.get_features_in_rect(rect.buffer(1, 2).boundingBox())


    def modifySelectionEx(self, selectedFeatures, deselectedFeatures):
        self.selected_feature_list.extend(selectedFeatures)
        for tmp_deselected_feature in deselectedFeatures:
            self.selected_feature_list.remove(tmp_deselected_feature)

        if len(selectedFeatures) + len(deselectedFeatures) > 0:
            self.selectionChangedEx.emit(self.selected_feature_list, selectedFeatures, deselectedFeatures, False)

    def setSelectedFeaturesEx(self, newSelectedFeatures):
        self.selected_feature_list = newSelectedFeatures[:]
        self.selectionChangedEx.emit(self.selected_feature_list, [], [], True)

    def removeSelectionEx(self):
        if len(self.selected_feature_list) == 0:
            return
        del self.selected_feature_list[:]
        # self.selectionChangedEx.emit(self.selected_feature_list, [], [], True)
        self.hide_selection_ex()

    def set_highlight(self, ft, option):
        option.color = None
        option.width = 1
        option.shift.distance = 1
        option.shift.direction = dir.right

    def create_feature(self, feature):
        feature.auto_update()
        if not feature.check_base_info():
            log(self, u'create failed, base info does not exists', Qgis.critical)
            return None

        feature_id = feature.get_id()
        if not feature_id:
            feature_id = self.get_new_id(feature.get_mesh_id())
            if not feature_id:
                log(self, u'create failed, new id를 가져올 수 없습니다. DB를 확인해보세요.', Qgis.critical)
                return None
            feature.set_id(feature_id)

        feature.update_mid()
        self.addFeature(feature, False)

        feature = self.get_features_from_mid(feature.get_mid())
        self.insert_feature_to_spatial_index(feature)
        return feature

    def update_feature(self, feature, is_forced_update_geometry=False):
        if feature.update_mid():
            self.delete_feature(feature)
            return self.create_feature(feature)

        if is_forced_update_geometry:
            self.changeGeometry(feature.id(), feature.geometry())

        feature.auto_update()
        self.cache_features[feature.get_mid()] = feature
        self.updateFeature(feature)

        self.delete_feature_to_spatial_index(feature)
        self.insert_feature_to_spatial_index(feature)
        return feature

    def delete_feature(self, ft):
        if isinstance(ft, MdaFeature):
            self.append_deleted_features(ft)
            self.delete_feature_to_spatial_index(ft)
            if ft.get_mid() in self.cache_features:
                del self.cache_features[ft.get_mid()]
            self.deleteFeature(ft.id())
        elif isinstance(ft, long):
            ft = self.get_features_from_mid(ft)
            self.delete_feature(ft)

    def append_deleted_features(self, fts):
        if isinstance(fts, list):
            for ft in fts:
                self.deleted_features[ft.id()] = ft
        elif isinstance(fts, MdaFeature):
            self.deleted_features[fts.id()] = fts

    def get_deleted_features(self, feature_ids):
        if isinstance(feature_ids, list):
            return [self.deleted_features[feature_id] for feature_id in feature_ids]
        elif isinstance(feature_ids, long):
            if feature_ids not in self.deleted_features:
                log(self, 'not in deleted_features list {0}, {1}'.format(self.name(), feature_ids), Qgis.info)
                return None
            return self.deleted_features[feature_ids]

    def clear_deleted_features(self):
        self.deleted_features = dict()

    def clear_cache(self):
        self.cache_features = dict()

    def get_feature_type(self):
        raise NotImplementedError

    def get_field_index(self, field_name_list):
        fields = self.fields()

        idx_list = list()

        for field_name in field_name_list:
            idx = self.fieldNameIndex(field_name)
            idx_list.append(self.fieldNameIndex(field_name))

        return idx_list
