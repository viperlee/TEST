# -*- coding: utf-8 -*-
from PyQt5.QtCore import QDate
from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry

from ..utilities.enumeration import enum
from ..utilities.patterns import Singleton


class FeatureAttributeController(Singleton):
    def __init__(self):
        self.attr_idx = dict()
        self.attr_type = dict()

    def add_attribute_index_map(self, layer, dic=None):
        """
        속성 필드의 인덱스를 map으로 관리
        :param layer:
        :type: QgsVectorLayer, QgsFeature, Type
        :param enums:
        :type: enum
        :return:
        """
        if isinstance(layer, QgsVectorLayer):
            if not dic:
                dic = self.create_attribute_index(layer)
            self.attr_idx[layer] = dic
            self.attr_idx[type(layer)] = dic
            self.attr_idx[layer.name()] = dic
        elif isinstance(layer, QgsFeature):
            if not dic:
                return None
            self.attr_idx[type(layer)] = dic
        elif isinstance(layer, type):
            if not dic:
                return None
            self.attr_idx[layer] = dic

    def add_attribute_type_map(self, layer, enums=None):
        """
        속성 필드의 type을 map으로 관리
        :param layer:
        :type: QgsVectorLayer, QgsFeature, Type
        :param enums:
        :type: enum
        :return:
        """
        if isinstance(layer, QgsVectorLayer):
            if not enums:
                enums = self.create_attribute_type(layer)
            self.attr_type[layer] = enums
            self.attr_type[type(layer)] = enums
            self.attr_type[layer.name()] = enums
        elif isinstance(layer, QgsFeature):
            if not enums:
                return None
            self.attr_type[type(layer)] = enums
        elif isinstance(layer, type):
            if not enums:
                return None
            self.attr_type[layer] = enums

    def get_attribute_index_map(self, layer):
        if layer in self.attr_idx:
            return self.attr_idx[layer]
        return None

    def get_attribute_type_map(self, layer):
        if layer in self.attr_type:
            return self.attr_type[layer]
        return None

    @staticmethod
    def create_attribute_index(layer):
        attr_list = layer.attributeList()
        seq = ()
        indexed = {layer.attributeDisplayName(idx): idx for idx in attr_list}
        return enum(*seq, **indexed)

    @staticmethod
    def create_attribute_type(layer):
        attr_list = layer.attributeList()
        fields = layer.fields()
        typed = dict()
        for idx in attr_list:
            field_type_name = fields[idx].typeName()
            if u'int' in field_type_name:
                typed[idx] = long
            elif u'float8' in field_type_name:
                typed[idx] = float
            elif u'numeric' in field_type_name:
                typed[idx] = long
            elif u'char' in field_type_name:
                typed[idx] = str
            elif u'text' in field_type_name:
                typed[idx] = str
            elif u'date' in field_type_name:
                typed[idx] = QDate
            elif u'geometry' in field_type_name:
                typed[idx] = QgsGeometry
            elif u'timestamp' in field_type_name:
                typed[idx] = QDate
            elif u'bool' in field_type_name:
                typed[idx] = long
            else:
                log(self, "unknown field type {0}".format(field_type_name), Qgis.critical)
                raise NotImplementedError
        return typed
