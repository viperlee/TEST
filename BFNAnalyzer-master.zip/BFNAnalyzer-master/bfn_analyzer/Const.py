# -*- coding: utf-8 -*-
from .utilities.patterns import Singleton
import os


class Const(Singleton):
    def __init__(self):
        self.PLUGIN_NAME = "Basement Facility Network Analyzer"
        self.PLUGIN_SIMPLE_NAME = 'bfn_analyzer'
        self.PLUGIN_PATH = os.path.realpath(os.path.dirname(__file__))
        self.IMG_RES_PATH = ':/plugins/bfn_analyzer/images/'
        self.LOG_PATH = os.path.join(self.PLUGIN_PATH, 'log')
        self.REGISTRY_KEY = "Software\\QGIS\\QGIS3\\PythonPlugins\\Settings\\bfn_analyzer"
        self.db_host = 'bfna.cqirg4tfm0kl.ap-northeast-2.rds.amazonaws.com'

        self.ACTION_NAME_LOGIN = 'login'
        self.ACTION_NAME_LOGOUT = 'logout'
        self.ACTION_NAME_LOAD_DB = 'load_db'
        self.ACTION_NAME_RELOAD_LAYERS = 'reload_layers'
        self.ACTION_NAME_UPLOAD_SHP = 'upload_shp'
        self.ACTION_NAME_GENERATE_NETWORK = 'generate_network'
        self.ACTION_NAME_ANALYZE_NETWORK = 'analyze_network'
        self.ACTION_NAME_SAVE_STYLE = 'save_style'

        self.TABLE_NAME_USER_STYLE = 'user_styles'
        self.LAYER_NAME_PIPE_LINK = 'swl_pipe_lm_link'
        self.LAYER_NAME_PIPE_NODE = 'swl_pipe_lm_node'

