# -*- coding: utf-8 -*-
import os
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.Qt import *
from bfn_analyzer.utilities.DbManager import *
from bfn_analyzer.utilities.registry_util import *

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'LoginDlg.ui'))


class LoginDlg(QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(LoginDlg, self).__init__(parent)
        self.setupUi(self)
        self.le_pw.setEchoMode(QLineEdit.Password)
        self.load_login_info()
        self.setModal(True)
        self.le_pw.setFocus()
    def load_login_info(self):
        settings = ResgistryUtil.get_instance()
        # user_id = settings.get_value("user_id")
        user_id = 'gwlee'
        # user_pw = settings.get_value("user_pw")
        user_pw = 'mapdb'
        self.le_id.setText(user_id)
        self.le_pw.setText(user_pw)

    def update_login_info(self):
        settings = ResgistryUtil.get_instance()
        user_id = settings.set_value("user_id", self.le_id.text())
        user_pw = settings.set_value("user_pw", self.le_pw.text())

    def get_password(self):
        return self.le_pw.text()

    def get_id(self):
        return self.le_id.text()


