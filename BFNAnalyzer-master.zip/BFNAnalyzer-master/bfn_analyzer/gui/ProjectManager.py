# -*- coding: utf-8 -*-

import os
import tempfile
import psycopg2
import xml.etree.ElementTree
from qgis.core import *
from PyQt5.QtCore import QObject, pyqtSignal, QFile, QByteArray, QIODevice, QDateTime
from PyQt5.QtSql import *

from bfn_analyzer.utilities.DbManager import *
from bfn_analyzer.utilities.patterns import Singleton
from bfn_analyzer.utilities.log import *
from bfn_analyzer.utilities.util_etc import *


class ProjectManager(Singleton):
    def __init__(self):
        pass

    def download_qgs_project(self):
        """
        qgs project를 db로 부터 다운받는다.

        :param tool_type_str: 타입 명칭
        :type tool_type_str: str
        :return: 임시폴더에 저장된 파일 명칭
        :rtype: str
        """
        const = Const.get_instance()
        file_path = get_temporary_file_name(const.PLUGIN_SIMPLE_NAME, 'qgs')

        my_data = None
        db_manager = DbManager.get_instance()  # type: DbManager
        qry = u"SELECT style_data FROM {0} WHERE table_name = '{1}'"
        qry = qry.format(const.TABLE_NAME_USER_STYLE, const.PLUGIN_SIMPLE_NAME)
        ret, results = db_manager.execute_sql(DbManager.get_common_db_info(), qry, ExecuteType.SELECT)
        if not results:
            return None

        for row in results:
            my_data = row[0]

        if my_data is not None:
            my_data = self.__adjust_xml_data(my_data)
            write_file(file_path, my_data)
            return file_path

        return None

    def upload_qgs_project(self):
        """
        QGS Project를 DB에 업로드 한다.
        """
        const = Const.get_instance()
        file_path = get_temporary_file_name(const.PLUGIN_SIMPLE_NAME, 'qgs')

        proj = QgsProject.instance()  # type: QgsProject
        proj.write(QFileInfo(file_path))

        const = Const.get_instance()
        db_manager = DbManager.get_instance()  # type: DbManager
        qry = u"DELETE FROM {0} WHERE AND table_name = '{1}'".format(const.TABLE_NAME_USER_STYLE, const.PLUGIN_SIMPLE_NAME)
        db_manager.execute_sql(DbManager.get_common_db_info(), qry, ExecuteType.EXECUTE)

        file = open(file_path, 'r')
        qry = u"INSERT INTO {0}(style_data, table_name) VALUES ({1}, '{2}')"
        style_file_string_data = file.read()
        proj_file_data = psycopg2.Binary(style_file_string_data)
        proj_file_data = psycopg2.Binary(self.__adjust_xml_data(proj_file_data))
        qry = qry.format(const.TABLE_NAME_USER_STYLE, proj_file_data, const.PLUGIN_SIMPLE_NAME)
        db_manager.execute_sql(DbManager.get_common_db_info(), qry, ExecuteType.EXECUTE)

    def __adjust_xml_data(self, xml_str):
        try:
            parser = xml.etree.ElementTree.XMLParser(encoding="utf-8")
            doc = xml.etree.ElementTree.fromstring(xml_str, parser)

            id_list = list()
            elems = doc.findall('layer-tree-group/layer-tree-group/layer-tree-layer')
            for elem in elems:
                id_list.append(elem.get('id'))

            elem0 = doc.find('projectlayers')
            if elem0 is not None:
                elems1 = elem0.findall('maplayer')
                for elem1 in elems1:
                    elem2 = elem1.find('id')
                    if elem2.text in id_list:
                        elem0.remove(elem1)

            return xml.etree.ElementTree.tostring(doc, encoding='utf8', method='xml')
        except Exception as e:
            log(self, 'xml parse error: {0}'.format(e), Qgis.Critical)
        return xml_str


