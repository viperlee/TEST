# -*- coding: utf-8 -*-
import ogr

from .ImportData import *


class ImportShp(ImportData):
    def __init__(self):
        super(ImportShp, self).__init__()

    def open_file(self):
        try:
            driver = ogr.GetDriverByName('ESRI Shapefile')
            self.file_data = driver.Open(self.job.file_path, 0) # 0 means read-only. 1 means writeable.
        except:
            return False

        if self.file_data is None:
            return False

        return True

    def get_file_layer(self, file_data):
        try:
            layer = file_data.GetLayer()
            return layer
        except:
            return None

    def get_file_field_count(self, layer):
        try:
            return layer.GetLayerDefn().GetFieldCount() + 1 # geometry 포함
        except:
            return 0

    def get_file_record_count(self, layer):
        try:
            return layer.GetFeatureCount()
        except:
            return 0

    def get_row_value_string(self, layer, insert_field_types, row, srid):
        values = list()
        feature = layer.GetNextFeature()

        for col in range(len(insert_field_types)-1):
            value = u"{0}".format(feature.GetField(col))
            values.append(value)

        # geometry
        geom_value = feature.GetGeometryRef().ExportToWkt()
        values.append(geom_value)

        row_value_string = self.make_row_value_string(values, insert_field_types, srid)
        return row_value_string
