# -*- coding: utf-8 -*-

from .ExportData import *

class ExportXls(ExportData):
    def __init__(self):
        super(ExportXls, self).__init__()



