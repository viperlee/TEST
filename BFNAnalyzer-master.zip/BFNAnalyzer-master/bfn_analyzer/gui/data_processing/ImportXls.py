# -*- coding: utf-8 -*-
import xlrd

from .ImportData import *


class ImportXls(ImportData):
    def __init__(self):
        super(ImportXls, self).__init__()

    def open_file(self):
        try:
            self.file_data = xlrd.open_workbook(self.job.file_path)
        except:
            return False

        if not self.file_data:
            return False
        return True

    def get_file_layer(self, file_data):
        if self.job.layer_name not in file_data.sheet_names():
            return None

        layer = file_data.sheet_by_name(self.job.layer_name)
        return layer

    def get_file_field_count(self, layer):
        try:
            return layer.ncols
        except:
            return 0

    def get_file_record_count(self, layer):
        try:
            return layer.nrows
        except:
            return 0

    def get_row_value_string(self, layer, insert_field_types, row, srid):
        values = list()
        for col in range(len(insert_field_types)):
            cell = layer.cell(row, col)
            if cell.ctype == 1:  # A Unicode string 유니코드 문자열
                value = u"{0}".format(cell.value)
            elif cell.ctype == 2:  # float 부동소수점
                value = str(cell.value)
            elif cell.ctype == 0:  # Empty string 빈 문자열
                value = ''
            elif cell.ctype == 3:  # Date float 부동소수점
                Y, M, D, h, m, s = xlrd.xldate_as_tuple(cell.value, self.file_data.datemode)
                value = '{0}-{1}-{2} {3}:{4}:{5}'.format(Y, M, D, h, m, s)
            elif cell.ctype == 4:  # int (1=TRUE, 0=FALSE) 정수
                value = str(cell.value)
            else:
                value = ''

            values.append(value)

        row_value_string = self.make_row_value_string(values, insert_field_types)
        return row_value_string

