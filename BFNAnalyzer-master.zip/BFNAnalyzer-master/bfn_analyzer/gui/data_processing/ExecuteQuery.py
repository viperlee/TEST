# -*- coding: utf-8 -*-
import datetime

from .ProcessData import *


class ExecuteQuery(ProcessData):
    def __init__(self):
        super(ExecuteQuery, self).__init__()

    def get_sql_list(self):
        sql_list = list()
        sql = self.job.get_sql()
        while sql.find(';') != -1:
            idx = sql.find(';')
            query = sql[0:idx+1].strip()
            sql_list.append(query)
            sql = sql[idx+1:]

        return sql_list

    def run(self):
        if not self.job:
            return

        debug = False
        if debug:
            self.print_log_message.emit([u'[{0}] all script \r\n{1}'.format(self.job.description, self.job.get_sql()), 0])

        start_time = datetime.datetime.now()
        sql_list = self.get_sql_list()  # type :list
        self.update_progress.emit([self.job.job_index, 0, len(sql_list), self.elapsed_time])
        self.print_log_message.emit([u'[{0}] 작업 시작'.format(self.job.description), 0])
        progress_count = 0
        total_count = len(sql_list)
        for sql in sql_list:
            if self.terminate:
                break
            progress_count += 1
            ret, results = self.execute_sql(sql, exec_type=0)
            if not ret:
                self.terminate = True
                self.print_log_message.emit([u'[{0}] 작업 취소'.format(self.job.description), 0])
                self.print_log_message.emit([u'sql: {0}'.format(sql), 0])
                return

            self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
            self.update_progress.emit([self.job.job_index, progress_count, total_count, self.elapsed_time])
            self.print_log_message.emit([u'[{0}] 쿼리가 실행됨. ({1}/{2})'.format(self.job.description, progress_count, total_count), 0])
        self.print_log_message.emit([u'[{0}] 작업 종료'.format(self.job.description), 0])



