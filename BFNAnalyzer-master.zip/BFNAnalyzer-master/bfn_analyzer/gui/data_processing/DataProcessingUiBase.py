# -*- coding: utf-8 -*-

import datetime
import psycopg2
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import QMutex
from qgis.core import QgsDataSourceUri, Qgis

from bfn_analyzer.utilities.DbManager import *
from bfn_analyzer.utilities.log import *

from .ExecuteQuery import ExecuteQuery
from .ImportShp import ImportShp
from .ExportShp import ExportShp
from .ImportXls import ImportXls
from .CheckQuery import CheckQuery
from .ExecuteFunction import ExecuteFunction
from .DataProcessingDlg import DataProcessingDlg
from .DataProcessingJob import DataProcessingJob


class DataProcessingUiBase:
    def __init__(self):
        self.dlg = None
        self.running_flag = False
        self.proc_name = None
        self.default_db_uri = None
        self.cancel_flag = False
        self.mutex = QMutex()
        self.db_dict = dict()
        self.all_jobs = list()
        self.do_jobs = list()
        self.using_multi_thread = False
        self.running_job_idx = 0
        self.set_job_info()
        self.make_jobs()
        self.set_dialog()

    def set_job_info(self):
        raise NotImplementedError

    def update_job_from_ui(self):
        raise NotImplementedError

    def set_dialog(self, dlg=None):
        self.disconnect_dialog_signal()
        if not dlg:
            self.dlg = DataProcessingDlg()
        else:
            self.dlg = dlg
        self.connect_dialog_signal()
        self.connect_dialog_ui()
        self.append_option_ui()

    def get_job(self, description):
        for job in self.all_jobs:
            if job.description == description:
                return job

        raise KeyError

    def init_all(self):
        if self.running_flag:
            msg = QMessageBox()
            msg.setStandardButtons(QMessageBox.Ok)
            msg.setText(u'데이터 변환 작업이 진행중입니다.')
            msg.exec_()
            return

        self.dlg.delete_ui()
        self.connect_dialog_ui()

    def connect_db(self):
        for job in self.all_jobs:
            if not job.uri:
                return False
            if job.uri in self.db_dict:
                try:
                    cur = self.db_dict[job.uri].cursor()
                    cur.execute('SELECT 1')
                    cur.close()
                    job.db_conn = self.db_dict[job.uri]
                    continue
                except:
                    # psycopg2.OperationalError
                    # reconnect
                    pass
            try:
                db_manager = DbManager.get_instance()
                conn_str = db_manager.make_db_connect_string(job.uri)
                db_conn = psycopg2.connect(conn_str)
                self.db_dict[job.uri] = db_conn
                job.db_conn = self.db_dict[job.uri]
            except Exception as e:
                self.print_log_message('db connection failed.{0}, {1}:{2}'.format(e, job.uri.host(), job.uri.database()), 2)
                return False
        return True

    def set_title(self, title, description):
        self.dlg.set_title(title, description)

    def disconnect_dialog_signal(self):
        try:
            self.dlg.pb_check_all.clicked.disconnect(self.pb_check_all_clicked)
        except:
            pass
        try:
            self.dlg.pb_start.clicked.disconnect(self.pb_start_clicked)
        except:
            pass
        try:
            self.dlg.pb_exit.clicked.disconnect(self.pb_exit_clicked)
        except:
            pass

    def connect_dialog_signal(self):
        self.dlg.pb_check_all.clicked.connect(self.pb_check_all_clicked)
        self.dlg.pb_start.clicked.connect(self.pb_start_clicked)
        self.dlg.pb_exit.clicked.connect(self.pb_exit_clicked)

    def connect_dialog_ui(self):
        for job in self.all_jobs:
            self.dlg.append_ui(job)

    def make_jobs(self):
        db_manager = DbManager.get_instance() #type: DbManager
        sql = "select proc_type, query, seq, estimated_time, description from db_proc_query where proc_name = '{0}' order by seq;"\
            .format(self.proc_name)

        options = DbOptions()
        options.result_type = 1
        ret, results = db_manager.execute_sql(db_manager.get_common_db_info(), sql, options)
        if not results:
            return

        if not self.default_db_uri:
            self.default_db_uri = db_manager.get_current_db_info()

        self.all_jobs = list()
        for row in results:
            job = DataProcessingJob()
            job.proc_name = self.proc_name
            if row[0] == u'ExecuteQuery':
                job.job_class = ExecuteQuery
            elif row[0] == u'ImportXls':
                job.job_class = ImportXls
            elif row[0] == u'ImportShp':
                job.job_class = ImportShp
            elif row[0] == u'ExportShp':
                job.job_class = ExportShp
            elif row[0] == u'CheckQuery':
                job.job_class = CheckQuery
            elif row[0] == u'ExecuteFunction':
                job.job_class = ExecuteFunction
            else:
                raise NotImplementedError
            job.origin_sql = row[1]
            job.proc_sequence = long(row[2])
            job.estimated_time = long(row[3])
            job.uri = QgsDataSourceUri(self.default_db_uri)
            job.description = row[4]
            job.job_index = len(self.all_jobs)
            self.all_jobs.append(job)

    def append_execute_function_job(self, callback, args):
        job = DataProcessingJob()
        job.job_class = ExecuteFunction
        job.callback = callback
        job.args = args
        job.job_index = len(self.all_jobs)
        self.all_jobs.append(job)

    def _append_option_item(self, ui_name, ui_text, ui_type):
        ui_list = list()
        if ui_text:
            label = QLabel()
            label.setText(ui_text)
            ui_list.append(['lb_' + ui_name, label])
        ui = None
        if ui_type:
            ui = ui_type()
            ui_list.append([ui_name, ui])
        self.dlg.append_option_ui(ui_list)
        return ui

    def _append_option_multi_items(self, ui_infos):
        ui_list = list()
        for ui_name, ui_text, ui_type in ui_infos:
            if ui_text:
                label = QLabel()
                label.setText(ui_text)
                ui_list.append(['lb_' + ui_name, label])
            if ui_type:
                ui = ui_type()
                ui_list.append([ui_name, ui])
        self.dlg.append_option_ui(ui_list)

    def append_option_ui(self):
        pass

    def get_option_ui(self, ui_name):
        return self.dlg.get_option_ui(ui_name)

    def set_default_uri(self, uri):
        self.default_db_uri = QgsDataSourceUri(uri)

    def change_db_uri(self):
        pass

    def start_jobs(self):
        db_manager = DbManager.get_instance()
        self.set_default_uri(db_manager.get_current_db_info())

        for job in self.all_jobs:
            job.uri = QgsDataSourceUri(self.default_db_uri)
            self.update_progress([job.job_index, 0, 1, 0])

        self.change_db_uri()

        if not self.update_job_from_ui():
            return False
        if not self.connect_db():
            return False

        self.do_jobs = list()
        for idx in self.dlg.get_todo_list():
            job = self.all_jobs[idx]
            job_thread = job.job_class()
            job_thread.set_job(job)
            job_thread.print_log_message.connect(self.print_log_message)
            job_thread.update_progress.connect(self.update_progress)
            job_thread.finished.connect(self.job_finished)
            self.do_jobs.append(job_thread)

        if len(self.do_jobs) > 0:
            self.running_job_idx = 0
            self._start_job_thread()
            return True

        return False

    def _start_job_thread(self):
        if self.running_job_idx >= len(self.do_jobs):
            return

        self.do_jobs[self.running_job_idx].start()
        self.running_job_idx += 1

        if self.using_multi_thread:
            self._start_job_thread()

    def cancel_jobs(self):
        for job_thread in self.do_jobs:
            try:
                job_thread.finished.disconnect(self.job_finished)
            except:
                pass
            if job_thread.isRunning():
                job_thread.terminate = True
                self.terminate_running_query(job_thread)
        while True:
            all_terminated = True
            for job_thread in self.do_jobs:
                if job_thread.isRunning():
                    all_terminated = False
            if all_terminated:
                break

            time.sleep(5)

        self.do_jobs = list()
        self.print_log_message('converting canceled.')

    def pb_check_all_clicked(self):
        if self.running_flag:
            return
        self.dlg.check_all()

    def pb_start_clicked(self):
        self.mutex.lock()
        if self.cancel_flag:
            self.mutex.unlock()
            return
        elif self.running_flag:
            self.cancel_flag = True
        else:
            self.running_flag = True
            self.dlg.enable_ui(False)
        self.mutex.unlock()

        if self.cancel_flag:
            self.cancel_jobs()
            self.running_flag = False
            self.cancel_flag = False
            self.dlg.pb_start.setText(u'변환시작')
            self.dlg.pb_check_all.setEnabled(True)
            self.dlg.pb_exit.setEnabled(True)
        else:
            if not self.start_jobs():
                self.running_flag = False
                self.cancel_flag = False
                self.dlg.enable_ui(True)
                return
            self.dlg.pb_check_all.setEnabled(False)
            self.dlg.pb_exit.setEnabled(False)
            self.dlg.pb_start.setText(u'변환취소')

    def pb_exit_clicked(self):
        if self.running_flag and not self.cancel_flag:
            self.cancel_flag = False
            self.cancel_jobs()
        self.dlg.close()

    def job_finished(self):
        # multi thread
        if self.using_multi_thread:
            thread = self.dlg.sender()
            self.mutex.lock()
            all_finished = True
            for job_thread in self.do_jobs:
                if job_thread.isRunning():
                    all_finished = False
            self.mutex.unlock()
            if all_finished:
                self.do_jobs = list()
                self.running_flag = False
                self.dlg.pb_start.setText(u'변환시작')
                self.dlg.pb_check_all.setEnabled(True)
                self.dlg.pb_exit.setEnabled(True)
                msg = QMessageBox()
                if thread.terminate:
                    msg.setText(u'변환이 취소되었습니다.')
                else:
                    msg.setText(u'변환이 완료되었습니다.')
                msg.exec_()
                self.dlg.start_check()
                self.dlg.enable_ui(True)
        else:
            # single thread
            thread = self.dlg.sender()
            if not thread.terminate:
                thread.job.update_job_estimated_time(thread.elapsed_time)

                if self.running_job_idx < len(self.do_jobs):
                    self._start_job_thread()
                    return

            self.do_jobs = list()
            self.running_flag = False
            self.dlg.pb_start.setText(u'변환시작')
            self.dlg.pb_check_all.setEnabled(True)
            self.dlg.pb_exit.setEnabled(True)
            msg = QMessageBox()
            if thread.terminate:
                msg.setText(u'변환이 취소되었습니다.')
            else:
                msg.setText(u'변환이 완료되었습니다.')
            msg.exec_()
            self.dlg.start_check()
            self.dlg.enable_ui(True)

    def update_progress(self, info):
        job_index, progress_count, total_count, elipsed_time = info
        self.dlg.update_progress(job_index, progress_count, total_count, elipsed_time)

    def print_log_message(self, log, level=0):
        if type(log) is list:
            self.print_log_message(log[0],log[1])

        else:
            self.mutex.lock()
            try:
                self.dlg.te_log.moveCursor(QTextCursor.End, QTextCursor.MoveAnchor)
                self.dlg.te_log.insertPlainText(u'[{0}] {1}\n'.format(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), log))
                if level == 0:
                    log(self, log, Qgis.Info)
                elif level == 1:
                    log(self, log, Qgis.Warning)
                elif level == 2:
                    log(self, log, Qgis.Critical)

            except:
                pass
            self.mutex.unlock()

    @staticmethod
    def terminate_running_query(job_thread):
        db_manager = DbManager.get_instance()
        if job_thread.job.db_conn:
            pid = job_thread.job.db_conn.get_backend_pid()
            query = 'select pg_cancel_backend({0})'.format(pid)
            db_manager.execute_sql(job_thread.job.uri, query)

