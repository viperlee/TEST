# -*- coding: utf-8 -*-

from bfn_analyzer.utilities.DbManager import *


class DataProcessingJob:
    def __init__(self):
        self.job_index = 0
        self.description = u''
        self.estimated_time = 0
        self.uri = None
        self.db_conn = None
        self.job_class = None
        self.proc_name = ''
        self.proc_sequence = 0
        self.origin_sql = ''
        self.file_path = ''
        self.srid = u'5179'
        self.exec_cnt = 1 # 여러번 실행

        self.callback = None
        self.args = None

        self.replace_strings = dict()

    def get_sql(self):
        sql = self.origin_sql
        for org_string in self.replace_strings.keys():
            sql = sql.replace(org_string, self.replace_strings[org_string])
        sql = sql * self.exec_cnt
        return sql

    def update_job_estimated_time(self, elapsed_time):
        db_manager = DbManager.get_instance()
        if not self.proc_name:
            return

        sql = u"update db_proc_query set estimated_time = {0} where proc_name = '{1}' and seq = {2}"\
            .format(elapsed_time, self.proc_name, self.proc_sequence)

        options = DbOptions()
        options.result_type = 0
        db_manager.execute_sql(db_manager.common_db_uri, sql, options)

