# -*- coding: utf-8 -*-
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from PyQt5.QtCore import *

from bfn_analyzer.utilities.DbManager import *


class ProcessData(QThread):
    update_progress = pyqtSignal(list)
    print_log_message = pyqtSignal(list)

    def __init__(self):
        super(ProcessData, self).__init__()
        self.results = list()
        self.job = None
        self.elapsed_time = 0
        self.terminate = False
        self.auto_commit = True

    def __del__(self):
        self.wait()

    def set_job(self, job):
        self.job = job

    def execute_sql(self, sql, exec_type=0):
        db_manager = DbManager.get_instance()  #type: DbManager
        options = DbOptions()
        options.auto_commit = self.auto_commit
        options.result_type = exec_type
        return db_manager.execute_sql(self.job.db_conn, sql, options)

    def get_table_field_type_dict(self, table_name):
        field_types = dict()
        sql = """
            select quote_ident(attname) as field_name,
                format_type(atttypid,atttypmod) as field_type
            from pg_attribute
                left outer join pg_constraint on conrelid = attrelid
                    and attnum = conkey[1]
                    and array_upper( conkey, 1 ) = 1,
                pg_class,
                pg_namespace
            where pg_class.oid = attrelid
                and pg_namespace.oid = relnamespace
                and pg_class.oid = btrim( '{0}' )::regclass::oid
                and attnum > 0
                and not attisdropped
            order by attrelid, attnum;
            """.format(table_name)

        ret, results = self.execute_sql(sql, exec_type=1)

        if not ret:
            return []

        try:
            for row in results:
                field_name = row[0]
                type_string = row[1]

                field_type = None
                if type_string.find('integer') >= 0:
                    field_type = 'integer'
                elif type_string.find('text') >= 0:
                    field_type = 'text'
                elif type_string.find('bigint') >= 0:
                    field_type = 'integer'
                elif type_string.find('character') >= 0:
                    field_type = 'text'
                elif type_string.find('smallint') >= 0:
                    field_type = 'integer'
                elif type_string.find('double') >= 0:
                    field_type = 'float'
                elif type_string.find('timestamp') >= 0:
                    field_type = 'text'
                elif type_string.find('date') >= 0:
                    field_type = 'text'
                elif type_string.find('geometry') >= 0:
                    field_type = type_string
                else:
                    raise NotImplementedError
                field_types[field_name] = field_type
        except Exception as e:
            log = u'{0}\n{1}'.format(e.message, sql)
            self.print_log_message.emit([u'[{0}] 쿼리 오류\r\n{1}'.format(self.job.description, log), 1])
            return []

        return field_types

    def get_table_field_type_list(self, table_name):
        field_types = list()
        sql = """
            select quote_ident(attname) as field_name,
                format_type(atttypid,atttypmod) as field_type
            from pg_attribute
                left outer join pg_constraint on conrelid = attrelid
                    and attnum = conkey[1]
                    and array_upper( conkey, 1 ) = 1,
                pg_class,
                pg_namespace
            where pg_class.oid = attrelid
                and pg_namespace.oid = relnamespace
                and pg_class.oid = btrim( '{0}' )::regclass::oid
                and attnum > 0
                and not attisdropped
            order by attrelid, attnum;
            """.format(table_name)

        ret, results = self.execute_sql(sql, exec_type=1)
        if not ret:
            return []

        try:
            for row in results:
                field_name = row[0]
                type_string = row[1]
                field_type = None
                field_length = 0
                if type_string.find('integer') >= 0:
                    field_type = 'integer'
                    field_length = 9
                elif type_string.find('bigint') >= 0:
                    field_type = 'float'
                elif type_string.find('smallint') >= 0:
                    field_type = 'integer'
                    field_length = 4
                elif type_string.find('double') >= 0:
                    field_type = 'float'
                elif type_string.find('text') >= 0:
                    field_type = 'text'
                elif type_string.find('character') >= 0:
                    field_type = 'text'
                elif type_string.find('timestamp') >= 0:
                    field_type = 'date'
                    field_length = 10
                elif type_string.find('date') >= 0:
                    field_type = 'date'
                    field_length = 10
                elif type_string.find('geometry') >= 0:
                    field_type = type_string
                else:
                    raise NotImplementedError

                if field_type == 'text':
                    max_len_sql = "select max(bit_length({0}))/8 from {1};".format(field_name, table_name)
                    _cur = self.job.db_conn.cursor()
                    _cur.execute(max_len_sql)
                    char_size = _cur.fetchone()
                    try:
                        field_length = int(char_size[0])
                    except:
                        field_length = 255
                    self.print_log_message.emit([u'[{0}] {1} 필드 길이 조정 {2}'.format(self.job.description, field_name, field_length), 0])
                    _cur.close()
                field_types.append([field_name, field_type, field_length])
        except Exception as e:
            log = u'{0}\n{1}'.format(e.message, sql)
            self.print_log_message.emit([u'[{0}] 쿼리 오류\r\n{1}'.format(self.job.description, log), 1])
            return []

        # self.print_log_message.emit([u'[{0}] 필드 확인 {1}'.format(self.job.description, field_types), 0])
        return field_types

    def get_layer_name(self):
        try:
            if self.job.layer_name:
                return self.job.layer_name
        except:
            pass
        return 'temp_layer'


