# -*- coding: utf-8 -*-
import datetime
import uuid
import codecs

from .ProcessData import *


class ExportData(ProcessData):
    def __init__(self):
        super(ExportData, self).__init__()
        self.file_data = None
        self.cursor_iter_size = 10000
        self.cursor_array_size = 10000
        self.export_table_name = None

    def __del__(self):
        self.file_data = None
        self.wait()

    def get_export_table_name(self):
        if not self.export_table_name:
            self.export_table_name = 'exp_temp_{0}'.format(str(uuid.uuid4().fields[0]))
        return self.export_table_name

    def create_export_file(self, field_list):
        raise NotImplementedError

    def get_sql_list(self):
        sql_list = list()
        sql = self.job.get_sql()
        while sql.find(';') != -1:
            idx = sql.find(';')
            query = sql[0:idx+1].strip()
            sql_list.append(query)
            sql = sql[idx+1:]

        return sql_list

    def run(self):
        if not self.job:
            return

        debug = False
        if debug:
            self.print_log_message.emit([u'[{0}] all script \r\n{1}'
                                        .format(self.job.description, self.job.get_sql()), 0])

        start_time = datetime.datetime.now()
        sql_list = self.get_sql_list()  # type :list
        if len(sql_list) != 1:
            self.print_log_message.emit([u'[{0}] 데이터 추출 쿼리가 한개가 아닙니다. {1}'.format(self.job.description, sql_list), 1])
            return
        sql = sql_list[0]
        self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
        self.print_log_message.emit([u'[{0}] 데이터 추출 시작'.format(self.job.description), 0])

        cursor = self.job.db_conn.cursor()
        if cursor is None:
            return

        # create temp table
        export_table_name = self.get_export_table_name()
        create_sql = u"drop table if exists {0}; create temp table {0} as {1}".format(export_table_name, sql)

        try:
            cursor.execute(create_sql)
            self.job.db_conn.commit()
        except:
            pass

        self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
        self.print_log_message.emit([u'[{0}] 임시 테이블 생성 완료'.format(self.job.description), 0])

        field_list = self.get_table_field_type_list(export_table_name)
        # create export file
        layer = None

        try:
            if self.job.field_definition:
                create_field_list = self.job.field_definition
            else:
                create_field_list = field_list
        except AttributeError:
            create_field_list = field_list

        layer = self.create_export_file(create_field_list)
        if not layer:
            self.print_log_message.emit([u'[{0}] 파일 생성 실패'.format(self.job.description), 1])
            return

        self.print_log_message.emit([u'[{0}] 레이어 생성 성공'.format(self.job.description), 1])
        # record count
        try:
            count_sql = u"select count(1) as cnt from {0}".format(export_table_name)
            cursor.execute(count_sql)
            row_count_record = cursor.fetchone()[0]
        except Exception as e:
            self.print_log_message.emit([u'[{0}] 레코드 개수 가져오기 실패\n{1}\n{2}'.format(self.job.description, count_sql, e), 1])
            return
        self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
        self.update_progress.emit([self.job.job_index, 0, row_count_record, self.elapsed_time])

        select_fields = list()
        for field_name, field_type, field_length in field_list:
            if field_type.find('geometry') >= 0:
                select_fields.append("st_astext({0})".format(field_name))
            else:
                select_fields.append(field_name)

        cursor_func_name = 'ref_{0}'.format(export_table_name)
        # print 'serverside_cursor_name = {0}'.format(cursor_func_name)
        export_sql = "CREATE OR REPLACE FUNCTION {0}(refcursor) RETURNS refcursor AS $$ " \
                     "BEGIN " \
                     "OPEN $1 FOR select {1} from {2} order by (ROW_NUMBER() OVER()); " \
                     "RETURN $1; " \
                     "END; " \
                     "$$ LANGUAGE plpgsql;".format(cursor_func_name,
                                                   u",".join(select_fields),
                                                   export_table_name)
        cursor_name = 'cur_{0}'.format(export_table_name)
        try:
            cursor.execute(export_sql)
            cursor.callproc(cursor_func_name, [cursor_name])
            export_cursor = self.job.db_conn.cursor(cursor_name)
        except:
            self.print_log_message.emit([u"[{0}] 데이터 추출 쿼리 실행 오류\n{1}"
                                        .format(self.job.description, export_sql), 0])
            cursor.close()
            return
        export_cursor.itersize = self.cursor_iter_size
        # insert data
        inserted_count = 0
        try:
            while True:
                if self.terminate:
                    break
                rows = export_cursor.fetchmany(self.cursor_array_size)
                inserted_count += 1
                get_row_count = len(rows)
                for row in rows:
                    # create the feature
                    self.write_data_to_layer(layer, row, create_field_list)

                # check write last data
                if get_row_count < self.cursor_array_size:
                    # write complete
                    self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
                    self.print_log_message.emit([u'[{0}] 데이터 추출 진행중 ({1}/{2})'
                                                .format(self.job.description,
                                                        (inserted_count-1)*self.cursor_array_size + get_row_count,
                                                        row_count_record), 0])
                    self.update_progress.emit([self.job.job_index,
                                               (inserted_count-1)*self.cursor_array_size + get_row_count,
                                               row_count_record,
                                               self.elapsed_time])
                    break
                # update progress bar
                self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
                self.print_log_message.emit([u'[{0}] 데이터 추출 진행중 ({1}/{2})'
                                            .format(self.job.description,
                                                    inserted_count*self.cursor_array_size,
                                                    row_count_record), 0])
                self.update_progress.emit([self.job.job_index,
                                           inserted_count*self.cursor_array_size,
                                           row_count_record,
                                           self.elapsed_time])

        except Exception as e:
            self.terminate = True
            self.print_log_message.emit([u'[{0}] 데이터 추출 실패\n{1}'.format(self.job.description, e), 1])

        export_cursor.close()
        cursor.execute("drop function {0}(refcursor)".format(cursor_func_name))
        self.job.db_conn.commit()
        cursor.close()
        self.file_data = None
        self.print_log_message.emit([u'[{0}] 데이터 추출 종료'.format(self.job.description), 0])

    def write_data_to_layer(self, layer, row, field_list):
        raise NotImplementedError
