# -*- coding: utf-8 -*-
import datetime

from qgis.core import Qgis
from .ProcessData import *


class ImportData(ProcessData):
    def __init__(self):
        super(ImportData, self).__init__()
        self.file_data = None

    def __del__(self):
        self.file_data = None
        self.wait()

    @staticmethod
    def get_insert_table_name(insert_sql):
        try:
            st_index = insert_sql.find(u'insert into')
            ed_index = insert_sql.find(u'(')
            table_name = insert_sql[st_index+11:ed_index].strip()
        except:
            table_name = ''

        return table_name

    @staticmethod
    def get_insert_fields(insert_sql):
        fields = list()
        try:
            st_index = insert_sql.find(u'(')
            ed_index = insert_sql.find(u')')
            fields_string = insert_sql[st_index+1:ed_index]
            fields_string_list = fields_string.split(",")
            for field_string in fields_string_list:
                fields.append(field_string.strip())
        except:
            fields = list()

        return fields

    def make_row_value_string(self, values, field_types, srid=u'5179'):
        value_strings = list()
        for col in range(len(field_types)):
            field_type = field_types[col]
            value = values[col]

            if field_type == 'text':
                value_string = u"'{0}'".format(value)
            elif field_type == 'integer':
                if value == '':
                    value = '0'
                value_string = u"{0}".format(long(float(value)))
            elif field_type == 'float':
                if value == '':
                    value = '0.0'
                value_string = u"{0}".format(float(value))
            elif field_type == 'geometry':
                value_string = u"ST_SETSRID(ST_GeomFromText('{0}'),{1})".format(value, srid)
            elif field_type == 'geometryMulti':
                value_string = u"ST_SETSRID(ST_Multi(ST_GeomFromText('{0}')),{1})".format(value, srid)
            elif field_type.find("geometry(LineStringZ") != -1:
                value_string = u"ST_SETSRID(st_force3d(st_linemerge(ST_GeomFromText('{0}'))),{1})".format(value, srid)
            elif field_type.find("geometry(PointZ") != -1:
                value_string = u"ST_SETSRID(st_force3d(ST_GeomFromText('{0}')),{1})".format(value, srid)
            else:
                log(self, field_type, Qgis.Critical)

            value_strings.append(value_string)

        row_value_string = u"({0})".format(",".join(value_strings))
        return row_value_string

    def get_sql_list(self):
        sql_list = list()
        sql = self.job.get_sql()
        idx = sql.find(u'insert into')
        if idx != -1:
            sql_list.append(sql[0:idx])
            sql_list.append(sql[idx:])
        else:
            sql_list.append(sql)
        return sql_list

    def open_file(self):
        raise NotImplementedError

    def get_file_layer(self, file_data):
        raise NotImplementedError

    def get_file_field_count(self, layer):
        raise NotImplementedError

    def get_file_record_count(self, layer):
        raise NotImplementedError

    def get_row_value_string(self, layer, insert_field_types, row, srid):
        raise NotImplementedError

    def run(self):
        if not self.job:
            return

        debug = False
        if debug:
            self.print_log_message.emit([u'[{0}] all script \r\n{1}'.format(self.job.description, self.job.get_sql()), 0])

        start_time = datetime.datetime.now()
        sql_list = self.get_sql_list()  # type :list

        self.print_log_message.emit([u'[{0}] 작업 시작'.format(self.job.description), 0])

        if len(sql_list) == 2:
            create_sql = sql_list[0]
            insert_header_sql = sql_list[1]
        else:
            self.print_log_message.emit([u'[{0}] 쿼리 오류'.format(self.job.description), 1])
            self.terminate = True
            return

        # create table
        ret, result = self.execute_sql(create_sql)
        if not ret:
            self.terminate = True
            self.print_log_message.emit([u'[{0}] 작업 취소됨'.format(self.job.description), 0])
            return

        if not self.open_file():
            self.terminate = True
            self.print_log_message.emit([u'[{0}] 작업 취소됨. 파일 열기 실패 {1}'.format(self.job.description, self.job.file_path), 0])
        file_layer = self.get_file_layer(self.file_data)
        if not file_layer:
            self.terminate = True
            self.print_log_message.emit([u'[{0}] 작업 취소됨. {1} 레이어 미존재'.format(self.job.description, self.get_layer_name()), 0])
            return
        table_name = self.get_insert_table_name(insert_header_sql)
        field_types = self.get_table_field_type_dict(table_name)
        insert_fields = self.get_insert_fields(insert_header_sql)
        insert_field_types = list()

        self.print_log_message.emit([u'[{0}] 데이터 업로드 정보: {1}'.format(
            self.job.description,
            "tbl:{0}, fields:{1}, records:{2}".format(
                table_name,
                len(insert_fields),
                self.get_file_record_count(file_layer))), 0])
        try:
            for field in insert_fields:
                insert_field_types.append(field_types[field])
        except Exception as e:
            self.print_log_message.emit([u'[{0}] 데이터 필드 오류\n{1}'.format(self.job.description, e), 1])
            return

        if len(insert_fields) != self.get_file_field_count(file_layer):
            self.print_log_message.emit([u'[{0}] 삽입 컬럼 개수가 다릅니다.\ndb:{1}, file{2} : {3}'.format(
                self.job.description, len(insert_fields), self.get_file_field_count(file_layer), self.get_layer_name()), 1])
        try:
            # insert data
            insert_values = list()
            total_count = self.get_file_record_count(file_layer)
            self.update_progress.emit([self.job.job_index, 0, total_count, self.elapsed_time])

            progress_count = 0
            is_error = False

            for row in range(1, self.get_file_record_count(file_layer)+1):
                if self.terminate:
                    if is_error:
                        self.print_log_message.emit([u'[{0}] 작업 오류'.format(self.job.description), 0])
                    else:
                        self.print_log_message.emit([u'[{0}] 작업 취소됨'.format(self.job.description), 0])
                    return
                progress_count += 1
                row_value_string = self.get_row_value_string(file_layer, insert_field_types, row, self.job.srid)
                insert_values.append(row_value_string)
                if len(insert_values) >= 10000:
                    insert_sql = u"{0} {1};".format(insert_header_sql.strip(), ",".join(insert_values))
                    # log(self, insert_sql)
                    ret, result = self.execute_sql(insert_sql)
                    if not ret:
                        self.terminate = True
                        is_error = True
                    insert_values = list()
                    self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
                    self.update_progress.emit([self.job.job_index, progress_count, total_count, self.elapsed_time])
                    self.print_log_message.emit([u'[{0}] 데이터가 추가됨 ({1}/{2}) '.format(self.job.description, progress_count, total_count), 0])

            if len(insert_values):
                insert_values_sql = u"{0};".format(",".join(insert_values))
                ret, result = self.execute_sql(insert_header_sql+insert_values_sql)
                if not ret:
                    self.terminate = True
                    self.print_log_message.emit([u'[{0}] 작업 취소됨'.format(self.job.description), 0])
                    return

                insert_values = list()
                self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
                self.update_progress.emit([self.job.job_index, progress_count, total_count, self.elapsed_time])
                self.print_log_message.emit([u'[{0}] 데이터가 추가됨 ({1}/{2}) '.format(self.job.description, progress_count, total_count), 0])

            self.print_log_message.emit([u'[{0}] 데이터 추가 종료'.format(self.job.description), 0])
        except Exception as e:
            self.print_log_message.emit([u'[{0}] 데이터 추가 예외 발생\n{1}'.format(self.job.description, e.message), 0])


