# -*- coding: utf-8 -*-

import os
import ogr
import osr
import unicodedata
from PyQt5.QtCore import QMutex

from .ExportData import *


class ExportShp(ExportData):

    def __init__(self):
        super(ExportShp, self).__init__()
        self.terminate = False
        self.mutex = QMutex()
        self.encoder = codecs.getincrementalencoder('cp949')()
        self.StringAsUTF8 = False

    def convert_cp949(self, text_string):
        convert_string = text_string.decode("utf-8")
        return str(self.encoder.encode(convert_string))

    def get_file_name(self):
        if not self.job.file_path:
            return None
        if self.job.file_path.find('.shp') == -1:
            return os.path.join(self.job.file_path, self.get_layer_name() + '.shp')
        self.print_log_message.emit([u"[{0}] 출력 파일 : {1}".format(self.job.file_path), 0])

        return self.job.file_path

    def create_export_file(self, field_list):
        driver_name = "ESRI Shapefile"      # e.g.: GeoJSON, ESRI Shapefile
        driver = ogr.GetDriverByName(driver_name)
        if driver is None:
            self.print_log_message.emit(["{0} driver not available.\n".format(driver_name), 1])
            return None

        shape_file_name = self.get_file_name()
        if not shape_file_name:
            self.print_log_message.emit([u"Shape 파일 명을 확인해주세요. 파일명이 없습니다.", 0])
            return None

        if os.path.exists(shape_file_name):
            driver.DeleteDataSource(shape_file_name)

        self.file_data = driver.CreateDataSource(shape_file_name)
        if self.file_data is None:
            self.print_log_message.emit([u"[{0}] 파일 생성 실패 {1}".format(self.job.description, shape_file_name), 1])
            return None

        layer = None
        for field_name, field_type, field_length in field_list:
            if field_type.find('geometry') >= 0:
                if field_type.find('PointZ') >= 0:
                    geom_type = ogr.wkbPointZM
                elif field_type.find('LineStringZ') >= 0:
                    geom_type = ogr.wkbLineStringZM
                elif field_type.find('PolygonZ') >= 0:
                    geom_type = ogr.wkbMultiPolygonZM
                elif field_type.find('Point') >= 0:
                    geom_type = ogr.wkbPoint
                elif field_type.find('LineString') >= 0:
                    geom_type = ogr.wkbLineString
                elif field_type.find('Polygon') >= 0:
                    geom_type = ogr.wkbMultiPolygon
                else:
                    raise TypeError

                # create the spatial reference, UTMK
                srs_type = osr.SpatialReference()
                if field_type.find('5179') >= 0:
                    srs_type.ImportFromEPSG(5179)
                elif field_type.find('4326') >= 0:
                    srs_type.ImportFromEPSG(4326)
                layer = self.file_data.CreateLayer(self.get_layer_name(), srs=srs_type, geom_type=geom_type)
                break

        if not layer:
            self.print_log_message.emit([u"[{0}] 레이어 생성 실패".format(self.job.description), 1])
            return None
        self.print_log_message.emit([u"[{0}] 지오메트리 생성 완료".format(self.job.description), 0])

        for field_name, field_type, field_length in field_list:
            ogr_field_type = None
            if field_type == 'text':
                ogr_field_type = ogr.OFTString
            elif field_type == 'integer':
                ogr_field_type = ogr.OFTInteger
                if field_length > 9:
                    ogr_field_type = ogr.OFTInteger64
            elif field_type == 'float':
                ogr_field_type = ogr.OFTReal
            elif field_type == 'date':
                ogr_field_type = ogr.OFTDate
            elif field_type.find('geometry') >= 0:
                continue
            else:
                raise TypeError
            field = ogr.FieldDefn(str(field_name), ogr_field_type)
            if field_length > 0:
                field.SetWidth(field_length)
            layer.CreateField(field)
            # self.print_log_message.emit([u"[{0}] 필드 생성 {1}".format(self.job.description, field_name), 0])

        self.StringAsUTF8 = layer.TestCapability(ogr.OLCStringsAsUTF8)
        if self.StringAsUTF8:
            self.print_log_message.emit([u"[{0}] UTF8 Capability {1}".format(self.job.description, layer.TestCapability(ogr.OLCStringsAsUTF8)), 0])
        return layer

    def write_data_to_layer(self, layer, row, field_list):
        feature = ogr.Feature(layer.GetLayerDefn())
        for field_index in range(0, len(field_list)):
            field_name, field_type, field_length = field_list[field_index]
            field_data = row[field_index]
            # self.print_log_message.emit([u"[{0}] 필드 {1} {2} {3}: {4} {5}".format(self.job.description, field_name, field_type, field_length, type(field_data), field_data), 0])
            if not field_data:
                if field_type in ('text', 'date'):
                    feature.SetField(field_index, str(''))
                elif field_type in ('integer', 'float'):
                    feature.SetField(field_index, 0)
                continue

            if field_type == 'text':
                if slen(field_data) > field_length:
                    field_data = scut(field_data, field_length)
                    self.print_log_message.emit([u"[{0}] 텍스트 길이 조정\n{1}: {2} -> {3}  ".format(self.job.description, field_name, row[field_index], field_data), 0])
                try:
                    field_data = self.convert_cp949(field_data)
                except Exception as e:
                    try:
                        field_data = unicodedata.normalize("NFKD", field_data)
                        field_data = field_data.replace(u'\u200b', u'')
                        field_data = self.convert_cp949(field_data)
                    except:
                        self.print_log_message.emit(
                            [u"[{0}] {1} 필드 쓰기 실패: {2}\n{3}".format(self.job.description, field_name, field_data, e), 1])
                        field_data = None
            elif field_type == 'date':
                    field_data = field_data.strftime('%Y-%m-%d')
            elif field_type.find('geometry') >= 0:
                geom = ogr.CreateGeometryFromWkt(field_data)
                feature.SetGeometry(geom)
                continue

            feature.SetField(field_index, field_data)
        layer.CreateFeature(feature)
        feature = None
