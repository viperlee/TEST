# -*- coding: utf-8 -*-
import os
from PyQt5 import uic
from PyQt5.QtWidgets import *
from PyQt5.Qt import *

PLUGIN_PATH = os.path.realpath(os.path.dirname(__file__))
FORM_CLASS, _ = uic.loadUiType(os.path.join(PLUGIN_PATH,  'DataProcessingDlg.ui'))


class DataProcessingDlg(QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(DataProcessingDlg, self).__init__(parent)
        self.setupUi(self)
        self.ui_list = list()
        self.option_ui = dict()
        # self.setWindowFlags(Qt.WindowStaysOnTopHint)

    def delete_ui(self):
        for i in reversed(range(self.gl_job_list.count())):
            for j in reversed(range(self.gl_job_list.columnCount())):
                widget = self.gl_job_list.itemAtPosition(i, j).widget()
                if widget is not None:
                     widget.deleteLater()
        self.ui_list = list()

    def set_title(self, title, description):
        self.setWindowTitle(title)
        self.lb_title.setText(description)

    def append_ui(self, job):
        chb = QCheckBox(self)
        chb.setMinimumWidth(150)
        chb.setText(job.description)
        chb.setTristate(False)
        chb.clicked.connect(self.start_check)
        pbar = QProgressBar(self)
        pbar.setValue(0)
        lb_elapsed_time = QLabel()
        lb_elapsed_time.setText('0 sec')
        lb_estimated_time = QLabel()
        if job.estimated_time is not None or job.estimated_time != -1:
            lb_estimated_time.setText('/ {0} sec'.format(job.estimated_time))
        else:
            lb_estimated_time.setText('/ unknown'.format(job.estimated_time))

        idx = len(self.ui_list)
        self.ui_list.append((job.description, chb, pbar, lb_elapsed_time, lb_estimated_time))
        self.gl_job_list.addWidget(chb, idx, 0)
        self.gl_job_list.addWidget(pbar, idx, 1)
        self.gl_job_list.addWidget(lb_elapsed_time, idx, 2)
        self.gl_job_list.addWidget(lb_estimated_time, idx, 3)

    def append_option_ui(self, ui_list):
        row_index = self.gl_option_list.count()
        column_index = 0
        for ui_name, widget in ui_list:
            if widget:
                self.gl_option_list.addWidget(widget, row_index, column_index)
                self.option_ui[ui_name] = widget
            column_index += 1

    def get_option_ui(self, ui_name):
        return self.option_ui[ui_name]

    def start_check(self):
        is_checked_all = self.is_checked_all()
        is_checked_none = self.is_checked_none()

        if is_checked_all:
            self.pb_check_all.setText(u'전체해제')
        else:
            self.pb_check_all.setText(u'전체선택')

        if is_checked_none:
            self.pb_start.setEnabled(Qt.Unchecked)
        else:
            self.pb_start.setEnabled(Qt.Checked)

    def init_ui(self):
        for description, chb, pbar, lb_elapsed_time, lb_estimated_time in self.ui_list:
            pbar.setValue(0)
            lb_elapsed_time.setText('0 sec')

    def get_todo_list(self):
        todo_list = list()
        idx = 0
        for description, chb, pbar, lb_elapsed_time, lb_estimated_time in self.ui_list:
            if chb.isChecked():
                todo_list.append(idx)
            idx += 1
        return todo_list

    def update_progress(self, job_index, progress_count, total_count, elipsed_time):
        description, chb, pbar, lb_elapsed_time, lb_estimated_time = self.ui_list[job_index]
        if progress_count == 0:
            pbar.setRange(0, total_count)

        pbar.setValue(progress_count)
        lb_elapsed_time.setText('{0} sec'.format(elipsed_time))

        if progress_count == total_count:
            chb.setCheckState(Qt.Unchecked)

    def enable_ui(self, enable_flag):
        for description, chb, pbar, lb_elapsed_time, lb_estimated_time in self.ui_list:
            chb.setEnabled(enable_flag)

        for widget in self.option_ui.values():
            if type(widget) == QCheckBox or type(widget) == QLineEdit:
                widget.setEnabled(enable_flag)

    def is_checked_none(self):
        for description, chb, pbar, lb_elapsed_time, lb_estimated_time in self.ui_list:
            if chb.isChecked():
                return False
        return True

    def is_checked_all(self):
        for description, chb, pbar, lb_elapsed_time, lb_estimated_time in self.ui_list:
            if not chb.isChecked():
                return False
        return True

    def check_all(self):
        is_checked_all = self.is_checked_all()
        if is_checked_all:
            for description, chb, pbar, lb_elapsed_time, lb_estimated_time in self.ui_list:
                chb.setCheckState(Qt.Unchecked)
            self.pb_check_all.setText(u'전체선택')
        else:
            for description, chb, pbar, lb_elapsed_time, lb_estimated_time in self.ui_list:
                chb.setCheckState(Qt.Checked)
            self.pb_check_all.setText(u'전체취소')

