# -*- coding: utf-8 -*-
import datetime

from .ProcessData import *


class ExecuteFunction(ProcessData):
    def __init__(self):
        super(ExecuteFunction, self).__init__()

    def run(self):
        if not self.job:
            return

        if not self.job.callback:
            return

        start_time = datetime.datetime.now()
        self.print_log_message.emit([u'[{0}] 작업 시작'.format(self.job.description), 0])
        try:
            ret = self.job.callback(self.update_progress,
                                    self.print_log_message,
                                    self.job.job_index,
                                    self.job.args)
            if not ret:
                self.terminate = True
                self.print_log_message.emit([u'[{0}] 작업 취소'.format(self.job.description), 0])
        except Exception as e:
            self.terminate = True
            self.print_log_message.emit([u'[{0}] 작업 취소 function 오류\n{1} '.format(self.job.description, e.args), 0])

        self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
        self.print_log_message.emit([u'[{0}] 작업 종료'.format(self.job.description), 0])

