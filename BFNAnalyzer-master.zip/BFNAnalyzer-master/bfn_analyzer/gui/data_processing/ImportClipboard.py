# -*- coding: utf-8 -*-
from .ImportData import *


class ImportClipboard(ImportData):

    def __init__(self):
        super(ImportClipboard, self).__init__()
