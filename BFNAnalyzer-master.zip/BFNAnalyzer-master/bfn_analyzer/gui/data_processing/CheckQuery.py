# -*- coding: utf-8 -*-

from PyQt5.QtCore import pyqtSignal
from bfn_analyzer.utilities.log import *
from bfn_analyzer.utilities.util_etc import *
from .ExecuteQuery import ExecuteQuery


class CheckQuery(ExecuteQuery):
    send_result = pyqtSignal(list)

    def __init__(self):
        super(CheckQuery, self).__init__()
        self.print_results = True

    def run(self):
        if not self.job:
            return

        debug = False
        if debug:
            self.print_log_message.emit([u'[{0}] all script \r\n{1}'.format(self.job.description, self.job.get_sql()), 0])

        start_time = datetime.datetime.now()
        sql_list = self.get_sql_list()  # type :list
        self.update_progress.emit([self.job.job_index, 0, len(sql_list), self.elapsed_time])
        self.print_log_message.emit([u'[{0}] 작업 시작'.format(self.job.description), 0])
        progress_count = 0
        total_count = len(sql_list)
        for sql in sql_list:
            if self.terminate:
                break
            progress_count += 1
            ret, row_cnt, results = self.execute_sql(sql, exec_type=1)
            if not ret:
                self.terminate = True
                self.print_log_message.emit([u'[{0}] 작업 취소'.format(self.job.description), 0])
                return

            self.elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
            self.update_progress.emit([self.job.job_index, progress_count, total_count, self.elapsed_time])
            self.print_log_message.emit([u'[{0}] 오류 대상이 {1}개 검출 되었습니다. ({2}/{3})'.format(self.job.description, len(results), progress_count, total_count), 0])
            if len(results) > 0:
                self.send_result.emit(results)
                if self.print_results:
                    self.print_log_message.emit([u'sql: {0}'.format(sql), 0])
                    for row in results:
                        self.print_log_message.emit([u'{0}'.format(', '.join(map(unicode, row))), 0])
        self.print_log_message.emit([u'[{0}] 검수 종료'.format(self.job.description), 0])



