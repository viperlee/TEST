# -*- coding: utf-8 -*-
import os
from PyQt5 import uic
from PyQt5.QtWidgets import *
from PyQt5.Qt import *
from bfn_analyzer.utilities.DbManager import *

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'LoadDBDlg.ui'))

class LoadDBDlg(QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(LoadDBDlg, self).__init__(parent)
        self.setupUi(self)
        self.setModal(True)
        self.selected_db_name = None
        self.selected_rb = None  #type: QRadioButton
        self.rb_new = self.add_radio_db(u'신규 DB 생성')
        self.le_new_db = QLineEdit()
        self.le_new_db.setText('bfn_')
        self.le_new_db.setEnabled(False)
        self.vl_db_list.addWidget(self.le_new_db)
        self.pb_drop_selected_db.clicked.connect(self.drop_selected_db)

    def add_radio_db(self, db_name):
        rb_db = QRadioButton(self)
        rb_db.setText(db_name)
        rb_db.clicked.connect(self.select_db)
        self.vl_db_list.addWidget(rb_db)
        return rb_db

    def select_db(self):
        self.selected_rb = self.sender()  # type: QRadioButton

        self.selected_db_name = self.selected_rb.text()
        if self.selected_db_name == u'신규 DB 생성':
            self.le_new_db.setEnabled(True)
        else:
            self.le_new_db.setEnabled(False)

    def get_selected_db_name(self):
        return self.selected_db_name

    def get_new_db_name(self):
        return self.le_new_db.text()

    def drop_selected_db(self):
        if not self.selected_db_name:
            message_box = QMessageBox()
            message_box.setText(u"선택된 DB가 없습니다..")
            return
        if self.selected_db_name in (u'신규 DB 생성', u'bfn_template'):
            message_box = QMessageBox()
            message_box.setText(u"삭제할 수 없는 DB입니다.")
            return
        message_box = QMessageBox()
        message_box.setText(u"DB에 연결된 모든 커넥션들을 해제 합니다. DB를 삭제하시겠습니까?")
        message_box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        result = message_box.exec_()
        if result != QMessageBox.Yes:
            return

        db_manager = DbManager.get_instance()
        db_manager.drop_database(self.selected_db_name)
        message_box = QMessageBox()
        message_box.setText(u"삭제가 완료되었습니다.")
        self.selected_rb.setEnabled(False)
        self.rb_new.setChecked(True)
