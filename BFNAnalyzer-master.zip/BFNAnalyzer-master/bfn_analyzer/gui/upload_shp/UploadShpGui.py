# -*- coding: utf-8 -*-

from qgis.gui import QgsFileWidget
from bfn_analyzer.utilities.patterns import Singleton
from bfn_analyzer.utilities.DbManager import DbManager
from ..data_processing.DataProcessingUiBase import *


class UploadShpGui(DataProcessingUiBase, Singleton):
    def __init__(self):
        DataProcessingUiBase.__init__(self)
        self.using_multi_thread = False
        self.set_title(u'지하시설물 Shape 업로드', u'지하시설물 Shape 업로드')

    def append_option_ui(self):
        self._append_option_item('shp_file_path', u'Shape file 디렉토리', QgsFileWidget)
        self.get_option_ui('shp_file_path').setStorageMode(QgsFileWidget.GetDirectory)

    def set_job_info(self):
        self.proc_name = 'upload_shp'
        db_manager = DbManager.get_instance()
        self.default_db_uri = db_manager.get_current_db_info()

    def update_job_from_ui(self):
        dir_path = self.get_option_ui('shp_file_path').filePath()
        for job in self.all_jobs:
            if job.description == 'swl_pipe_lm.shp':
                job.file_path = os.path.join(dir_path, 'SWL_PIPE_LM.shp')
                job.layer_name = 'swl_pipe_lm'
                job.srid = u'5186'
            elif job.description == 'swl_dept_ps.shp':
                job.file_path = os.path.join(dir_path, 'SWL_DEPT_PS.shp')
                job.layer_name = 'swl_dept_ps'
                job.srid = u'5186'
        return True
