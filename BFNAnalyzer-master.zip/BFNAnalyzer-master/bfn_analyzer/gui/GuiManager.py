# -*- coding: utf-8 -*-
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QAction, QDialog
from qgis.core import QgsDataSourceUri, QgsProject, QgsLayerTreeGroup, QgsVectorLayer, QgsPointXY

from bfn_analyzer.utilities.patterns import Singleton
from bfn_analyzer.utilities.util_etc import *
from .load_db.LoadDBDlg import *
from .login.LoginDlg import *
from .upload_shp.UploadShpGui import *
from .generate_network.GenerateNetwork import *
from .analyze_network.AnalyzeNetwork import *
from .Settings import *
from .ProjectManager import *
from bfn_analyzer.core.LayerManager import *

# from bfn_analyzer.tms.weblayers.weblayer_registry import WebLayerTypeRegistry
# from bfn_analyzer.tms.weblayers.daum_maps import (OlDaumStreetLayer,
#                                   OlDaumHybridLayer,
#                                   OlDaumSatelliteLayer,
#                                   OlDaumPhysicalLayer,
#                                   OlDaumCadstralLayer)
# from bfn_analyzer.tms.openlayers_layer import *


class GuiManager(Singleton):
    def __init__(self):
        self.iface = None

        # Declare instance attributes
        self.actions = dict()
        self.event_list = list()
        # self._olLayerTypeRegistry = WebLayerTypeRegistry(self)

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        disconnect_event(self.event_list)
        const = Const.get_instance()
        for action in self.actions.values():
            self.iface.removePluginMenu(
                self.tr(const.PLUGIN_NAME),
                action)
            self.iface.removeToolBarIcon(action)


    def set_iface(self, iface):
        self.iface = iface

    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('BfnAnalyzer', message)

    def add_action(self, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True,
                   status_tip=None, whats_this=None,parent=None):
        const = Const.get_instance()
        icon = QIcon(const.IMG_RES_PATH + text)
        action = QAction(icon, self.tr(text), parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            # Adds plugin icon to Plugins toolbar
            self.iface.addToolBarIcon(action)

        if add_to_menu:
            self.iface.addPluginToMenu(self.tr(const.PLUGIN_NAME), action)
        self.actions[text] = action

        return action

    def enable_actions(self, action_names, enable):
        """
        액션 명칭 리스트에 대한 액션들을 enable/disable 시킨다.
        :param action_names: 액션 명칭 리스트, list of string
        :param enable: enable/disable, bool
        :return: None
        """
        for action_name in action_names:
            action = self.actions[action_name]
            if action:
                action.setEnabled(enable)

    def init_gui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        const = Const.get_instance()
        self.add_action(
            text=const.ACTION_NAME_LOGIN,
            callback=self.login,
            parent=self.iface.mainWindow())
        self.add_action(
            text=const.ACTION_NAME_LOGOUT,
            callback=self.logout,
            parent=self.iface.mainWindow())
        self.add_action(
            text=const.ACTION_NAME_SAVE_STYLE,
            callback=self.save_styles,
            parent=self.iface.mainWindow())
        self.add_action(
            text=const.ACTION_NAME_LOAD_DB,
            callback=self.load_db,
            parent=self.iface.mainWindow())
        self.add_action(
            text=const.ACTION_NAME_RELOAD_LAYERS,
            callback=self.load_layers,
            parent=self.iface.mainWindow())
        self.add_action(
            text=const.ACTION_NAME_UPLOAD_SHP,
            callback=self.upload_data,
            parent=self.iface.mainWindow())
        self.add_action(
            text=const.ACTION_NAME_GENERATE_NETWORK,
            callback=self.generate_network,
            parent=self.iface.mainWindow())
        self.add_action(
            text=const.ACTION_NAME_ANALYZE_NETWORK,
            callback=self.analyze_network,
            parent=self.iface.mainWindow())

        const = Const.get_instance()
        action_list = (const.ACTION_NAME_LOGOUT,
                       const.ACTION_NAME_SAVE_STYLE,
                       const.ACTION_NAME_RELOAD_LAYERS,
                       const.ACTION_NAME_LOAD_DB,
                       const.ACTION_NAME_UPLOAD_SHP,
                       const.ACTION_NAME_GENERATE_NETWORK,
                       const.ACTION_NAME_ANALYZE_NETWORK
                       )

        self.enable_actions(action_list, False)
        self.enable_actions([const.ACTION_NAME_LOGIN], True)

        # # Kakao Maps - 5181
        # self._olLayerTypeRegistry.register(OlDaumStreetLayer())
        # self._olLayerTypeRegistry.register(OlDaumHybridLayer())
        # self._olLayerTypeRegistry.register(OlDaumSatelliteLayer())
        # self._olLayerTypeRegistry.register(OlDaumPhysicalLayer())
        # self._olLayerTypeRegistry.register(OlDaumCadstralLayer())

    def login(self):
        login_dlg = LoginDlg()
        login_dlg.show()
        if login_dlg.exec_() != QDialog.Accepted:
            return
        login_dlg.update_login_info()
        id = login_dlg.get_id()
        pw = login_dlg.get_password()

        db_manager = DbManager.get_instance()
        const = Const.get_instance()
        db_manager.set_common_db_info([const.db_host, "5432", "common", id, pw])

        ret = db_manager.connect_db(db_manager.get_common_db_info(), False)
        if not ret:
            return

        const = Const.get_instance()
        action_list = (const.ACTION_NAME_LOGOUT,
                       const.ACTION_NAME_SAVE_STYLE,
                       const.ACTION_NAME_RELOAD_LAYERS,
                       const.ACTION_NAME_LOAD_DB,
                       const.ACTION_NAME_UPLOAD_SHP,
                       const.ACTION_NAME_GENERATE_NETWORK,
                       const.ACTION_NAME_ANALYZE_NETWORK,
                       )
        self.enable_actions(action_list, True)
        self.enable_actions([const.ACTION_NAME_LOGIN], False)

        self.load_db()

    def logout(self):
        disconnect_event(self.event_list)
        const = Const.get_instance()
        action_list = (const.ACTION_NAME_LOGOUT,
                       const.ACTION_NAME_SAVE_STYLE,
                       const.ACTION_NAME_RELOAD_LAYERS,
                       const.ACTION_NAME_LOAD_DB,
                       const.ACTION_NAME_UPLOAD_SHP,
                       const.ACTION_NAME_GENERATE_NETWORK,
                       const.ACTION_NAME_ANALYZE_NETWORK
                       )
        self.enable_actions(action_list, False)
        self.enable_actions([const.ACTION_NAME_LOGIN], True)
        self.iface.mapCanvas().setRenderFlag(False)
        self.remove_layers()
        self.iface.mapCanvas().setRenderFlag(True)

    def load_db(self):
        load_db_dlg = LoadDBDlg()
        const = Const.get_instance()
        db_manager = DbManager.get_instance()
        db_list = db_manager.get_db_list('bfn_', db_manager.common_db_uri)
        for db_name in db_list:
            if db_name == 'bfn_template':
                continue
            load_db_dlg.add_radio_db(db_name)

        load_db_dlg.show()
        if load_db_dlg.exec_() != QDialog.Accepted:
            return

        current_db_name = load_db_dlg.get_selected_db_name()
        if not current_db_name:
            return

        if current_db_name == u'신규 DB 생성':
            new_db_name = load_db_dlg.get_new_db_name()
            if len(new_db_name) <= len('bfn_'):
                return

            if not db_manager.create_new_database(new_db_name, "bfn_template"):
                return
            common_db = db_manager.get_common_db_info()
            db_manager.set_current_db_info(
                [const.db_host, "5432", new_db_name, common_db.username(), common_db.password()])
            self.load_layers()
            # self.generate_shoot_network()
            return
        else:
            common_db = db_manager.get_common_db_info()
            db_manager.set_current_db_info(
                [const.db_host, "5432", current_db_name, common_db.username(), common_db.password()])
            self.load_layers()

    def load_last_point(self):
        settings = Settings.get_instance()  # type: Settings
        if not settings.get_last_position():
            return
        scale, center_x, center_y = settings.get_last_position()
        self.iface.mapCanvas().zoomScale(scale)
        center_pos = QgsPointXY(center_x, center_y)
        self.iface.mapCanvas().setCenter(center_pos)
        disconnect_event(self.event_list)
        self.event_list = [[self.iface.mapCanvas().extentsChanged, self.save_last_point]]
        disconnect_event(self.event_list)
        connect_event(self.event_list)

    def save_last_point(self):
        settings = Settings.get_instance()  # type: Settings
        canvas = self.iface.mapCanvas()
        settings.save_last_position(canvas.scale(), canvas.center().x(), canvas.center().y())

    def upload_data(self):
        gui = UploadShpGui.get_instance()
        gui.dlg.show()
        result = gui.dlg.exec_()

    def generate_network(self):
        gui = GenerateNetwork.get_instance()
        gui.dlg.show()
        result = gui.dlg.exec_()

    def analyze_network(self):
        gui = AnalyzeNetwork.get_instance()
        gui.dlg.show()
        result = gui.dlg.exec_()

    def remove_layers(self):
        root = QgsProject.instance().layerTreeRoot()  # type: QgsLayerTreeGroup
        root.removeAllChildren()
        layer_manager = LayerManager.get_instance()
        layer_manager.remove_layers()

    def load_layers(self):
        layer_manager = LayerManager.get_instance()
        self.iface.mapCanvas().setRenderFlag(False)
        self.remove_layers()
        root = QgsProject.instance().layerTreeRoot()  # type: QgsLayerTreeGroup
        layer_manager.load_layers()
        for group_name, layer_name, geom_field, order_idx, view_check in layer_manager.layer_infos:
            layer_group = None
            for child_node in root.children():
                if isinstance(child_node, QgsLayerTreeGroup):
                    if child_node.name() == group_name:
                        layer_group = child_node
                        break
            if not layer_group:
                layer_group = root.addGroup(group_name)

            layer = layer_manager.get_layer(layer_name)
            if not layer:
                continue
            QgsProject.instance().addMapLayer(layer, False)
            layer_group.addLayer(layer)

            layer_tree = root.findLayer(layer.id())  # type: QgsLayerTreeLayer
            if layer_tree is not None:
                layer_tree.setItemVisibilityChecked(2 if view_check == 1 else 0)

        self.iface.mapCanvas().setRenderFlag(True)
        # self.open_project()
        # iface.currentLayerChanged.connect(self.current_layer_changed)
        # iface.actionSaveProject().setVisible(False)
        # iface.actionSaveProjectAs().setVisible(False)
        # iface.actionOpenProject().setVisible(False)

        self.event_list = [[self.iface.mapCanvas().renderStarting, self.load_last_point]]
        disconnect_event(self.event_list)
        connect_event(self.event_list)

    def save_styles(self):
        msg = QMessageBox()
        msg.setWindowTitle(u'스타일 저장')
        msg.setText(u'현재 스타일을 DB에 저장하시겠습니까?')
        msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        if msg.exec_() != QMessageBox.Ok:
            return

        # project_manager = ProjectManager.get_instance()
        # project_manager.upload_qgs_project()

        layer_order = 0
        layer_manager = LayerManager.get_instance()
        root = QgsProject.instance().layerTreeRoot()  # type: QgsLayerTreeGroup
        const = Const.get_instance()
        db_manager = DbManager.get_instance()  # type: DbManager
        qry = u"DELETE FROM {0} WHERE group_name > ''".format(const.TABLE_NAME_USER_STYLE)
        db_manager.execute_sql(db_manager.get_common_db_info(), qry, ExecuteType.EXECUTE)

        for group_node in root.children():
            if not isinstance(group_node, QgsLayerTreeGroup):
                continue

            group_name = group_node.name()
            for layer_node in group_node.children():
                if not isinstance(layer_node, QgsLayerTreeLayer):
                    continue
                layer_name = layer_node.name()
                layer = layer_manager.get_layer(layer_name)
                if not layer:
                    continue

                layer.saveNamedStyle(get_temporary_file_name(layer_name, 'qml'))
                layer_tree = root.findLayer(layer.id())  # type: QgsLayerTreeLayer
                view_check = 1
                if layer_tree is not None:
                    view_check = 0 if layer_tree.isVisible() == 0 else 1

                layer_manager.upload_layer_style(group_name, layer_name, view_check, layer_order)
                layer_order += 1

    def open_project(self):
        """
        DB로 부터 QGIS Project파일을 열고, Layer를 다시 불러온다.
        이후 Layer의 스타일도 불러온다.

        :param project_name:
        :param layer_list:
        :return:
        """
        project_manager = ProjectManager.get_instance()
        project_file_name = project_manager.download_qgs_project()

        proj = QgsProject.instance()                                    # type: QgsProject
        const = Const.get_instance()
        if project_file_name is not None:
            proj.clear()
            proj.read(QFileInfo(project_file_name))
            proj.setObjectName(const.PLUGIN_SIMPLE_NAME)
            db_manager = DbManager.get_instance()
            self.iface.mainWindow().setWindowTitle('{0} - {1}'.format(QGis.QGIS_VERSION, db_manager.current_db_name))

        # self.reset_tree_layer()
        # self.make_layer_tree(layer_list)
