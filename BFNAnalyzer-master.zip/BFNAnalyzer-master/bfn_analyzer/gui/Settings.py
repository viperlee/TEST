# -*- coding: utf-8 -*-
import os
import math
import bz2
import binascii
import collections

from bfn_analyzer.utilities.patterns import *
from bfn_analyzer.utilities.registry_util import *

class Settings(Singleton):
    def __init__(self):
        pass

    ###############
    # 최종 위치 저장
    ###############
    @staticmethod
    def save_last_position(scale, center_x, center_y):
        settings = ResgistryUtil.get_instance()
        settings.set_value("scale", str(scale), group='last_position')
        settings.set_value("center_x", str(center_x), group='last_position')
        settings.set_value("center_y", str(center_y), group='last_position')

    @staticmethod
    def get_last_position():
        settings = ResgistryUtil.get_instance()
        try:
            scale = float(settings.get_value("scale", group='last_position'))
            center_x = float(settings.get_value("center_x", group='last_position'))
            center_y = float(settings.get_value("center_y", group='last_position'))
        except:
            # scale, center_x, center_y = 2000.0, 948194.354, 1947904.568
            return

        return [scale, center_x, center_y]
