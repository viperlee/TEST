drop table if exists db_proc_query;
create table db_proc_query
(
	mid serial primary key,
	proc_type text, 
	proc_name text,
	query text, 
	seq integer, 
	estimated_time integer default -1, 
	description text

);

create index db_proc_query_n1 on db_proc_query(proc_name);


insert into db_proc_query(proc_type, proc_name, seq, description, query) values
(
'ImportShp',
'upload_shp',
1,
'swl_pipe_lm.shp',
'
drop table if exists swl_pipe_lm;
create table public.swl_pipe_lm(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	sba_cde text,
	mop_cde text,
	lit_cde text,
	for_cde text,
	std_dip float,
	std_hol float,
	std_vel float,
	byc_len float,
	beg_dep float,
	end_dep float,
	sbk_hsl float,
	sbl_hsl float,
	pip_slp float,
	sph_lin integer,
	bst_ara float,
	drt_ara float,
	sbq_spd float,
	sbr_spd float,
	cnt_num text,
	bom_cde text,
	bom_idn integer,
	eom_cde text,
	eom_idn text,
	sys_chk text,
	pip_lbl text,
	iqt_cde text,
	ugid text,
	sht_idx text,
	rsm_wgt float,
	dep_cde text,
	dip_cde text,
	mdl_pth text,
	geom geometry(LineStringZ, 5186)
);

alter table public.swl_pipe_lm owner to bfna_user;
create index swl_pipe_lm_ggeom on swl_pipe_lm using gist(geom);
COMMENT ON TABLE public.swl_pipe_lm IS ''하수관로'';
COMMENT ON COLUMN swl_pipe_lm.ftr_cde IS ''지형지물부호'';
COMMENT ON COLUMN swl_pipe_lm.ftr_idn IS ''관리번호'';
COMMENT ON COLUMN swl_pipe_lm.hjd_cde IS ''행정읍면동코드'';
COMMENT ON COLUMN swl_pipe_lm.sht_num IS ''도엽번호'';
COMMENT ON COLUMN swl_pipe_lm.mng_cde IS ''관리기관코드'';
COMMENT ON COLUMN swl_pipe_lm.ist_ymd IS ''설치일자'';
COMMENT ON COLUMN swl_pipe_lm.sba_cde IS ''하수관용도'';
COMMENT ON COLUMN swl_pipe_lm.mop_cde IS ''관재질'';
COMMENT ON COLUMN swl_pipe_lm.lit_cde IS ''규모'';
COMMENT ON COLUMN swl_pipe_lm.for_cde IS ''시설물형태'';
COMMENT ON COLUMN swl_pipe_lm.std_dip IS ''관경'';
COMMENT ON COLUMN swl_pipe_lm.std_hol IS ''가로길이'';
COMMENT ON COLUMN swl_pipe_lm.std_vel IS ''세로길이'';
COMMENT ON COLUMN swl_pipe_lm.byc_len IS ''연장'';
COMMENT ON COLUMN swl_pipe_lm.beg_dep IS ''시점깊이'';
COMMENT ON COLUMN swl_pipe_lm.end_dep IS ''종점깊이'';
COMMENT ON COLUMN swl_pipe_lm.sbk_hsl IS ''시점관저고'';
COMMENT ON COLUMN swl_pipe_lm.sbl_hsl IS ''종점관저고'';
COMMENT ON COLUMN swl_pipe_lm.pip_slp IS ''평균구배'';
COMMENT ON COLUMN swl_pipe_lm.sph_lin IS ''차선통로수'';
COMMENT ON COLUMN swl_pipe_lm.bst_ara IS ''우수배수면적'';
COMMENT ON COLUMN swl_pipe_lm.drt_ara IS ''오수배수면적'';
COMMENT ON COLUMN swl_pipe_lm.sbq_spd IS ''우천시_유속'';
COMMENT ON COLUMN swl_pipe_lm.sbr_spd IS ''청천시_유속'';
COMMENT ON COLUMN swl_pipe_lm.cnt_num IS ''공사번호'';
COMMENT ON COLUMN swl_pipe_lm.bom_cde IS ''시점맨홀지형지물부호'';
COMMENT ON COLUMN swl_pipe_lm.bom_idn IS ''시점맨홀관리번호'';
COMMENT ON COLUMN swl_pipe_lm.eom_cde IS ''종점맨홀지형지물부호'';
COMMENT ON COLUMN swl_pipe_lm.eom_idn IS ''종점맨홀관리번호'';
COMMENT ON COLUMN swl_pipe_lm.sys_chk IS ''대장초기화여부'';
COMMENT ON COLUMN swl_pipe_lm.pip_lbl IS ''관라벨'';
COMMENT ON COLUMN swl_pipe_lm.iqt_cde IS ''탐사구분'';
COMMENT ON COLUMN swl_pipe_lm.ugid    IS ''3D고유식별코드'';
COMMENT ON COLUMN swl_pipe_lm.sht_idx IS ''5000도엽번호'';
COMMENT ON COLUMN swl_pipe_lm.rsm_wgt IS ''위험도가중치'';
COMMENT ON COLUMN swl_pipe_lm.dep_cde IS ''심도적용구분'';
COMMENT ON COLUMN swl_pipe_lm.dip_cde IS ''관경적용구분'';
COMMENT ON COLUMN swl_pipe_lm.mdl_pth IS ''3DS모델명'';
insert into swl_pipe_lm(ftr_cde, ftr_idn, hjd_cde, sht_num, mng_cde, ist_ymd, sba_cde, mop_cde, lit_cde, for_cde, std_dip, std_hol, std_vel, byc_len, beg_dep, end_dep, sbk_hsl, sbl_hsl, pip_slp, sph_lin, bst_ara, drt_ara, sbq_spd, sbr_spd, cnt_num, bom_cde, bom_idn, eom_cde, eom_idn, sys_chk, pip_lbl, iqt_cde, ugid, sht_idx, rsm_wgt, geom) values 
'
);


insert into db_proc_query(proc_type, proc_name, seq, description, query) values
(
'ImportShp',
'upload_shp',
2,
'swl_dept_ps.shp',
'
drop table if exists swl_dept_ps;
create table public.swl_dept_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	pip_dep float,
	geom geometry(PointZ, 5186)
);

alter table public.swl_dept_ps owner to bfna_user;

COMMENT ON TABLE public.swl_dept_ps IS ''하수관로심도'';
COMMENT ON COLUMN swl_dept_ps.ftr_cde IS ''지형지물부호'';
COMMENT ON COLUMN swl_dept_ps.ftr_idn IS ''관리번호'';
COMMENT ON COLUMN swl_dept_ps.hjd_cde IS ''행정읍면동코드'';
COMMENT ON COLUMN swl_dept_ps.pip_dep IS ''심도'';

insert into swl_dept_ps(ftr_cde, pip_dep, ftr_idn, hjd_cde, geom) values 
'
);



insert into db_proc_query(proc_type, proc_name, seq, description, query) values
(
'ExecuteQuery',
'generate_network',
1,
'swl_pipe_lm 네트워크 생성',
'

drop table if exists swl_pipe_lm_link;
create table public.swl_pipe_lm_link(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	sba_cde text,
	mop_cde text,
	lit_cde text,
	for_cde text,
	std_dip float,
	std_hol float,
	std_vel float,
	byc_len float,
	beg_dep float,
	end_dep float,
	sbk_hsl float,
	sbl_hsl float,
	pip_slp float,
	sph_lin integer,
	bst_ara float,
	drt_ara float,
	sbq_spd float,
	sbr_spd float,
	cnt_num text,
	bom_cde text,
	bom_idn integer,
	eom_cde text,
	eom_idn text,
	sys_chk text,
	pip_lbl text,
	iqt_cde text,
	ugid text,
	sht_idx text,
	rsm_wgt float,
	dep_cde text,
	dip_cde text,
	mdl_pth text,
	geom geometry(LineStringZ, 5186)
);

alter table public.swl_pipe_lm_link owner to bfna_user;
COMMENT ON TABLE public.swl_pipe_lm_link IS ''하수관로'';
COMMENT ON COLUMN swl_pipe_lm_link.ftr_cde IS ''지형지물부호'';
COMMENT ON COLUMN swl_pipe_lm_link.ftr_idn IS ''관리번호'';
COMMENT ON COLUMN swl_pipe_lm_link.hjd_cde IS ''행정읍면동코드'';
COMMENT ON COLUMN swl_pipe_lm_link.sht_num IS ''도엽번호'';
COMMENT ON COLUMN swl_pipe_lm_link.mng_cde IS ''관리기관코드'';
COMMENT ON COLUMN swl_pipe_lm_link.ist_ymd IS ''설치일자'';
COMMENT ON COLUMN swl_pipe_lm_link.sba_cde IS ''하수관용도'';
COMMENT ON COLUMN swl_pipe_lm_link.mop_cde IS ''관재질'';
COMMENT ON COLUMN swl_pipe_lm_link.lit_cde IS ''규모'';
COMMENT ON COLUMN swl_pipe_lm_link.for_cde IS ''시설물형태'';
COMMENT ON COLUMN swl_pipe_lm_link.std_dip IS ''관경'';
COMMENT ON COLUMN swl_pipe_lm_link.std_hol IS ''가로길이'';
COMMENT ON COLUMN swl_pipe_lm_link.std_vel IS ''세로길이'';
COMMENT ON COLUMN swl_pipe_lm_link.byc_len IS ''연장'';
COMMENT ON COLUMN swl_pipe_lm_link.beg_dep IS ''시점깊이'';
COMMENT ON COLUMN swl_pipe_lm_link.end_dep IS ''종점깊이'';
COMMENT ON COLUMN swl_pipe_lm_link.sbk_hsl IS ''시점관저고'';
COMMENT ON COLUMN swl_pipe_lm_link.sbl_hsl IS ''종점관저고'';
COMMENT ON COLUMN swl_pipe_lm_link.pip_slp IS ''평균구배'';
COMMENT ON COLUMN swl_pipe_lm_link.sph_lin IS ''차선통로수'';
COMMENT ON COLUMN swl_pipe_lm_link.bst_ara IS ''우수배수면적'';
COMMENT ON COLUMN swl_pipe_lm_link.drt_ara IS ''오수배수면적'';
COMMENT ON COLUMN swl_pipe_lm_link.sbq_spd IS ''우천시_유속'';
COMMENT ON COLUMN swl_pipe_lm_link.sbr_spd IS ''청천시_유속'';
COMMENT ON COLUMN swl_pipe_lm_link.cnt_num IS ''공사번호'';
COMMENT ON COLUMN swl_pipe_lm_link.bom_cde IS ''시점맨홀지형지물부호'';
COMMENT ON COLUMN swl_pipe_lm_link.bom_idn IS ''시점맨홀관리번호'';
COMMENT ON COLUMN swl_pipe_lm_link.eom_cde IS ''종점맨홀지형지물부호'';
COMMENT ON COLUMN swl_pipe_lm_link.eom_idn IS ''종점맨홀관리번호'';
COMMENT ON COLUMN swl_pipe_lm_link.sys_chk IS ''대장초기화여부'';
COMMENT ON COLUMN swl_pipe_lm_link.pip_lbl IS ''관라벨'';
COMMENT ON COLUMN swl_pipe_lm_link.iqt_cde IS ''탐사구분'';
COMMENT ON COLUMN swl_pipe_lm_link.ugid    IS ''3D고유식별코드'';
COMMENT ON COLUMN swl_pipe_lm_link.sht_idx IS ''5000도엽번호'';
COMMENT ON COLUMN swl_pipe_lm_link.rsm_wgt IS ''위험도가중치'';
COMMENT ON COLUMN swl_pipe_lm_link.dep_cde IS ''심도적용구분'';
COMMENT ON COLUMN swl_pipe_lm_link.dip_cde IS ''관경적용구분'';
COMMENT ON COLUMN swl_pipe_lm_link.mdl_pth IS ''3DS모델명'';

insert into swl_pipe_lm_link(ftr_cde, ftr_idn, hjd_cde, sht_num, mng_cde, ist_ymd, sba_cde, mop_cde, lit_cde, for_cde, std_dip, std_hol, std_vel, byc_len, beg_dep, end_dep, sbk_hsl, sbl_hsl, pip_slp, sph_lin, bst_ara, drt_ara, sbq_spd, sbr_spd, cnt_num, bom_cde, bom_idn, eom_cde, eom_idn, sys_chk, pip_lbl, iqt_cde, ugid, sht_idx, rsm_wgt, geom)
select ftr_cde, ftr_idn, hjd_cde, sht_num, mng_cde, ist_ymd, sba_cde, mop_cde, lit_cde, for_cde, std_dip, std_hol, std_vel, byc_len, beg_dep, end_dep, sbk_hsl, sbl_hsl, pip_slp, sph_lin, bst_ara, drt_ara, sbq_spd, sbr_spd, cnt_num, bom_cde, bom_idn, eom_cde, eom_idn, sys_chk, pip_lbl, iqt_cde, ugid, sht_idx, rsm_wgt, 
	set_link_z(geom, beg_dep, end_dep)
from swl_pipe_lm
;
create index swl_pipe_lm_link_ggeom on swl_pipe_lm_link using gist(geom);


drop table if exists swl_pipe_lm_cn_info;
create table swl_pipe_lm_cn_info
(
	mid serial primary key,
	node_id integer,
	link_id bigint,
	depth float,
	min_depth float,
	max_depth float,
	ord integer,
	geom geometry(PointZ,5186)
);
COMMENT ON TABLE public.swl_pipe_lm IS ''하수관로NW연결정보'';
COMMENT ON COLUMN swl_pipe_lm_cn_info.mid IS ''id'';
COMMENT ON COLUMN swl_pipe_lm_cn_info.node_id IS ''node_id'';
COMMENT ON COLUMN swl_pipe_lm_cn_info.link_id IS ''link_id'';
COMMENT ON COLUMN swl_pipe_lm_cn_info.depth IS ''깊이'';
COMMENT ON COLUMN swl_pipe_lm_cn_info.min_depth IS ''min 깊이'';
COMMENT ON COLUMN swl_pipe_lm_cn_info.max_depth IS ''max 깊이'';
COMMENT ON COLUMN swl_pipe_lm_cn_info.ord IS ''link연결순서'';


insert into swl_pipe_lm_cn_info(link_id, depth, min_depth, max_depth, geom)
select ftr_idn, beg_dep, beg_dep, beg_dep, 
	st_setsrid(st_makepoint(st_x(st_startpoint(geom)), st_y(st_startpoint(geom)), beg_dep),5186) as geom
from swl_pipe_lm
union all
select ftr_idn, end_dep, end_dep, end_dep, 
	st_setsrid(st_makepoint(st_x(st_endpoint(geom)), st_y(st_endpoint(geom)), beg_dep),5186) as geom
from swl_pipe_lm
;
create index swl_pipe_lm_cn_info_ggeom on swl_pipe_lm_cn_info using gist(geom);

update swl_pipe_lm_cn_info
set node_id = mid;

-- ------------------------
$merge_sql;
-- ------------------------

update swl_pipe_lm_cn_info as a
set ord = b.rank
from (
	select mid, rank() over( partition by node_id order by depth, mid) as rank
	from swl_pipe_lm_cn_info
) as b
where a.mid = b.mid;

drop table if exists swl_pipe_lm_node;
create table swl_pipe_lm_node(
	mid integer primary key, 
	cn_num integer, 
	min_depth float,
	max_depth float,
	cn_id1 bigint default 0, 
	cn_depth1 float,
	cn_id2 bigint default 0, 
	cn_depth2 float,
	cn_id3 bigint default 0,
	cn_depth3 float,
	cn_id4 bigint default 0,
	cn_depth4 float,
	cn_id5 bigint default 0,
	cn_depth5 float,
	cn_id6 bigint default 0,
	cn_depth6 float,
	cn_id7 bigint default 0,
	cn_depth7 float,
	cn_id8 bigint default 0,
	cn_depth8 float,
	cn_id9 bigint default 0,
	cn_depth9 float,
	cn_id10 bigint default 0,
	cn_depth10 float,
	geom geometry(PointZ, 5186)
);

COMMENT ON TABLE public.swl_pipe_lm_node IS ''하수관로노드'';
COMMENT ON COLUMN swl_pipe_lm_node.mid is ''id'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_num is ''연결링크 수'';
COMMENT ON COLUMN swl_pipe_lm_node.min_depth is ''min깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.max_depth is ''max깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id1 is ''연결링크1'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id2 is ''연결링크2'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id3 is ''연결링크3'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id4 is ''연결링크4'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id5 is ''연결링크5'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id6 is ''연결링크6'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id7 is ''연결링크7'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id8 is ''연결링크8'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id9 is ''연결링크9'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_id10 is ''연결링크10'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth1 is ''연결링크1깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth2 is ''연결링크2깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth3 is ''연결링크3깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth4 is ''연결링크4깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth5 is ''연결링크5깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth6 is ''연결링크6깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth7 is ''연결링크7깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth8 is ''연결링크8깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth9 is ''연결링크9깊이'';
COMMENT ON COLUMN swl_pipe_lm_node.cn_depth10 is ''연결링크10깊이'';


insert into swl_pipe_lm_node(mid, cn_num)
select node_id , count(1) as cn_num
from swl_pipe_lm_cn_info
group by node_id ;

update swl_pipe_lm_node as a
set geom = b.geom
from swl_pipe_lm_cn_info as b
where a.mid = b.mid;

update swl_pipe_lm_node as a
set cn_id1 = link_id, cn_depth1 = b.depth,
	min_depth = b.min_depth,
	max_depth = b.max_depth, 
	geom = st_setsrid(st_makepoint(st_x(b.geom), st_y(b.geom), b.depth),5186)
from swl_pipe_lm_cn_info as b
where a.mid = b.node_id
and ord = 1;

update swl_pipe_lm_node as a
set cn_id2 = link_id, cn_depth2 = b.depth,
	min_depth = least(a.min_depth, b.min_depth),
	max_depth = greatest(a.max_depth, b.max_depth)
from swl_pipe_lm_cn_info as b
where a.mid = b.node_id
and ord = 2;

update swl_pipe_lm_node as a
set cn_id3 = link_id, cn_depth3 = b.depth,
	min_depth = least(a.min_depth, b.min_depth),
	max_depth = greatest(a.max_depth, b.max_depth)
from swl_pipe_lm_cn_info as b
where a.mid = b.node_id
and ord = 3;

update swl_pipe_lm_node as a
set cn_id4 = link_id, cn_depth4 = b.depth,
	min_depth = least(a.min_depth, b.min_depth),
	max_depth = greatest(a.max_depth, b.max_depth)
from swl_pipe_lm_cn_info as b
where a.mid = b.node_id
and ord = 4;

update swl_pipe_lm_node as a
set cn_id5 = link_id, cn_depth5 = b.depth,
	min_depth = least(a.min_depth, b.min_depth),
	max_depth = greatest(a.max_depth, b.max_depth)
from swl_pipe_lm_cn_info as b
where a.mid = b.node_id
and ord = 5;

update swl_pipe_lm_node as a
set cn_id6 = link_id, cn_depth6 = b.depth,
	min_depth = least(a.min_depth, b.min_depth),
	max_depth = greatest(a.max_depth, b.max_depth)
from swl_pipe_lm_cn_info as b
where a.mid = b.node_id
and ord = 6;

update swl_pipe_lm_node as a
set cn_id7 = link_id, cn_depth7 = b.depth,
	min_depth = least(a.min_depth, b.min_depth),
	max_depth = greatest(a.max_depth, b.max_depth)
from swl_pipe_lm_cn_info as b
where a.mid = b.node_id
and ord = 7;

update swl_pipe_lm_node as a
set cn_id8 = link_id, cn_depth8 = b.depth,
	min_depth = least(a.min_depth, b.min_depth),
	max_depth = greatest(a.max_depth, b.max_depth)
from swl_pipe_lm_cn_info as b
where a.mid
 = b.node_id
and ord = 8;

update swl_pipe_lm_node as a
set cn_id9 = link_id, cn_depth9 = b.depth,
	min_depth = least(a.min_depth, b.min_depth),
	max_depth = greatest(a.max_depth, b.max_depth)
from swl_pipe_lm_cn_info as b
where a.mid
 = b.node_id
and ord = 9;

update swl_pipe_lm_node as a
set cn_id10 = link_id, cn_depth10 = b.depth,
	min_depth = least(a.min_depth, b.min_depth),
	max_depth = greatest(a.max_depth, b.max_depth)
from swl_pipe_lm_cn_info as b
where a.mid
 = b.node_id
and ord = 10;

create index swl_pipe_lm_node_ggeom on swl_pipe_lm_node using gist(geom);



'
);



insert into db_proc_query(proc_type, proc_name, seq, description, query) values
(
'ExecuteQuery',
'generate_network',
2,
'swl_pipe_lm_link 교차 커브 삭제',
'

drop table if exists swl_pipe_lm_cross;
create table swl_pipe_lm_cross
(
	mid serial primary key,
	ftr_idn bigint,
	rank integer,
	geom geometry(PointZ, 5186)
);


insert into swl_pipe_lm_cross(ftr_idn, geom)
select a.ftr_idn, 
	st_intersection(a.geom, b.geom) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	  and st_numgeometries(st_intersection(a.geom, b.geom)) = 1
	 and ST_NumPoints(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4))) > 4
union all
select a.ftr_idn, 
	st_geometryN(st_intersection(a.geom, b.geom),1) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	 and st_numgeometries(st_intersection(a.geom, b.geom)) > 1
	 and ST_NumPoints(st_intersection(a.geom, st_buffer(st_geometryN(st_intersection(a.geom, b.geom),1), 1, 4))) > 4
union all
select a.ftr_idn, 
	st_geometryN(st_intersection(a.geom, b.geom),2) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	 and st_numgeometries(st_intersection(a.geom, b.geom)) >= 2
	 and ST_NumPoints(st_intersection(a.geom, st_buffer(st_geometryN(st_intersection(a.geom, b.geom),2), 1, 4))) > 4
union all
select a.ftr_idn, 
	st_geometryN(st_intersection(a.geom, b.geom),3) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	 and st_numgeometries(st_intersection(a.geom, b.geom)) >= 3
	 and ST_NumPoints(st_intersection(a.geom, st_buffer(st_geometryN(st_intersection(a.geom, b.geom),3), 1, 4))) > 4
union all
select a.ftr_idn, 
	st_geometryN(st_intersection(a.geom, b.geom),4) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	 and st_numgeometries(st_intersection(a.geom, b.geom)) >= 4
	 and ST_NumPoints(st_intersection(a.geom, st_buffer(st_geometryN(st_intersection(a.geom, b.geom),4), 1, 4))) > 4
union all
select a.ftr_idn, 
	st_geometryN(st_intersection(a.geom, b.geom),5) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	 and st_numgeometries(st_intersection(a.geom, b.geom)) >= 5
	 and ST_NumPoints(st_intersection(a.geom, st_buffer(st_geometryN(st_intersection(a.geom, b.geom),5), 1, 4))) > 4
union all
select a.ftr_idn, 
	st_intersection(a.geom, b.geom) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	  and st_numgeometries(st_intersection(a.geom, b.geom)) = 1
	  and st_numgeometries(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4))) > 1
	 and ST_NumPoints(st_geometryN(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4)),1)) > 4
union all
select a.ftr_idn, 
	st_intersection(a.geom, b.geom) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	  and st_numgeometries(st_intersection(a.geom, b.geom)) = 1
	  and st_numgeometries(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4))) >= 2
	 and ST_NumPoints(st_geometryN(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4)),2)) > 4
union all
select a.ftr_idn, 
	st_intersection(a.geom, b.geom) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	  and st_numgeometries(st_intersection(a.geom, b.geom)) = 1
	  and st_numgeometries(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4))) >= 3
	 and ST_NumPoints(st_geometryN(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4)),3)) > 4
union all
select a.ftr_idn, 
	st_intersection(a.geom, b.geom) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	  and st_numgeometries(st_intersection(a.geom, b.geom)) = 1
	  and st_numgeometries(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4))) >= 4
	 and ST_NumPoints(st_geometryN(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4)),4)) > 4
union all 
select a.ftr_idn, 
	st_intersection(a.geom, b.geom) as geom
from swl_pipe_lm_link as a, swl_pipe_lm_link as b
where st_intersects(a.geom, b.geom)
	and a.ftr_idn != b.ftr_idn
	and not st_intersects(st_intersection(a.geom, b.geom),st_startpoint(a.geom))
	 and not st_intersects(st_intersection(a.geom, b.geom), st_endpoint(a.geom))
	  and st_numgeometries(st_intersection(a.geom, b.geom)) = 1
	  and st_numgeometries(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4))) >= 5
	 and ST_NumPoints(st_geometryN(st_intersection(a.geom, st_buffer(st_intersection(a.geom, b.geom), 1, 4)),5)) > 4
;

update swl_pipe_lm_cross as a
set rank = b.rank
from (
select ftr_idn, mid,
	rank() over (partition by ftr_idn order by mid) as rank
from swl_pipe_lm_cross
) as b
where a.mid = b.mid;
;
create index swl_pipe_lm_cross_n1 on swl_pipe_lm_cross(ftr_idn);
create index swl_pipe_lm_cross_ggeom on swl_pipe_lm_cross using gist(geom);


-- max rank
-- select max(rank) from swl_pipe_lm_cross 
-- 

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 1
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;
update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 2
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;
update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 3
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 4
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;


update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 5
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;
update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 6
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 7
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 8
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 9
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 10
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 11
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 12
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 13
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 14
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 15
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;

update swl_pipe_lm_link as a
set geom = b.new_geom
from (
select a.ftr_idn , remove_curv_vtx(b.geom, a.geom, 1.0) as new_geom
from swl_pipe_lm_cross as a, swl_pipe_lm_link as b
where a.rank = 16
and a.ftr_idn = b.ftr_idn
) as b
where a.ftr_idn = b.ftr_idn 
;
'
);

insert into db_proc_query(proc_type, proc_name, seq, description, query) values
(
'ExecuteQuery',
'generate_network',
3,
' 불필요한 노드 삭제(연결 링크가 두 개인 노드)',
'
-- 불필요한 노드 삭제
drop table if exists swl_pipe_lm_2link;
create temp table swl_pipe_lm_2link
(
mid integer primary key,
cn_id1 bigint,
cn_id2 bigint,
beg_depth float,
end_depth float,
beg_geom geometry(PointZ,5186),
end_geom geometry(PointZ,5186),
geom geometry(LineStringZ, 5186)
);

insert into swl_pipe_lm_2link(mid, cn_id1, cn_id2, geom)
select a.mid, a.cn_id1, a.cn_id2, st_linemerge(st_union(b.geom, c.geom)) as geom
from swl_pipe_lm_node as a, swl_pipe_lm_link as b, swl_pipe_lm_link as c
where a.cn_num = 2
and a.cn_id1 = b.ftr_idn
and a.cn_id2 = c.ftr_idn
and b.sba_cde = c.sba_cde -- 하수관 용도
and b.mop_cde = c.mop_cde -- 관재질
and b.std_dip = c.std_dip -- 관경
and GeometryType (st_linemerge(st_union(b.geom, c.geom))) = ''LINESTRING'';

-- link1 - link2 - link3 인 형태로 link2-link3는 이번 대상에서 제외하고 다음에 다시 돌린다.
delete from swl_pipe_lm_2link as a
using (
	select b.mid
	from swl_pipe_lm_2link as a , swl_pipe_lm_2link as b
	where a.cn_id2 = b.cn_id1
	) as b
where a.mid = b.mid
;

-- 시종점 속성이 변경
update swl_pipe_lm_2link
set beg_geom = st_startpoint(geom), 
    end_geom = st_endpoint(geom)
  ;

update swl_pipe_lm_2link as a 
set beg_depth = b.beg_dep
from swl_pipe_lm_link as b
where a.cn_id1 = b.ftr_idn
and a.beg_geom = st_startpoint(b.geom)
;

update swl_pipe_lm_2link as a
set beg_depth = b.end_dep
from swl_pipe_lm_link as b
where a.cn_id1 = b.ftr_idn
and a.beg_geom = st_endpoint(b.geom)
;

update swl_pipe_lm_2link as a 
set end_depth = b.beg_dep
from swl_pipe_lm_link as b
where a.cn_id1 = b.ftr_idn
and a.end_geom = st_startpoint(b.geom)
;

update swl_pipe_lm_2link as a
set end_depth = b.end_dep
from swl_pipe_lm_link as b
where a.cn_id1 = b.ftr_idn
and a.end_geom = st_endpoint(b.geom)
;

update swl_pipe_lm_2link as a 
set beg_depth = b.beg_dep
from swl_pipe_lm_link as b
where a.cn_id2 = b.ftr_idn
and a.beg_geom = st_startpoint(b.geom)
;

update swl_pipe_lm_2link as a
set beg_depth = b.end_dep
from swl_pipe_lm_link as b
where a.cn_id2 = b.ftr_idn
and a.beg_geom = st_endpoint(b.geom)
;

update swl_pipe_lm_2link as a 
set end_depth = b.beg_dep
from swl_pipe_lm_link as b
where a.cn_id2 = b.ftr_idn
and a.end_geom = st_startpoint(b.geom)
;

update swl_pipe_lm_2link as a
set end_depth = b.end_dep
from swl_pipe_lm_link as b
where a.cn_id2 = b.ftr_idn
and a.end_geom = st_endpoint(b.geom)
;

-- 처음 링크에는 속성 업데이트 / 두번째 링크는 삭제
update swl_pipe_lm_link as a
set beg_dep = b.beg_depth,
    end_dep = b.end_depth,
    geom = b.geom
from swl_pipe_lm_2link as b
where a.ftr_idn = cn_id1
;

delete from swl_pipe_lm_link as a
using swl_pipe_lm_2link  as b
where a.ftr_idn = cn_id2
;

-- 노드 연결정보 삭제
update swl_pipe_lm_node as a set cn_id1 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id1 = b.cn_id2;
update swl_pipe_lm_node as a set cn_id2 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id2 = b.cn_id2;
update swl_pipe_lm_node as a set cn_id3 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id3 = b.cn_id2;
update swl_pipe_lm_node as a set cn_id4 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id4 = b.cn_id2;
update swl_pipe_lm_node as a set cn_id5 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id5 = b.cn_id2;
update swl_pipe_lm_node as a set cn_id6 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id6 = b.cn_id2;
update swl_pipe_lm_node as a set cn_id7 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id7 = b.cn_id2;
update swl_pipe_lm_node as a set cn_id8 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id8 = b.cn_id2;
update swl_pipe_lm_node as a set cn_id9 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id9 = b.cn_id2;
update swl_pipe_lm_node as a set cn_id10 = b.cn_id1 from swl_pipe_lm_2link as b where a.cn_id10 = b.cn_id2;

-- 노드 삭제
delete from swl_pipe_lm_node as a
using swl_pipe_lm_2link as b
where a.mid = b.mid
;
'
);


drop table if exists load_layers;
create table load_layers
(
	mid serial primary key,
	group_name text,
	layer_name text,
	geom_field text, 
	loading_ord int
);
insert into load_layers(group_name, layer_name, geom_field, loading_ord) values
('swl_network','swl_pipe_lm_cross','geom',1),
('swl_network','swl_pipe_lm_link','geom',2),
('swl_network','swl_pipe_lm_node','geom', 3),

('shp_org','swl_dept_ps','geom', 1),
('shp_org','swl_pipe_lm','geom', 2);


drop table if exists layer_styles;
create table layer_styles(
	id serial primary key,
	f_table_catalog text,
	f_table_schema text,
	f_table_name text,
	f_geometry_column text,
	stylename text,
	styleqml xml,
	stylesld xml,
	useasdefault boolean,
	description text,
	owner text,
	ui xml,
	update_time timestamp without time zone,
	type character varying
);

drop table if exists user_styles;
create table user_styles
(
	mid serial primary key,
	group_name text,
	table_name text,
	geom_field text, 
	layer_order int,
	view_check int,
	style_data bytea
	
	
);
-- create database common;

-- create database bfn_template;
-- create extension postgis;
