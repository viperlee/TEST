
drop table if exists swl_clay_ps;
create table public.swl_clay_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	for_cde text,
	wol_hit float,
	mah_cde text,
	hmn_cde text,
	hmn_idn integer,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.swl_clay_ps owner to bfna_user;

COMMENT ON TABLE public.swl_clay_ps IS '우수토실';
COMMENT ON COLUMN swl_clay_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_clay_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_clay_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_clay_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_clay_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_clay_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_clay_ps.for_cde IS '시설물형태';
COMMENT ON COLUMN swl_clay_ps.wol_hit IS '월류턱높이';
COMMENT ON COLUMN swl_clay_ps.mah_cde IS '맨홀존재여부';
COMMENT ON COLUMN swl_clay_ps.hmn_cde IS '하수맨홀지형지물부호';
COMMENT ON COLUMN swl_clay_ps.hmn_idn IS '하수맨홀관리번호';
COMMENT ON COLUMN swl_clay_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_clay_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_clay_ps.ang_dir IS '방향각';



drop table if exists swl_conn_ls;
create table public.swl_conn_ls(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	sba_cde text,
	mop_cde text,
	for_cde text,
	std_dip float,
	std_hol float,
	std_vel float,
	byc_len float,
	sph_lin integer,
	pip_slp float,
	cnt_num text,
	sys_chk text,
	pip_lbl text
);

alter table public.swl_conn_ls owner to bfna_user;

COMMENT ON TABLE public.swl_conn_ls IS '하수연결관';
COMMENT ON COLUMN swl_conn_ls.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_conn_ls.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_conn_ls.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_conn_ls.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_conn_ls.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_conn_ls.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_conn_ls.sba_cde IS '하수관용도';
COMMENT ON COLUMN swl_conn_ls.mop_cde IS '관재질';
COMMENT ON COLUMN swl_conn_ls.for_cde IS '시설물형태';
COMMENT ON COLUMN swl_conn_ls.std_dip IS '관경';
COMMENT ON COLUMN swl_conn_ls.std_hol IS '가로길이';
COMMENT ON COLUMN swl_conn_ls.std_vel IS '세로길이';
COMMENT ON COLUMN swl_conn_ls.byc_len IS '연장';
COMMENT ON COLUMN swl_conn_ls.sph_lin IS '차선통로수';
COMMENT ON COLUMN swl_conn_ls.pip_slp IS '평균구배';
COMMENT ON COLUMN swl_conn_ls.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_conn_ls.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_conn_ls.pip_lbl IS '관라벨';





drop table if exists swl_dran_ps;
create table public.swl_dran_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	drn_nam text,
	gai_ara float,
	soo_cde text,
	adp_ara float,
	sbb_cde text,
	pcc_vol integer,
	puc_vol integer,
	qw1_exp text,
	qw2_exp text,
	pip_len float,
	dra_nam text,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.swl_dran_ps owner to bfna_user;

COMMENT ON TABLE public.swl_dran_ps IS '하수처리장';
COMMENT ON COLUMN swl_dran_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_dran_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_dran_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_dran_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_dran_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_dran_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_dran_ps.drn_nam IS '하수처리장명';
COMMENT ON COLUMN swl_dran_ps.gai_ara IS '부지면적';
COMMENT ON COLUMN swl_dran_ps.soo_cde IS '개통상태';
COMMENT ON COLUMN swl_dran_ps.adp_ara IS '처리구역면적';
COMMENT ON COLUMN swl_dran_ps.sbb_cde IS '하수처리방식';
COMMENT ON COLUMN swl_dran_ps.pcc_vol IS '청천시_처리용량';
COMMENT ON COLUMN swl_dran_ps.puc_vol IS '우천시_처리용량';
COMMENT ON COLUMN swl_dran_ps.qw1_exp IS '설계유입수_수질';
COMMENT ON COLUMN swl_dran_ps.qw2_exp IS '설계유출수_수질';
COMMENT ON COLUMN swl_dran_ps.pip_len IS '차집관_연장';
COMMENT ON COLUMN swl_dran_ps.dra_nam IS '방류수역명';
COMMENT ON COLUMN swl_dran_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_dran_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_dran_ps.ang_dir IS '방향각';





drop table if exists swl_manh_ps;
create table public.swl_manh_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	ecn_ymd text,
	smu_cde text,
	for_cde text,
	som_cde text,
	man_dip float,
	man_hol float,
	man_vel float,
	sbc_cde text,
	ivt_cde text,
	lad_cde text,
	mos_hsl float,
	lms_hsl float,
	cst_cde text,
	cnt_num text,
	sys_chk text,
	ang_dir integer,
	ugid text,
	sht_idx text,
	man_dep float

);

alter table public.swl_manh_ps owner to bfna_user;

COMMENT ON TABLE public.swl_manh_ps IS '하수맨홀';
COMMENT ON COLUMN swl_manh_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_manh_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_manh_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_manh_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_manh_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_manh_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_manh_ps.ecn_ymd IS '최종준설일자';
COMMENT ON COLUMN swl_manh_ps.smu_cde IS '하수맨홀용도';
COMMENT ON COLUMN swl_manh_ps.for_cde IS '시설물형태';
COMMENT ON COLUMN swl_manh_ps.som_cde IS '맨홀종류';
COMMENT ON COLUMN swl_manh_ps.man_dip IS '하수맨홀구경';
COMMENT ON COLUMN swl_manh_ps.man_hol IS '하수맨홀가로';
COMMENT ON COLUMN swl_manh_ps.man_vel IS '하수맨홀세로';
COMMENT ON COLUMN swl_manh_ps.sbc_cde IS '뚜껑재질';
COMMENT ON COLUMN swl_manh_ps.ivt_cde IS '인버트유무';
COMMENT ON COLUMN swl_manh_ps.lad_cde IS '사다리설치유무';
COMMENT ON COLUMN swl_manh_ps.mos_hsl IS '하수맨홀_고도';
COMMENT ON COLUMN swl_manh_ps.lms_hsl IS '하수맨홀_저고';
COMMENT ON COLUMN swl_manh_ps.cst_cde IS '이상상태';
COMMENT ON COLUMN swl_manh_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_manh_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_manh_ps.ang_dir IS '방향각';
COMMENT ON COLUMN swl_manh_ps.ugid IS '3D고유식별코드'; 
COMMENT ON COLUMN swl_manh_ps.sht_idx IS '5000도엽번호';
COMMENT ON COLUMN swl_manh_ps.man_dep IS '맨홀깊이';





drop table if exists swl_pipe_lm;
create table public.swl_pipe_lm(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	sba_cde text,
	mop_cde text,
	lit_cde text,
	for_cde text,
	std_dip float,
	std_hol float,
	std_vel float,
	byc_len float,
	beg_dep float,
	end_dep float,
	sbk_hsl float,
	sbl_hsl float,
	pip_slp float,
	sph_lin integer,
	bst_ara float,
	drt_ara float,
	sbq_spd float,
	sbr_spd float,
	cnt_num text,
	bom_cde text,
	bom_idn integer,
	eom_cde text,
	eom_idn text,
	sys_chk text,
	pip_lbl text,
	iqt_cde text,
	ugid text,
	sht_idx text,
	rsm_wgt float,
	dep_cde text,
	dip_cde text,
	mdl_pth text,
	geom geometry(LineStringZ, 5186)
);

alter table public.swl_pipe_lm owner to bfna_user;

COMMENT ON TABLE public.swl_pipe_lm IS '하수관로';
COMMENT ON COLUMN swl_pipe_lm.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_pipe_lm.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_pipe_lm.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_pipe_lm.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_pipe_lm.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_pipe_lm.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_pipe_lm.sba_cde IS '하수관용도';
COMMENT ON COLUMN swl_pipe_lm.mop_cde IS '관재질';
COMMENT ON COLUMN swl_pipe_lm.lit_cde IS '규모';
COMMENT ON COLUMN swl_pipe_lm.for_cde IS '시설물형태';
COMMENT ON COLUMN swl_pipe_lm.std_dip IS '관경';
COMMENT ON COLUMN swl_pipe_lm.std_hol IS '가로길이';
COMMENT ON COLUMN swl_pipe_lm.std_vel IS '세로길이';
COMMENT ON COLUMN swl_pipe_lm.byc_len IS '연장';
COMMENT ON COLUMN swl_pipe_lm.beg_dep IS '시점깊이';
COMMENT ON COLUMN swl_pipe_lm.end_dep IS '종점깊이';
COMMENT ON COLUMN swl_pipe_lm.sbk_hsl IS '시점관저고';
COMMENT ON COLUMN swl_pipe_lm.sbl_hsl IS '종점관저고';
COMMENT ON COLUMN swl_pipe_lm.pip_slp IS '평균구배';
COMMENT ON COLUMN swl_pipe_lm.sph_lin IS '차선통로수';
COMMENT ON COLUMN swl_pipe_lm.bst_ara IS '우수배수면적';
COMMENT ON COLUMN swl_pipe_lm.drt_ara IS '오수배수면적';
COMMENT ON COLUMN swl_pipe_lm.sbq_spd IS '우천시_유속';
COMMENT ON COLUMN swl_pipe_lm.sbr_spd IS '청천시_유속';
COMMENT ON COLUMN swl_pipe_lm.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_pipe_lm.bom_cde IS '시점맨홀지형지물부호';
COMMENT ON COLUMN swl_pipe_lm.bom_idn IS '시점맨홀관리번호';
COMMENT ON COLUMN swl_pipe_lm.eom_cde IS '종점맨홀지형지물부호';
COMMENT ON COLUMN swl_pipe_lm.eom_idn IS '종점맨홀관리번호';
COMMENT ON COLUMN swl_pipe_lm.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_pipe_lm.pip_lbl IS '관라벨';
COMMENT ON COLUMN swl_pipe_lm.iqt_cde IS '탐사구분';
COMMENT ON COLUMN swl_pipe_lm.ugid    IS '3D고유식별코드';
COMMENT ON COLUMN swl_pipe_lm.sht_idx IS '5000도엽번호';
COMMENT ON COLUMN swl_pipe_lm.rsm_wgt IS '위험도가중치';
COMMENT ON COLUMN swl_pipe_lm.dep_cde IS '심도적용구분';
COMMENT ON COLUMN swl_pipe_lm.dip_cde IS '관경적용구분';
COMMENT ON COLUMN swl_pipe_lm.mdl_pth IS '3DS모델명';





drop table if exists swl_pres_ps;
create table public.swl_pres_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	prs_nam text,
	gai_ara float,
	sbs_cde text,
	ctn_vol integer,
	low_wal float,
	hgh_wal float,
	prn_wal float,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.swl_pres_ps owner to bfna_user;

COMMENT ON TABLE public.swl_pres_ps IS '유수지';
COMMENT ON COLUMN swl_pres_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_pres_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_pres_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_pres_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_pres_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_pres_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_pres_ps.prs_nam IS '유수지명';
COMMENT ON COLUMN swl_pres_ps.gai_ara IS '부지면적';
COMMENT ON COLUMN swl_pres_ps.sbs_cde IS '유수지형태';
COMMENT ON COLUMN swl_pres_ps.ctn_vol IS '저수용량';
COMMENT ON COLUMN swl_pres_ps.low_wal IS '최저수위';
COMMENT ON COLUMN swl_pres_ps.hgh_wal IS '최고수위';
COMMENT ON COLUMN swl_pres_ps.prn_wal IS '계획홍수위';
COMMENT ON COLUMN swl_pres_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_pres_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_pres_ps.ang_dir IS '방향각';



drop table if exists swl_pump_ps;
create table public.swl_pump_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	pmp_nam text,
	gai_ara float,
	soo_cde text,
	sbe_cde text,
	day_vol integer,
	max_vol integer,
	stp_hsl float,
	pmp_wal float,
	cos_vol integer,
	uos_vol integer,
	usu_vol integer,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.swl_pump_ps owner to bfna_user;

COMMENT ON TABLE public.swl_pump_ps IS '하수펌프장';
COMMENT ON COLUMN swl_pump_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_pump_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_pump_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_pump_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_pump_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_pump_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_pump_ps.pmp_nam IS '하수펌프장명';
COMMENT ON COLUMN swl_pump_ps.gai_ara IS '부지면적';
COMMENT ON COLUMN swl_pump_ps.soo_cde IS '개통상태';
COMMENT ON COLUMN swl_pump_ps.sbe_cde IS '펌프장용도';
COMMENT ON COLUMN swl_pump_ps.day_vol IS '일일처리용량';
COMMENT ON COLUMN swl_pump_ps.max_vol IS '최대저수용량';
COMMENT ON COLUMN swl_pump_ps.stp_hsl IS '표고';
COMMENT ON COLUMN swl_pump_ps.pmp_wal IS '수위';
COMMENT ON COLUMN swl_pump_ps.cos_vol IS '청천시_오수양수능력';
COMMENT ON COLUMN swl_pump_ps.uos_vol IS '우천시_오수양수능력';
COMMENT ON COLUMN swl_pump_ps.usu_vol IS '우수양수능력';
COMMENT ON COLUMN swl_pump_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_pump_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_pump_ps.ang_dir IS '방향각';




drop table if exists swl_rsph_ps;
create table public.swl_rsph_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	sba_cde text,
	for_cde text,
	mop_cde text,
	sph_dip float,
	std_hol float,
	std_vel float,
	sph_len float,
	sph_hsl float,
	sph_lin integer,
	std_slp float,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.swl_rsph_ps owner to bfna_user;

COMMENT ON TABLE public.swl_rsph_ps IS '역사이펀';
COMMENT ON COLUMN swl_rsph_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_rsph_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_rsph_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_rsph_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_rsph_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_rsph_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_rsph_ps.sba_cde IS '하수관용도';
COMMENT ON COLUMN swl_rsph_ps.for_cde IS '시설물형태';
COMMENT ON COLUMN swl_rsph_ps.mop_cde IS '관재질';
COMMENT ON COLUMN swl_rsph_ps.sph_dip IS '원형관구경';
COMMENT ON COLUMN swl_rsph_ps.std_hol IS '가로길이';
COMMENT ON COLUMN swl_rsph_ps.std_vel IS '세로길이';
COMMENT ON COLUMN swl_rsph_ps.sph_len IS '구체_연장';
COMMENT ON COLUMN swl_rsph_ps.sph_hsl IS '역사이펀관저고';
COMMENT ON COLUMN swl_rsph_ps.sph_lin IS '차선통로수';
COMMENT ON COLUMN swl_rsph_ps.std_slp IS '경사';
COMMENT ON COLUMN swl_rsph_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_rsph_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_rsph_ps.ang_dir IS '방향각';





drop table if exists swl_side_ls;
create table public.swl_side_ls(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	aeg_cde text,
	byc_len float,
	std_hol float,
	std_vel float,
	sph_lin integer,
	mop_cde text,
	cnt_num text,
	sys_chk text
);

alter table public.swl_side_ls owner to bfna_user;

COMMENT ON TABLE public.swl_side_ls IS '측구';
COMMENT ON COLUMN swl_side_ls.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_side_ls.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_side_ls.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_side_ls.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_side_ls.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_side_ls.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_side_ls.aeg_cde IS '측구구분';
COMMENT ON COLUMN swl_side_ls.byc_len IS '연장';
COMMENT ON COLUMN swl_side_ls.std_hol IS '가로길이';
COMMENT ON COLUMN swl_side_ls.std_vel IS '세로길이';
COMMENT ON COLUMN swl_side_ls.sph_lin IS '차선통로수';
COMMENT ON COLUMN swl_side_ls.mop_cde IS '관재질';
COMMENT ON COLUMN swl_side_ls.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_side_ls.sys_chk IS '대장초기화여부';





drop table if exists swl_spew_ps;
create table public.swl_spew_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	vmt_cde text,
	for_cde text,
	spw_dip float,
	spw_hol float,
	spw_vel float,
	spw_hsl float,
	spw_wal float,
	riv_nam text,
	spw_saf float,
	dra_cde text,
	dra_idn integer,
	dsp_cde text,
	dsp_idn integer,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.swl_spew_ps owner to bfna_user;

COMMENT ON TABLE public.swl_spew_ps IS '토구';
COMMENT ON COLUMN swl_spew_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_spew_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_spew_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_spew_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_spew_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_spew_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_spew_ps.vmt_cde IS '토구용도';
COMMENT ON COLUMN swl_spew_ps.for_cde IS '시설물형태';
COMMENT ON COLUMN swl_spew_ps.spw_dip IS '원형토구내경';
COMMENT ON COLUMN swl_spew_ps.spw_hol IS '각형토구가로길이';
COMMENT ON COLUMN swl_spew_ps.spw_vel IS '각형토구세로길이';
COMMENT ON COLUMN swl_spew_ps.spw_hsl IS '토구표고';
COMMENT ON COLUMN swl_spew_ps.spw_wal IS '평균수위';
COMMENT ON COLUMN swl_spew_ps.riv_nam IS '하천명';
COMMENT ON COLUMN swl_spew_ps.spw_saf IS '계획방류량';
COMMENT ON COLUMN swl_spew_ps.dra_cde IS '배수구역지형지물부호';
COMMENT ON COLUMN swl_spew_ps.dra_idn IS '배수구역관리번호';
COMMENT ON COLUMN swl_spew_ps.dsp_cde IS '처리구역지형지물부호';
COMMENT ON COLUMN swl_spew_ps.dsp_idn IS '처리구역관리번호';
COMMENT ON COLUMN swl_spew_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_spew_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_spew_ps.ang_dir IS '방향각';





drop table if exists swl_spot_ps;
create table public.swl_spot_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	ecn_ymd text,
	sbd_cde text,
	for_cde text,
	spt_dip float,
	spt_hol float,
	spt_vel float,
	spt_dep float,
	cov_cde text,
	mop_cde text,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.swl_spot_ps owner to bfna_user;

COMMENT ON TABLE public.swl_spot_ps IS '물받이';
COMMENT ON COLUMN swl_spot_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_spot_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_spot_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_spot_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_spot_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_spot_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_spot_ps.ecn_ymd IS '최종준설일자';
COMMENT ON COLUMN swl_spot_ps.sbd_cde IS '물받이용도';
COMMENT ON COLUMN swl_spot_ps.for_cde IS '시설물형태';
COMMENT ON COLUMN swl_spot_ps.spt_dip IS '원형물받이내경';
COMMENT ON COLUMN swl_spot_ps.spt_hol IS '각형물받이가로길이';
COMMENT ON COLUMN swl_spot_ps.spt_vel IS '각형물받이세로길이';
COMMENT ON COLUMN swl_spot_ps.spt_dep IS '물받이깊이';
COMMENT ON COLUMN swl_spot_ps.cov_cde IS '물받이뚜껑형태';
COMMENT ON COLUMN swl_spot_ps.mop_cde IS '관재질';
COMMENT ON COLUMN swl_spot_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_spot_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_spot_ps.ang_dir IS '방향각';





drop table if exists swl_vent_ps;
create table public.swl_vent_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	vnt_dip float,
	mop_cde text,
	mof_cde text,
	hmp_cde text,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.swl_vent_ps owner to bfna_user;

COMMENT ON TABLE public.swl_vent_ps IS '환기구';
COMMENT ON COLUMN swl_vent_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_vent_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_vent_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_vent_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_vent_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_vent_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_vent_ps.vnt_dip IS '환기구구경';
COMMENT ON COLUMN swl_vent_ps.mop_cde IS '관재질';
COMMENT ON COLUMN swl_vent_ps.mof_cde IS '흡출기형식';
COMMENT ON COLUMN swl_vent_ps.hmp_cde IS '흡출기재질';
COMMENT ON COLUMN swl_vent_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_vent_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_vent_ps.ang_dir IS '방향각';




drop table if exists swl_aodr_as;
create table public.swl_aodr_as(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	mng_cde text,
	str_ymd text,
	adr_nam text,
	ntf_num text,
	adr_ara float,
	adr_pop integer,
	riv_nam text,
	drn_cnt float,
	sys_chk text
);

alter table public.swl_aodr_as owner to bfna_user;

COMMENT ON TABLE public.swl_aodr_as IS '배수구역';
COMMENT ON COLUMN swl_aodr_as.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_aodr_as.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_aodr_as.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_aodr_as.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_aodr_as.str_ymd IS '사용개시일자';
COMMENT ON COLUMN swl_aodr_as.adr_nam IS '배수구역명';
COMMENT ON COLUMN swl_aodr_as.ntf_num IS '고시번호';
COMMENT ON COLUMN swl_aodr_as.adr_ara IS '배수구역면적';
COMMENT ON COLUMN swl_aodr_as.adr_pop IS '배수구역인구수';
COMMENT ON COLUMN swl_aodr_as.riv_nam IS '하천명';
COMMENT ON COLUMN swl_aodr_as.drn_cnt IS '유출계수';
COMMENT ON COLUMN swl_aodr_as.sys_chk IS '대장초기화여부';






drop table if exists swl_pipe_as;
create table public.swl_pipe_as(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	ugid text,
	sht_idx text
);

alter table public.swl_pipe_as owner to bfna_user;

COMMENT ON TABLE public.swl_pipe_as IS '면형하수관로';
COMMENT ON COLUMN swl_pipe_as.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_pipe_as.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_pipe_as.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_pipe_as.ugid IS '3D고유식별코드';
COMMENT ON COLUMN swl_pipe_as.sht_idx IS '5000도엽번호';




drop table if exists swl_door_as;
create table public.swl_door_as(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	mng_cde text,
	str_ymd text,
	ddr_nam text,
	ddr_ara float,
	ddr_pop integer,
	res_ara float,
	com_ara float,
	ind_ara float,
	nat_ara float,
	rn1_cnt float,
	rn2_cnt float,
	riv_nam text,
	drn_cnt float,
	sys_chk text
);

alter table public.swl_door_as owner to bfna_user;

COMMENT ON TABLE public.swl_door_as IS '배수분구';
COMMENT ON COLUMN swl_door_as.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_door_as.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_door_as.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_door_as.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_door_as.str_ymd IS '사용개시일자';
COMMENT ON COLUMN swl_door_as.ddr_nam IS '배수분구명';
COMMENT ON COLUMN swl_door_as.ddr_ara IS '배수분구면적';
COMMENT ON COLUMN swl_door_as.ddr_pop IS '배수분구인구수';
COMMENT ON COLUMN swl_door_as.res_ara IS '주거지역면적';
COMMENT ON COLUMN swl_door_as.com_ara IS '상업지역면적';
COMMENT ON COLUMN swl_door_as.ind_ara IS '공업지역면적';
COMMENT ON COLUMN swl_door_as.nat_ara IS '녹지면적';
COMMENT ON COLUMN swl_door_as.rn1_cnt IS '5년_빈도_강우강도';
COMMENT ON COLUMN swl_door_as.rn2_cnt IS '10년_빈도_강우강도';
COMMENT ON COLUMN swl_door_as.riv_nam IS '하천명';
COMMENT ON COLUMN swl_door_as.drn_cnt IS '유출계수';
COMMENT ON COLUMN swl_door_as.sys_chk IS '대장초기화여부';





drop table if exists swl_aodp_as;
create table public.swl_aodp_as(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	mng_cde text,
	str_ymd text,
	adp_nam text,
	ntf_num text,
	use_cde text,
	adp_ara float,
	adp_pop integer,
	prn_pop integer,
	sew_vol integer,
	sys_chk text
);

alter table public.swl_aodp_as owner to bfna_user;

COMMENT ON TABLE public.swl_aodp_as IS '처리구역';
COMMENT ON COLUMN swl_aodp_as.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_aodp_as.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_aodp_as.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_aodp_as.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_aodp_as.str_ymd IS '사용개시일자';
COMMENT ON COLUMN swl_aodp_as.adp_nam IS '처리구역명';
COMMENT ON COLUMN swl_aodp_as.ntf_num IS '고시번호';
COMMENT ON COLUMN swl_aodp_as.use_cde IS '용도지역';
COMMENT ON COLUMN swl_aodp_as.adp_ara IS '처리구역면적';
COMMENT ON COLUMN swl_aodp_as.adp_pop IS '처리구역인구수';
COMMENT ON COLUMN swl_aodp_as.prn_pop IS '계획처리인구수';
COMMENT ON COLUMN swl_aodp_as.sew_vol IS '오수발생량';
COMMENT ON COLUMN swl_aodp_as.sys_chk IS '대장초기화여부';



drop table if exists swl_dept_ps;
create table public.swl_dept_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	pip_dep float,
	geom geometry(PointZ, 5186)
);

alter table public.swl_dept_ps owner to bfna_user;

COMMENT ON TABLE public.swl_dept_ps IS '하수관로심도';
COMMENT ON COLUMN swl_dept_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_dept_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_dept_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_dept_ps.pip_dep IS '심도';




drop table if exists swl_clpi_lm;
create table public.swl_clpi_lm(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	sba_cde text,
	mop_cde text,
	lit_cde text,
	for_cde text,
	std_dip float,
	std_hol float,
	std_vel float,
	byc_len float,
	beg_dep float,
	end_dep float,
	sbk_hsl float,
	sbl_hsl float,
	pip_slp float,
	sph_lin integer,
	sbo_ara float,
	drt_ara float,
	sbq_spd float,
	sbr_spd float,
	cnt_num text,
	bom_cde text,
	bom_idn integer,
	eom_cde text,
	eom_idn integer,
	sys_chk text,
	pip_lbl text
);

alter table public.swl_clpi_lm owner to bfna_user;

COMMENT ON TABLE public.swl_clpi_lm IS '하수폐관로';
COMMENT ON COLUMN swl_clpi_lm.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_clpi_lm.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_clpi_lm.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_clpi_lm.sht_num IS '도엽번호';
COMMENT ON COLUMN swl_clpi_lm.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_clpi_lm.ist_ymd IS '설치일자';
COMMENT ON COLUMN swl_clpi_lm.sba_cde IS '하수관용도';
COMMENT ON COLUMN swl_clpi_lm.mop_cde IS '관재질';
COMMENT ON COLUMN swl_clpi_lm.lit_cde IS '규모';
COMMENT ON COLUMN swl_clpi_lm.for_cde IS '시설물형태';
COMMENT ON COLUMN swl_clpi_lm.std_dip IS '관경';
COMMENT ON COLUMN swl_clpi_lm.std_hol IS '가로길이';
COMMENT ON COLUMN swl_clpi_lm.std_vel IS '세로길이';
COMMENT ON COLUMN swl_clpi_lm.byc_len IS '연장';
COMMENT ON COLUMN swl_clpi_lm.beg_dep IS '시점깊이';
COMMENT ON COLUMN swl_clpi_lm.end_dep IS '종점깊이';
COMMENT ON COLUMN swl_clpi_lm.sbk_hsl IS '시점관저고';
COMMENT ON COLUMN swl_clpi_lm.sbl_hsl IS '종점관저고';
COMMENT ON COLUMN swl_clpi_lm.pip_slp IS '평균구배';
COMMENT ON COLUMN swl_clpi_lm.sph_lin IS '차선통로수';
COMMENT ON COLUMN swl_clpi_lm.sbo_ara IS '폐관우수배수면적';
COMMENT ON COLUMN swl_clpi_lm.drt_ara IS '오수배수면적';
COMMENT ON COLUMN swl_clpi_lm.sbq_spd IS '우천시유속';
COMMENT ON COLUMN swl_clpi_lm.sbr_spd IS '청천시유속';
COMMENT ON COLUMN swl_clpi_lm.cnt_num IS '공사번호';
COMMENT ON COLUMN swl_clpi_lm.bom_cde IS '시점맨홀지형지물부호';
COMMENT ON COLUMN swl_clpi_lm.bom_idn IS '시점맨홀관리번호';
COMMENT ON COLUMN swl_clpi_lm.eom_cde IS '종점맨홀지형지물부호';
COMMENT ON COLUMN swl_clpi_lm.eom_idn IS '종점맨홀관리번호';
COMMENT ON COLUMN swl_clpi_lm.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN swl_clpi_lm.pip_lbl IS '관라벨';




drop table if exists swl_clde_ps;
create table public.swl_clde_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	pip_dep float
);

alter table public.swl_clde_ps owner to bfna_user;

COMMENT ON TABLE public.swl_clde_ps IS '하수폐관심도';
COMMENT ON COLUMN swl_clde_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_clde_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_clde_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_clde_ps.pip_dep IS '심도';



drop table if exists swl_dodp_as;
create table public.swl_dodp_as(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	mng_cde text,
	str_ymd text,
	ddp_nam text,
	ddp_ara float,
	ddp_pop integer,
	prn_pop integer,
	res_ara float,
	com_ara float,
	ind_ara float,
	sew_vol integer,
	sys_chk text
);

alter table public.swl_dodp_as owner to bfna_user;

COMMENT ON TABLE public.swl_dodp_as IS '처리분구';
COMMENT ON COLUMN swl_dodp_as.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN swl_dodp_as.ftr_idn IS '관리번호';
COMMENT ON COLUMN swl_dodp_as.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN swl_dodp_as.mng_cde IS '관리기관코드';
COMMENT ON COLUMN swl_dodp_as.str_ymd IS '사용개시일자';
COMMENT ON COLUMN swl_dodp_as.ddp_nam IS '처리분구명';
COMMENT ON COLUMN swl_dodp_as.ddp_ara IS '처리분구면적';
COMMENT ON COLUMN swl_dodp_as.ddp_pop IS '처리분구인구수';
COMMENT ON COLUMN swl_dodp_as.prn_pop IS '계획처리인구수';
COMMENT ON COLUMN swl_dodp_as.res_ara IS '주거지역면적';
COMMENT ON COLUMN swl_dodp_as.com_ara IS '상업지역면적';
COMMENT ON COLUMN swl_dodp_as.ind_ara IS '공업지역면적';
COMMENT ON COLUMN swl_dodp_as.sew_vol IS '오수발생량';
COMMENT ON COLUMN swl_dodp_as.sys_chk IS '대장초기화여부';




