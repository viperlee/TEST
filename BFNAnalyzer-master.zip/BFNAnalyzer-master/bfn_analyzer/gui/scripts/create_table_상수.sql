drop table if exists wtl_fire_ps;
create table public.wtl_fire_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	hom_num text,
	mof_cde text,
	fir_dip float,
	std_dip float,
	sup_hit float, 
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.wtl_fire_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_fire_ps IS '소방시설';
COMMENT ON COLUMN wtl_fire_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_fire_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_fire_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_fire_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_fire_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_fire_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_fire_ps.hom_num IS '수용가번호';
COMMENT ON COLUMN wtl_fire_ps.mof_cde IS '소화전형식';
COMMENT ON COLUMN wtl_fire_ps.fir_dip IS '소화전구경';
COMMENT ON COLUMN wtl_fire_ps.std_dip IS '관경';
COMMENT ON COLUMN wtl_fire_ps.sup_hit IS '급수탑높이';
COMMENT ON COLUMN wtl_fire_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_fire_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN wtl_fire_ps.ang_dir IS '방향각';




drop table if exists wtl_flow_ps;
create table public.wtl_flow_ps(
	ftr_cde	text,
	ftr_idn	bigint primary key,
	hjd_cde	text,
	sht_num	text,
	mng_cde	text,
	ist_ymd	text,
	gag_cde	text,
	mof_cde	text,
	std_dip	integer,
	prc_nam	text,
	pip_cde	text,
	pip_idn	integer,
	cnt_num	text,
	sys_chk	text,
	ang_dir	integer
);

alter table public.wtl_flow_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_flow_ps IS '유량계';
COMMENT ON COLUMN wtl_flow_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_flow_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_flow_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_flow_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_flow_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_flow_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_flow_ps.gag_cde IS '유량계종류';
COMMENT ON COLUMN wtl_flow_ps.mof_cde IS '유량계형식';
COMMENT ON COLUMN wtl_flow_ps.std_dip IS '관경';
COMMENT ON COLUMN wtl_flow_ps.prc_nam IS '제작회사명';
COMMENT ON COLUMN wtl_flow_ps.pip_cde IS '관로지형지물부호';
COMMENT ON COLUMN wtl_flow_ps.pip_idn IS '관로관리번호';
COMMENT ON COLUMN wtl_flow_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_flow_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN wtl_flow_ps.ang_dir IS '방향각';






drop table if exists wtl_gain_ps;
create table public.wtl_gain_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	fns_ymd text,
	gai_nam text,
	wsr_cde text,
	wss_nam text,
	aga_vol integer,
	hga_vol integer,
	pmp_cnt float,
	gai_ara float,
	wrw_cde text,
	wgw_cde text,
	cnt_num text,
	sys_chk text
);

alter table public.wtl_gain_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_gain_ps IS '취수장';
COMMENT ON COLUMN wtl_gain_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_gain_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_gain_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_gain_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_gain_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_gain_ps.fns_ymd IS '준공일자';
COMMENT ON COLUMN wtl_gain_ps.gai_nam IS '취수장명';
COMMENT ON COLUMN wtl_gain_ps.wsr_cde IS '수원구분';
COMMENT ON COLUMN wtl_gain_ps.wss_nam IS '수계명';
COMMENT ON COLUMN wtl_gain_ps.aga_vol IS '평균취수량';
COMMENT ON COLUMN wtl_gain_ps.hga_vol IS '최대취수량';
COMMENT ON COLUMN wtl_gain_ps.pmp_cnt IS '펌프대수';
COMMENT ON COLUMN wtl_gain_ps.gai_ara IS '부지면적';
COMMENT ON COLUMN wtl_gain_ps.wrw_cde IS '도수방법';
COMMENT ON COLUMN wtl_gain_ps.wgw_cde IS '취수방법';
COMMENT ON COLUMN wtl_gain_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_gain_ps.sys_chk IS '대장초기화여부';



	

drop table if exists wtl_head_ps;
create table public.wtl_head_ps(
ftr_cde text, 
ftr_idn bigint primary key,
hjd_cde text,
sht_num text,
mng_cde text,
fns_ymd text,
hea_nam text,
wsr_cde text,
riv_nam text,
rsv_vol integer,
rsv_ara integer,
ful_ara integer,
thr_wal integer,
hth_wal integer,
avg_wal integer,
dra_wal integer,
hdr_wal integer,
kee_wal integer,
gua_ara integer,
gua_pop integer,
cnt_num text,
sys_chk text
	
);

alter table public.wtl_head_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_head_ps IS '수원지';
COMMENT ON COLUMN wtl_head_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_head_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_head_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_head_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_head_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_head_ps.fns_ymd IS '준공일자';
COMMENT ON COLUMN wtl_head_ps.hea_nam IS '수원지명';
COMMENT ON COLUMN wtl_head_ps.wsr_cde IS '수원구분';
COMMENT ON COLUMN wtl_head_ps.riv_nam IS '하천명';
COMMENT ON COLUMN wtl_head_ps.rsv_vol IS '유효저수량';
COMMENT ON COLUMN wtl_head_ps.rsv_ara IS '유역면적';
COMMENT ON COLUMN wtl_head_ps.ful_ara IS '만수면적';
COMMENT ON COLUMN wtl_head_ps.thr_wal IS '갈수위';
COMMENT ON COLUMN wtl_head_ps.hth_wal IS '최대갈수위';
COMMENT ON COLUMN wtl_head_ps.avg_wal IS '평수위';
COMMENT ON COLUMN wtl_head_ps.dra_wal IS '홍수위';
COMMENT ON COLUMN wtl_head_ps.hdr_wal IS '최대홍수위';
COMMENT ON COLUMN wtl_head_ps.kee_wal IS '사수위';
COMMENT ON COLUMN wtl_head_ps.gua_ara IS '상수원보호구역면적';
COMMENT ON COLUMN wtl_head_ps.gua_pop IS '상수원보호구역인구';
COMMENT ON COLUMN wtl_head_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_head_ps.sys_chk IS '대장초기화여부';


	
	
	
drop table if exists wtl_leak_ps;
create table public.wtl_leak_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	rcv_num text,
	lek_ymd text,
	lek_loc text,
	pip_cde text,
	pip_idn integer,
	mop_cde text,
	std_dip float,
	lrs_cde text,
	lep_cde text,
	lek_exp text,
	rep_ymd text,
	rep_exp text,
	mat_des text,
	rep_nam text,
	sys_chk text
);

alter table public.wtl_leak_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_leak_ps IS '누수지점 및 복구내역';
COMMENT ON COLUMN wtl_leak_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_leak_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_leak_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_leak_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_leak_ps.rcv_num IS '민원접수번호';
COMMENT ON COLUMN wtl_leak_ps.lek_ymd IS '누수일자';
COMMENT ON COLUMN wtl_leak_ps.lek_loc IS '누수위치설명';
COMMENT ON COLUMN wtl_leak_ps.pip_cde IS '관로지형지물부호';
COMMENT ON COLUMN wtl_leak_ps.pip_idn IS '관로관리번호';
COMMENT ON COLUMN wtl_leak_ps.mop_cde IS '관재질';
COMMENT ON COLUMN wtl_leak_ps.std_dip IS '관경';
COMMENT ON COLUMN wtl_leak_ps.lrs_cde IS '누수원인';
COMMENT ON COLUMN wtl_leak_ps.lep_cde IS '누수부위';
COMMENT ON COLUMN wtl_leak_ps.lek_exp IS '누수현황';
COMMENT ON COLUMN wtl_leak_ps.rep_ymd IS '복구일자';
COMMENT ON COLUMN wtl_leak_ps.rep_exp IS '누수복구내용';
COMMENT ON COLUMN wtl_leak_ps.mat_des IS '소요자재내역';
COMMENT ON COLUMN wtl_leak_ps.rep_nam IS '누수복구자명';
COMMENT ON COLUMN wtl_leak_ps.sys_chk IS '대장초기화여부';





drop table if exists wtl_manh_ps;
create table public.wtl_manh_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	dpg_std text,
	som_cde text,
	mhs_cde text,
	cnt_num text,
	sys_chk text,
	ang_dir integer,
	ugid text,
	sht_idx text,
	man_dep float
);

alter table public.wtl_manh_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_manh_ps IS '상수맨홀';
COMMENT ON COLUMN wtl_manh_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_manh_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_manh_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_manh_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_manh_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_manh_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_manh_ps.dpg_std IS '규격';
COMMENT ON COLUMN wtl_manh_ps.som_cde IS '맨홀종류';
COMMENT ON COLUMN wtl_manh_ps.mhs_cde IS '맨홀형태';
COMMENT ON COLUMN wtl_manh_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_manh_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN wtl_manh_ps.ang_dir IS '방향각';
COMMENT ON COLUMN wtl_manh_ps.ugid	  IS '3D고유식별코드';
COMMENT ON COLUMN wtl_manh_ps.sht_idx IS '5000도엽번호';
COMMENT ON COLUMN wtl_manh_ps.man_dep IS '맨홀깊이';





drop table if exists wtl_meta_ps;
create table public.wtl_meta_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	ist_ymd text,
	hom_num text,
	hom_nam text,
	hom_cde text,
	hom_adr text,
	hom_cnt integer,
	sbi_cde text,
	met_num text,
	met_dip float,
	mof_cde text,
	prd_nam text,
	pip_cde text,
	pip_idn integer,
	cnt_num text,
	sys_chk text
);

alter table public.wtl_meta_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_meta_ps IS '급수전계량기';
COMMENT ON COLUMN wtl_meta_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_meta_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_meta_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_meta_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_meta_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_meta_ps.hom_num IS '수용가번호';
COMMENT ON COLUMN wtl_meta_ps.hom_nam IS '수용가성명';
COMMENT ON COLUMN wtl_meta_ps.hom_cde IS '수용가행정읍면동';
COMMENT ON COLUMN wtl_meta_ps.hom_adr IS '수용가주소설명';
COMMENT ON COLUMN wtl_meta_ps.hom_cnt IS '가구수';
COMMENT ON COLUMN wtl_meta_ps.sbi_cde IS '업종';
COMMENT ON COLUMN wtl_meta_ps.met_num IS '계량기기물번호';
COMMENT ON COLUMN wtl_meta_ps.met_dip IS '계량기구경';
COMMENT ON COLUMN wtl_meta_ps.mof_cde IS '계량기형식';
COMMENT ON COLUMN wtl_meta_ps.prd_nam IS '계량기제작회사명';
COMMENT ON COLUMN wtl_meta_ps.pip_cde IS '관로지형지물부호';
COMMENT ON COLUMN wtl_meta_ps.pip_idn IS '관로관리번호';
COMMENT ON COLUMN wtl_meta_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_meta_ps.sys_chk IS '대장초기화여부';





drop table if exists wtl_pipe_lm;
create table public.wtl_pipe_lm(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	saa_cde text,
	mop_cde text,
	std_dip float,
	byc_len float,
	jht_cde text,
	low_dep float,
	hgh_dep float,
	cnt_num text,
	sys_chk text,
	pip_lbl text,
	iqt_cde text,
	ugid text,
	sht_idx text,
	rsm_wgt float,
	dep_cde text,
	dip_cde text,
	mdl_pth text
);

alter table public.wtl_pipe_lm owner to bfna_user;

COMMENT ON TABLE public.wtl_pipe_lm IS '상수관로';
COMMENT ON COLUMN wtl_pipe_lm.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_pipe_lm.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_pipe_lm.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_pipe_lm.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_pipe_lm.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_pipe_lm.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_pipe_lm.saa_cde IS '관용도';
COMMENT ON COLUMN wtl_pipe_lm.mop_cde IS '관재질';
COMMENT ON COLUMN wtl_pipe_lm.std_dip IS '관경';
COMMENT ON COLUMN wtl_pipe_lm.byc_len IS '연장';
COMMENT ON COLUMN wtl_pipe_lm.jht_cde IS '접합종류';
COMMENT ON COLUMN wtl_pipe_lm.low_dep IS '최저깊이';
COMMENT ON COLUMN wtl_pipe_lm.hgh_dep IS '최고깊이';
COMMENT ON COLUMN wtl_pipe_lm.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_pipe_lm.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN wtl_pipe_lm.pip_lbl IS '관라벨';
COMMENT ON COLUMN wtl_pipe_lm.iqt_cde IS '탐사구분';
COMMENT ON COLUMN wtl_pipe_lm.ugid IS '3D고유식별코드';
COMMENT ON COLUMN wtl_pipe_lm.sht_idx IS '5000도엽번호';
COMMENT ON COLUMN wtl_pipe_lm.rsm_wgt IS '위험도가중치';
COMMENT ON COLUMN wtl_pipe_lm.dep_cde IS '심도적용구분';
COMMENT ON COLUMN wtl_pipe_lm.dip_cde IS '관경적용구분';
COMMENT ON COLUMN wtl_pipe_lm.mdl_pth IS '3DS모델명';








drop table if exists wtl_pres_ps;
create table public.wtl_pres_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	fns_ymd text,
	prs_nam text,
	gai_ara float,
	sag_cde text,
	prs_hsl float,
	prs_saf float,
	prs_are text,
	prs_cnt float,
	cnt_num text,
	sys_chk text
);

alter table public.wtl_pres_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_pres_ps IS '가압펌프장';
COMMENT ON COLUMN wtl_pres_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_pres_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_pres_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_pres_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_pres_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_pres_ps.fns_ymd IS '준공일자';
COMMENT ON COLUMN wtl_pres_ps.prs_nam IS '가압장명';
COMMENT ON COLUMN wtl_pres_ps.gai_ara IS '부지면적';
COMMENT ON COLUMN wtl_pres_ps.sag_cde IS '관리방법';
COMMENT ON COLUMN wtl_pres_ps.prs_hsl IS '가압장표고';
COMMENT ON COLUMN wtl_pres_ps.prs_saf IS '가압능력';
COMMENT ON COLUMN wtl_pres_ps.prs_are IS '가압구역';
COMMENT ON COLUMN wtl_pres_ps.prs_cnt IS '가압수혜가구';
COMMENT ON COLUMN wtl_pres_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_pres_ps.sys_chk IS '대장초기화여부';




drop table if exists wtl_prga_ps;
create table public.wtl_prga_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	pga_cde text,
	mof_cde text,
	std_dip float,
	std_saf float,
	avg_saf float,
	msr_saf float,
	srv_dip float,
	prc_nam text,
	pip_cde text,
	pip_idn integer,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.wtl_prga_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_prga_ps IS '수압계';
COMMENT ON COLUMN wtl_prga_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_prga_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_prga_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_prga_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_prga_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_prga_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_prga_ps.pga_cde IS '수압계종류';
COMMENT ON COLUMN wtl_prga_ps.mof_cde IS '수압계형식';
COMMENT ON COLUMN wtl_prga_ps.std_dip IS '관경';
COMMENT ON COLUMN wtl_prga_ps.std_saf IS '기준압력';
COMMENT ON COLUMN wtl_prga_ps.avg_saf IS '평균압력';
COMMENT ON COLUMN wtl_prga_ps.msr_saf IS '측정압력';
COMMENT ON COLUMN wtl_prga_ps.srv_dip IS '배수관_관경';
COMMENT ON COLUMN wtl_prga_ps.prc_nam IS '제작회사명';
COMMENT ON COLUMN wtl_prga_ps.pip_cde IS '관로지형지물부호';
COMMENT ON COLUMN wtl_prga_ps.pip_idn IS '관로관리번호';
COMMENT ON COLUMN wtl_prga_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_prga_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN wtl_prga_ps.ang_dir IS '방향각';





drop table if exists wtl_puri_as;
create table public.wtl_puri_as(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	fns_ymd text,
	pur_nam text,
	wsr_cde text,
	gai_nam text,
	srv_nam text,
	pur_vol integer,
	pwr_saf float,
	gai_ara float,
	sam_cde text,
	cnt_num text,
	sys_chk text
);

alter table public.wtl_puri_as owner to bfna_user;

COMMENT ON TABLE public.wtl_puri_as IS '정수장';
COMMENT ON COLUMN wtl_puri_as.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_puri_as.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_puri_as.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_puri_as.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_puri_as.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_puri_as.fns_ymd IS '준공일자';
COMMENT ON COLUMN wtl_puri_as.pur_nam IS '정수장명';
COMMENT ON COLUMN wtl_puri_as.wsr_cde IS '수원구분';
COMMENT ON COLUMN wtl_puri_as.gai_nam IS '취수장명';
COMMENT ON COLUMN wtl_puri_as.srv_nam IS '배수지명';
COMMENT ON COLUMN wtl_puri_as.pur_vol IS '처리용량';
COMMENT ON COLUMN wtl_puri_as.pwr_saf IS '사용전력';
COMMENT ON COLUMN wtl_puri_as.gai_ara IS '부지면적';
COMMENT ON COLUMN wtl_puri_as.sam_cde IS '여과방법';
COMMENT ON COLUMN wtl_puri_as.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_puri_as.sys_chk IS '대장초기화여부';




drop table if exists wtl_rsrv_ps;
create table public.wtl_rsrv_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	pms_ymd text,
	fns_ymd text,
	bls_cde text,
	rsr_nam text,
	own_nam text,
	own_adr text,
	own_tel text,
	mng_nam text,
	mng_adr text,
	mng_tel text,
	bld_ara float,
	tbl_ara float,
	fam_cnt float,
	bld_adr text,
	sys_chk text
);

alter table public.wtl_rsrv_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_rsrv_ps IS '저수조';
COMMENT ON COLUMN wtl_rsrv_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_rsrv_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_rsrv_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_rsrv_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_rsrv_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_rsrv_ps.pms_ymd IS '허가일자';
COMMENT ON COLUMN wtl_rsrv_ps.fns_ymd IS '준공일자';
COMMENT ON COLUMN wtl_rsrv_ps.bls_cde IS '건물유형';
COMMENT ON COLUMN wtl_rsrv_ps.rsr_nam IS '저수조명';
COMMENT ON COLUMN wtl_rsrv_ps.own_nam IS '소유자성명';
COMMENT ON COLUMN wtl_rsrv_ps.own_adr IS '소유자주소';
COMMENT ON COLUMN wtl_rsrv_ps.own_tel IS '소유자전화번호';
COMMENT ON COLUMN wtl_rsrv_ps.mng_nam IS '관리자';
COMMENT ON COLUMN wtl_rsrv_ps.mng_adr IS '관리자주소';
COMMENT ON COLUMN wtl_rsrv_ps.mng_tel IS '관리자전화번호';
COMMENT ON COLUMN wtl_rsrv_ps.bld_ara IS '건축면적';
COMMENT ON COLUMN wtl_rsrv_ps.tbl_ara IS '건축연면적';
COMMENT ON COLUMN wtl_rsrv_ps.fam_cnt IS '세대수';
COMMENT ON COLUMN wtl_rsrv_ps.bld_adr IS '건물주소';
COMMENT ON COLUMN wtl_rsrv_ps.sys_chk IS '대장초기화여부';




drop table if exists wtl_serv_ps;
create table public.wtl_serv_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	fns_ymd text,
	srv_nam text,
	pur_nam text,
	gai_ara float,
	sag_cde text,
	srv_vol integer,
	hgh_wal float,
	low_wal float,
	isr_vol integer,
	sup_are text,
	sup_pop integer,
	scw_cde text,
	cnt_num text,
	sys_chk text
);

alter table public.wtl_serv_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_serv_ps IS '배수지';
COMMENT ON COLUMN wtl_serv_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_serv_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_serv_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_serv_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_serv_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_serv_ps.fns_ymd IS '준공일자';
COMMENT ON COLUMN wtl_serv_ps.srv_nam IS '배수지명';
COMMENT ON COLUMN wtl_serv_ps.pur_nam IS '정수장명';
COMMENT ON COLUMN wtl_serv_ps.gai_ara IS '부지면적';
COMMENT ON COLUMN wtl_serv_ps.sag_cde IS '관리방법';
COMMENT ON COLUMN wtl_serv_ps.srv_vol IS '시설용량';
COMMENT ON COLUMN wtl_serv_ps.hgh_wal IS '최고수위';
COMMENT ON COLUMN wtl_serv_ps.low_wal IS '최저수위';
COMMENT ON COLUMN wtl_serv_ps.isr_vol IS '배수지유입량';
COMMENT ON COLUMN wtl_serv_ps.sup_are IS '급수지역';
COMMENT ON COLUMN wtl_serv_ps.sup_pop IS '급수인구';
COMMENT ON COLUMN wtl_serv_ps.scw_cde IS '배수지제어방법';
COMMENT ON COLUMN wtl_serv_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_serv_ps.sys_chk IS '대장초기화여부';






drop table if exists wtl_sply_ls;
create table public.wtl_sply_ls(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	saa_cde text,
	mop_cde text,
	std_dip float,
	byc_len float,
	jht_cde text,
	low_dep float,
	hgh_dep float,
	cnt_num text,
	sys_chk text,
	pip_lbl text
);

alter table public.wtl_sply_ls owner to bfna_user;

COMMENT ON TABLE public.wtl_sply_ls IS '급수관로';
COMMENT ON COLUMN wtl_sply_ls.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_sply_ls.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_sply_ls.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_sply_ls.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_sply_ls.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_sply_ls.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_sply_ls.saa_cde IS '관용도';
COMMENT ON COLUMN wtl_sply_ls.mop_cde IS '관재질';
COMMENT ON COLUMN wtl_sply_ls.std_dip IS '관경';
COMMENT ON COLUMN wtl_sply_ls.byc_len IS '연장';
COMMENT ON COLUMN wtl_sply_ls.jht_cde IS '접합종류';
COMMENT ON COLUMN wtl_sply_ls.low_dep IS '최저깊이';
COMMENT ON COLUMN wtl_sply_ls.hgh_dep IS '최고깊이';
COMMENT ON COLUMN wtl_sply_ls.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_sply_ls.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN wtl_sply_ls.pip_lbl IS '관라벨';





drop table if exists wtl_pipe_ps;
create table public.wtl_pipe_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	pip_dep float
);

alter table public.wtl_pipe_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_pipe_ps IS '상수관로 심도';
COMMENT ON COLUMN wtl_pipe_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_pipe_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_pipe_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_pipe_ps.pip_dep IS '심도';



drop table if exists wtl_stpi_ps;
create table public.wtl_stpi_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	mof_cde text,
	mop_cde text,
	std_dip float,
	stp_hsl float,
	prc_nam text,
	cnt_num text,
	sys_chk text,
	ang_dir integer
);

alter table public.wtl_stpi_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_stpi_ps IS '스탠드파이프';
COMMENT ON COLUMN wtl_stpi_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_stpi_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_stpi_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_stpi_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_stpi_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_stpi_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_stpi_ps.mof_cde IS '스탠드파이프형식';
COMMENT ON COLUMN wtl_stpi_ps.mop_cde IS '관재질';
COMMENT ON COLUMN wtl_stpi_ps.std_dip IS '관경';
COMMENT ON COLUMN wtl_stpi_ps.stp_hsl IS '표고';
COMMENT ON COLUMN wtl_stpi_ps.prc_nam IS '제작회사명';
COMMENT ON COLUMN wtl_stpi_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_stpi_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN wtl_stpi_ps.ang_dir IS '방향각';





drop table if exists wtl_valv_ps;
create table public.wtl_valv_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	mof_cde text,
	mop_cde text,
	std_dip float,
	sae_cde text,
	tro_cnt float,
	cro_cnt float,
	mth_cde text,
	for_cde text,
	val_std text,
	val_saf float,
	prc_nam text,
	pip_cde text,
	pip_idn integer,
	cst_cde text,
	off_cde text,
	cnt_num text,
	ang_dir integer,
	sys_chk text,
	ugid text,
	sht_idx text,
	val_dep float
);

alter table public.wtl_valv_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_valv_ps IS '변류시설';
COMMENT ON COLUMN wtl_valv_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_valv_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_valv_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_valv_ps.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_valv_ps.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_valv_ps.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_valv_ps.mof_cde IS '변류형식';
COMMENT ON COLUMN wtl_valv_ps.mop_cde IS '관재질';
COMMENT ON COLUMN wtl_valv_ps.std_dip IS '관경';
COMMENT ON COLUMN wtl_valv_ps.sae_cde IS '제수변회전방향';
COMMENT ON COLUMN wtl_valv_ps.tro_cnt IS '제수변총회전수';
COMMENT ON COLUMN wtl_valv_ps.cro_cnt IS '제수변현회전수';
COMMENT ON COLUMN wtl_valv_ps.mth_cde IS '제수변구동방법';
COMMENT ON COLUMN wtl_valv_ps.for_cde IS '시설물형태';
COMMENT ON COLUMN wtl_valv_ps.val_std IS '변실규격';
COMMENT ON COLUMN wtl_valv_ps.val_saf IS '설정압력';
COMMENT ON COLUMN wtl_valv_ps.prc_nam IS '제작회사명';
COMMENT ON COLUMN wtl_valv_ps.pip_cde IS '관로지형지물부호';
COMMENT ON COLUMN wtl_valv_ps.pip_idn IS '관로관리번호';
COMMENT ON COLUMN wtl_valv_ps.cst_cde IS '이상상태';
COMMENT ON COLUMN wtl_valv_ps.off_cde IS '개폐여부';
COMMENT ON COLUMN wtl_valv_ps.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_valv_ps.ang_dir IS '방향각';
COMMENT ON COLUMN wtl_valv_ps.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN wtl_valv_ps.ugid IS '3D고유식별코드';
COMMENT ON COLUMN wtl_valv_ps.sht_idx IS '5000도엽번호';
COMMENT ON COLUMN wtl_valv_ps.val_dep IS '밸브깊이';










drop table if exists wtl_clpi_lm;
create table public.wtl_clpi_lm(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	sht_num text,
	mng_cde text,
	ist_ymd text,
	saa_cde text,
	mop_cde text,
	std_dip float,
	byc_len float,
	jht_cde text,
	low_dep float,
	hgh_dep float,
	cnt_num text,
	sys_chk text,
	pip_lbl text
);

alter table public.wtl_clpi_lm owner to bfna_user;

COMMENT ON TABLE public.wtl_clpi_lm IS '상수폐관로';
COMMENT ON COLUMN wtl_clpi_lm.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_clpi_lm.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_clpi_lm.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_clpi_lm.sht_num IS '도엽번호';
COMMENT ON COLUMN wtl_clpi_lm.mng_cde IS '관리기관코드';
COMMENT ON COLUMN wtl_clpi_lm.ist_ymd IS '설치일자';
COMMENT ON COLUMN wtl_clpi_lm.saa_cde IS '상수관용도';
COMMENT ON COLUMN wtl_clpi_lm.mop_cde IS '관재질';
COMMENT ON COLUMN wtl_clpi_lm.std_dip IS '관경';
COMMENT ON COLUMN wtl_clpi_lm.byc_len IS '연장';
COMMENT ON COLUMN wtl_clpi_lm.jht_cde IS '접합종류';
COMMENT ON COLUMN wtl_clpi_lm.low_dep IS '최저깊이';
COMMENT ON COLUMN wtl_clpi_lm.hgh_dep IS '최고깊이';
COMMENT ON COLUMN wtl_clpi_lm.cnt_num IS '공사번호';
COMMENT ON COLUMN wtl_clpi_lm.sys_chk IS '대장초기화여부';
COMMENT ON COLUMN wtl_clpi_lm.pip_lbl IS '관라벨';





drop table if exists wtl_clde_ps;
create table public.wtl_clde_ps(
	ftr_cde text,
	ftr_idn bigint primary key,
	hjd_cde text,
	pip_dep float
);

alter table public.wtl_clde_ps owner to bfna_user;

COMMENT ON TABLE public.wtl_clde_ps IS '상수폐관심도';
COMMENT ON COLUMN wtl_clde_ps.ftr_cde IS '지형지물부호';
COMMENT ON COLUMN wtl_clde_ps.ftr_idn IS '관리번호';
COMMENT ON COLUMN wtl_clde_ps.hjd_cde IS '행정읍면동코드';
COMMENT ON COLUMN wtl_clde_ps.pip_dep IS '심도';





