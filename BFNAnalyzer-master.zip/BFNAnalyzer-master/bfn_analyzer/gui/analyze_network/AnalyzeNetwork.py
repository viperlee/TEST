# -*- coding: utf-8 -*-
import networkx as nx
from random import randint

from bfn_analyzer.utilities.patterns import Singleton
from bfn_analyzer.utilities.DbManager import DbManager
from ..data_processing.DataProcessingUiBase import *
from .AnalyzeNetworkDlg import AnalyzeNetworkDlg
from bfn_analyzer.core.LayerManager import *
from qgis.core import *


class AnalyzeNetwork(DataProcessingUiBase, Singleton):
    def __init__(self):
        DataProcessingUiBase.__init__(self)
        self.set_dialog(AnalyzeNetworkDlg())
        self.using_multi_thread = False
        self.set_title(u'지하시설물 네트워크 분석', u'지하시설물 네트워크 분석')

    def append_option_ui(self):
        pass
        # validator = QDoubleValidator(0.1, 10.0, 1)
        # option_ui_list = list()
        # label = QLabel(u'disconnected islands xy tolerance(m)')
        # option_ui_list.append(['lb_dis_tol_xy', label])
        # le_tolerance = QLineEdit()
        # le_tolerance.setValidator(validator)
        # option_ui_list.append(['le_tolerance_xy', le_tolerance])
        # self.dlg.append_option_ui(option_ui_list)
        #
        # option_ui_list = list()
        # label = QLabel(u'disconnected islands  z tolerance(m)')
        # option_ui_list.append(['lb_dis_tol_z', label])
        # le_tolerance = QLineEdit()
        # le_tolerance.setValidator(validator)
        # option_ui_list.append(['le_tolerance_z', le_tolerance])
        # self.dlg.append_option_ui(option_ui_list)

    def set_job_info(self):
        self.proc_name = 'analyze_network'
        db_manager = DbManager.get_instance()
        self.default_db_uri = db_manager.get_current_db_info()

    def update_job_from_ui(self):
        for job in self.all_jobs:
            if job.description == u"disconnected_islands":
                job.callback = self.disconnected_islands
                job.args = [0]

        return True

    def disconnected_islands(self, update_progress, print_log_message, job_index, args):
        start_time = datetime.datetime.now()
        layer_manager = LayerManager.get_instance()
        const = Const.get_instance()
        ly_link = layer_manager.get_layer(const.LAYER_NAME_PIPE_LINK)

        if not ly_link:
            log(self, '레이어가 없음', Qgis.Warning)
            return False

        if not ly_link.isEditable():
            ly_link.startEditing()

        is_update_style = True
        xy_tol = 0.000001
        try:
            if self.dlg.rd_tolerance_xy.isChecked():
                xy_tol_text = self.dlg.le_tolerance_xy.text()
                if not xy_tol_text.replace('.', '', 1).isdigit():
                    pass
                else:
                    # 소수점 6자리
                    xy_tol = float(xy_tol_text)
                    xy_tol = round(xy_tol, 6)
                    if xy_tol < 0.000001:
                        xy_tol = 0.000001
        except:
            pass

        z_tol = None
        try:
            if self.dlg.rd_no_merge_z.isChecked():
                z_tol = 0.001
            elif self.dlg.rd_tolerance_z.isChecked():
                z_tol_text = self.dlg.le_tolerance_z.text()
                if not z_tol_text.replace('.', '', 1).isdigit():
                    pass
                else:
                    # 소수점 3자리(0.001~99.999)
                    z_tol = float(z_tol_text)
                    z_tol = round(z_tol, 3)
                    if z_tol < 0.001:
                        z_tol = 0.001
                    if z_tol > 99.999:
                        z_tol = None
        except:
            pass

        G = nx.Graph()
        count = 0
        total_cnt = ly_link.featureCount()
        print_log_message.emit([u'[{0}] total link count: {1}'.format(u'disconnected_islands', total_cnt), 0])

        src_crs = ly_link.crs()
        dest_crs = QgsCoordinateReferenceSystem(5179)
        tr = QgsCoordinateTransform(src_crs, dest_crs, QgsProject.instance())

        for feat in ly_link.getFeatures():
            count += 1
            done = ly_link.changeAttributeValue(feat.id(), ly_link.attr_idx.group_id, -1)
            geom = feat.geometry()

            QgsGeometry.convertToSingleType(geom)  # QGIS 3.x seems to load single LineString as MultiLineString??
            geom.transform(tr)
            line = geom.asPolyline()

            for i in range(len(line) - 1):
                # z값 상관 없이 group
                if z_tol is None:
                    G.add_edges_from([((int(line[i][0] / xy_tol), int(line[i][1] / xy_tol)),
                                       (int(line[i + 1][0] / xy_tol), int(line[i + 1][1] / xy_tol)),
                                       {
                                           'fid': feat.id()})])  # first scale by tolerance, then convert to int.  Before doing this, there were problems (in NetworkX v1) with floats not equating, thus creating disconnects that weren't there.
                else:
                    s_vtx = geom.vertexAt(i)
                    e_vtx = geom.vertexAt(i+1)
                    G.add_edges_from([((int(s_vtx.x() / xy_tol)*1000000 + int(s_vtx.z() * -1.0 /z_tol) , int(s_vtx.y() / xy_tol)),
                                       (int(e_vtx.x() / xy_tol)*1000000 + int(e_vtx.z() * -1.0 /z_tol), int(e_vtx.y() / xy_tol)),
                                       {
                                           'fid': feat.id()})])  # first scale by tolerance, then convert to int.  Before doing this, there were problems (in NetworkX v1) with floats not equating, thus creating disconnects that weren't there.

            if count % 1000 == 0:
                print_log_message.emit([u'[{0}] progress... {1}'.format(u'disconnected_islands', count), 0])
                elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
                update_progress.emit([job_index, count, total_cnt, elapsed_time])

        print_log_message.emit([u'[{0}] progress... {1}'.format(u'disconnected_islands', count), 0])

        print_log_message.emit([u'[{0}] make a graph...'.format(u'disconnected_islands'), 0])
        connected_components = list(nx.connected_component_subgraphs(G))    # this takes a long time.  TODO: how to show progress?

        # gather edges and components to which they belong
        fid_comp = {}
        for i, graph in enumerate(connected_components):
           for edge in graph.edges(data=True):
               fid_comp[edge[2].get('fid', None)] = i

        # write output to csv file
        # with open('C:/Tmp/Components.csv', 'wb') as f:
        #    w = csv.DictWriter(f, fieldnames=['fid', 'group'])
        #    w.writeheader()
        #    for (fid, group) in fid_comp.items():
        #        w.writerow({'fid': fid, 'group': group})

        for (fid, group) in fid_comp.items():
            done = ly_link.changeAttributeValue(fid, ly_link.attr_idx.group_id, group)

        groups = list(set(fid_comp.values()))

        print_log_message.emit([u'[{0}] renew styles...'.format(u'disconnected_islands'), 0])
        if is_update_style:
            categories = []
            firstCat = True
            for cat in groups:
                symbol = QgsSymbol.defaultSymbol(ly_link.geometryType())
                symbol.setColor(QColor(randint(0, 255), randint(0, 255), randint(0, 255)))
                if firstCat:
                    firstCat = False
                else:
                    symbol.setWidth(symbol.width() * 5)
                category = QgsRendererCategory(cat, symbol, "%d" % cat)
                categories.append(category)

            renderer = QgsCategorizedSymbolRenderer('group_id', categories)
            ly_link.setRenderer(renderer)

            #                    if self.iface.mapCanvas().isCachingEnabled():
            #                        aLayer.setCacheImage(None)
            #                    else:
            #                        self.iface.mapCanvas().refresh()
            ly_link.triggerRepaint()

        print_log_message.emit([u'[{0}] save layer...'.format(u'disconnected_islands'), 0])
        ly_link.commitChanges()

        elapsed_time = (datetime.datetime.now() - start_time).total_seconds()
        update_progress.emit([job_index, count, total_cnt, elapsed_time])
        print_log_message.emit([u'[{0}] analyze completed...'.format(u'disconnected_islands'), 0])

        group_links_count = dict()
        for group_id in fid_comp.values():
            try:
                group_links_count[group_id] += 1
            except:
                group_links_count[group_id] = 1

        link_count_group = dict()
        for link_count in group_links_count.values():
            try:
                link_count_group[link_count] += 1
            except:
                link_count_group[link_count] = 1


        link_group_list_out = list()
        for link_count in sorted(link_count_group.keys()):
            link_group_list_out.append(u"{0},{1}".format(link_count, link_count_group[link_count]))
        analyze_text = u'--------------------------------\n' \
                       u'전체 링크 수: {0}, 전체 그룹 수:{1}\n' \
                       u'--------------------------------\n' \
                       u'링크 수,그룹 수\n'.format(total_cnt, len(groups))
        analyze_text += "\n".join(link_group_list_out)
        print_log_message.emit([u'[{0}] analysis results\n{1}'.format(u'disconnected_islands', analyze_text), 0])

        return True

