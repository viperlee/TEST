# -*- coding: utf-8 -*-

from bfn_analyzer.utilities.patterns import Singleton
from bfn_analyzer.utilities.DbManager import DbManager
from ..data_processing.DataProcessingUiBase import *
from .GenerateNetworkDlg import GenerateNetworkDlg
from PyQt5.QtWidgets import *


class GenerateNetwork(DataProcessingUiBase, Singleton):
    def __init__(self):
        DataProcessingUiBase.__init__(self)
        self.set_dialog(GenerateNetworkDlg())
        self.using_multi_thread = False
        self.set_title(u'지하시설물 네트워크 생성', u'지하시설물 네트워크 생성')

    def append_option_ui(self):
        pass

    def set_job_info(self):
        self.proc_name = 'generate_network'
        db_manager = DbManager.get_instance()
        self.default_db_uri = db_manager.get_current_db_info()

    def update_job_from_ui(self):
        merge_node_sql = ''
        if self.dlg.rd_all_merge_z.isChecked():
            merge_node_sql = """
            update swl_pipe_lm_cn_info as a
            set node_id = nd_id
            from (
                select a.node_id as nd_id, b.mid
                from swl_pipe_lm_cn_info as a, swl_pipe_lm_cn_info as b
                where st_intersects(a.geom, b.geom)
                    and a.node_id != b.node_id
                    and a.mid < b.mid
                )as b
            where a.mid = b.mid;
            """ *10
        elif self.dlg.rd_no_merge_z.isChecked():
            merge_node_sql = """
            update swl_pipe_lm_cn_info as a
            set node_id = nd_id
            from (
                select a.node_id as nd_id, b.mid
                from swl_pipe_lm_cn_info as a, swl_pipe_lm_cn_info as b
                where st_intersects(a.geom, b.geom)
                    and a.node_id != b.node_id
                    and a.mid < b.mid
                    and a.depth = b.depth
                )as b
            where a.mid = b.mid;
            """ *10
        elif self.dlg.rd_tolerance_z.isChecked():
            tolerance = self.dlg.le_tolerance_z.text()
            if not tolerance.replace('.', '', 1).isdigit():
                return False
            merge_node_sql = """
            update swl_pipe_lm_cn_info as a
            set node_id = nd_id,
                min_depth = least(a.min_depth, b.min_depth),
                max_depth = greatest(a.max_depth, b.max_depth)
            from(
                select a.node_id as nd_id,
                    a.mid as mid1,
                    b.mid as mid2,
                    least(a.min_depth, b.min_depth) as min_depth,
                    greatest(a.max_depth, b.max_depth) as max_depth
                from swl_pipe_lm_cn_info as a, swl_pipe_lm_cn_info as b
                where st_intersects(a.geom, b.geom)
                    and a.node_id != b.node_id
                    and ((b.min_depth between a.min_depth - {0} and a.max_depth + {0})
                        or (b.max_depth between a.min_depth - {0} and a.max_depth + {0}))
                    and a.mid < b.mid
                )as b
            where a.mid = b.mid1 or a.mid = b.mid2;
            """.format(tolerance) * 10
        try:
            self.enroll_procedures()
            for job in self.all_jobs:
                job.replace_strings = {u'$merge_sql': merge_node_sql}
                if job.description == u"불필요한 노드 삭제(연결 링크가 두 개인 노드)":
                    # 20번 반복
                    job.exec_cnt = 20
        except Exception as e:
            self.print_log_message(u'update_job_from_ui failed {0}'.format(e))
            return False

        return True

    def enroll_procedures(self):
        sql = """
            drop function if exists remove_curv_vtx;
            create or replace function remove_curv_vtx(geom geometry, cross_pnt geometry, boundary float)
            returns geometry as $$
            declare
                vtx_cnt int := st_numPoints(geom);
                buff_pnt geometry := st_buffer(cross_pnt, boundary, 4);
                status int := 0;
                endVertex geometry(Pointz, 5186);
                vtx_idx int := 2;
                start_idx int := -1;
                end_idx int := -1;
                new_geom geometry(Linestringz,5186) := ST_MakeLine(st_pointN(geom, 1), st_pointN(geom, vtx_cnt));
            begin
                LOOP
                    exit when vtx_idx > vtx_cnt-1;
                    if st_intersects(st_pointN(geom, vtx_idx), buff_pnt) then
                        if status = 0 then 
                            new_geom := ST_AddPoint(new_geom, st_pointN(geom, vtx_idx), st_numPoints(new_geom)-1);
                            status := 1;
                            start_idx := vtx_idx;
                        else 
                            endVertex = st_pointN(geom, vtx_idx);
                        end if;
                    elseif (status = 1) then
                        new_geom := ST_AddPoint(new_geom, endVertex, st_numPoints(new_geom)-1);
                        new_geom := ST_AddPoint(new_geom, st_pointN(geom, vtx_idx), st_numPoints(new_geom)-1);
                        end_idx  := vtx_idx;
                        status := 2;
                    else
                        new_geom := ST_AddPoint(new_geom, st_pointN(geom, vtx_idx), st_numPoints(new_geom)-1);
                    end if;
                    vtx_idx = vtx_idx +1;
                    
                end loop;
                     return new_geom;
            end;
            $$ language plpgsql;

            
            drop function if exists set_link_z;
            create or replace function set_link_z(_geom geometry, _start_z float, _end_z float)
            returns geometry as $$
            declare
                vtx_cnt int := st_numPoints(_geom);
                vtx_idx int := 2;
                new_geom geometry(Linestringz,5186) := st_setsrid(ST_MakeLine(ST_MakePoint(st_x(st_pointN(_geom, 1)), st_y(st_pointN(_geom, 1)), _start_z), ST_MakePoint(st_x(st_pointN(_geom, vtx_cnt)), st_y(st_pointN(_geom, vtx_cnt)), _end_z)),5186);
                z_value float := 0;
                loc float := 0;
                
            begin
                LOOP
                    exit when vtx_idx > vtx_cnt-1;
                    loc := ST_LineLocatePoint(_geom, st_pointN(_geom, vtx_idx));
                        z_value := round(((_end_z - _start_z) * loc + _start_z)::numeric,2);
                    new_geom := ST_AddPoint(new_geom, st_setsrid(ST_MakePoint(st_x(st_pointN(_geom, vtx_idx)), st_y(st_pointN(_geom, vtx_idx)), z_value), 5186), st_numPoints(new_geom)-1);
                    vtx_idx = vtx_idx +1;
                end loop;
                     return new_geom;
            end;
            $$ language plpgsql;
            
            alter function public.remove_curv_vtx(geom geometry, cross_pnt geometry, boundary float) owner to bfna_user;
            alter function public.set_link_z(_geom geometry, _start_z float, _end_z float) owner to bfna_user;
        """
        db_manager = DbManager.get_instance()
        db_manager.execute_sql(self.default_db_uri, sql, ExecuteType.EXECUTE)

