# -*- coding: utf-8 -*-
import os
from PyQt5 import uic
from PyQt5.QtWidgets import *
from PyQt5.Qt import *

from bfn_analyzer.Const import *
from bfn_analyzer.utilities.patterns import Singleton
from ..data_processing.DataProcessingDlg import DataProcessingDlg


class GenerateNetworkDlg(DataProcessingDlg):
    def __init__(self, parent=None):
        super(GenerateNetworkDlg, self).__init__(parent)
        self.append_option_ui()

    def append_option_ui(self):
        validator = QDoubleValidator(0.1, 10.0, 1)
        group_z = QGroupBox()
        layout_z = QHBoxLayout()
        label = QLabel(u'노드병합기준(수직): ')
        self.rd_all_merge_z = QRadioButton(u'전부병합')
        self.rd_no_merge_z = QRadioButton(u'병합안함')
        self.rd_tolerance_z = QRadioButton(u'tolerance(0 ~ 99.0m)')
        self.le_tolerance_z = QLineEdit()
        self.le_tolerance_z.setText('0.1')
        self.le_tolerance_z.setValidator(validator)
        self.le_tolerance_z.setDisabled(True)
        self.rd_all_merge_z.setChecked(True)
        self.rd_tolerance_z.toggled.connect(self.rd_tolerance_z_toggled)
        layout_z.addWidget(label)
        layout_z.addWidget(self.rd_all_merge_z)
        layout_z.addWidget(self.rd_no_merge_z)
        layout_z.addWidget(self.rd_tolerance_z)
        layout_z.addWidget(self.le_tolerance_z)
        group_z.setLayout(layout_z)
        self.gl_option_list.addWidget(group_z, 1, 0)

        group_xy = QGroupBox()
        layout_xy = QHBoxLayout()
        label = QLabel(u'노드병합기준(수평): ')
        self.rd_all_merge_xy = QRadioButton(u'전부병합')
        self.rd_all_merge_xy.setDisabled(True)
        self.rd_no_merge_xy = QRadioButton(u'병합안함')
        self.rd_tolerance_xy = QRadioButton(u'tolerance(m)')
        self.le_tolerance_xy = QLineEdit()
        self.le_tolerance_xy.setText('0.1')
        self.le_tolerance_xy.setValidator(validator)
        self.le_tolerance_xy.setDisabled(True)
        self.rd_no_merge_xy.setChecked(True)
        self.rd_tolerance_xy.toggled.connect(self.rd_tolerance_xy_toggled)
        layout_xy.addWidget(label)
        layout_xy.addWidget(self.rd_all_merge_xy)
        layout_xy.addWidget(self.rd_no_merge_xy)
        layout_xy.addWidget(self.rd_tolerance_xy)
        layout_xy.addWidget(self.le_tolerance_xy)
        group_xy.setLayout(layout_xy)
        self.gl_option_list.addWidget(group_xy, 2, 0)

    def rd_tolerance_z_toggled(self, toggled):
        self.le_tolerance_z.setDisabled(not toggled)

    def rd_tolerance_xy_toggled(self, toggled):
        self.le_tolerance_xy.setDisabled(not toggled)

