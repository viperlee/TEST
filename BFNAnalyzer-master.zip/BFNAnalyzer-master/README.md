# Basement Facility Network Analyzer
: 지하시설물 네트워크 분석 컴포넌트 

## Postgresql 정보 
 * url: https://ap-northeast-2.console.aws.amazon.com/rds/home?region=ap-northeast-2
 * pg_version: 12.3 + postgis
 * host: bfna.cqirg4tfm0kl.ap-northeast-2.rds.amazonaws.com
 * port: 5432
 * dbname: bfna
 * user: postgres
 * pw: b***d*1**!

## QGis 
 * QGIS VERSION: 3.14
 * download: https://qgis.org/downloads/QGIS-OSGeo4W-3.14.16-2-Setup-x86_64.exe
 
## GeoTools
 * http://docs.geotools.org/latest/userguide/tutorial/quickstart/eclipse.html
 * JDK 설치: https://www.oracle.com/java/technologies/javase/javase-jdk8-downloads.html
 * eclipse  설치: https://www.eclipse.org/downloads/download.php?file=/oomph/epp/2020-09/R/eclipse-inst-jre-win64.exe
